export const NUM_ARTICLES = 12;
export const NUM_PROJECTS = 3;
export const NUM_FEATURED = 3;
export const NUM_PRODUCTS = 12;
export const NUM_SEARCH = 6;
export const NUM_TOP_PRODUCTS = 4;
