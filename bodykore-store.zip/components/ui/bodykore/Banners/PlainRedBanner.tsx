export default function PlainRedBanner() {
    return (
        <>
            <div className="h-4 bg-red-bc2026 mb-10"></div>
        </>
    )
}