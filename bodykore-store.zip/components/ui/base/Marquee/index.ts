export { default } from './Marquee'
