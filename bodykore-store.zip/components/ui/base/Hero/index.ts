export { default } from './Hero'
