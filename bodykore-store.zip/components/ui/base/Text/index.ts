export { default } from './Text'
