"use strict";
exports.id = 1332;
exports.ids = [1332];
exports.modules = {

/***/ 1332:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8702);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);





const Slider = ({ title1 , color1 , title2 , color2 , description , btnText , btnBorder , border , style , bgImage , link , height  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const { 0: slideBgColor , 1: setSlideBgColor  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0.5);
    const myRefs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        myRefs.current = bgImage.map((element, i)=>myRefs.current[i] ?? /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createRef)());
    // console.log(myRefs.current)
    }, []);
    // const [imgZooms, setImgZooms] = useState(new Array(bgImage.length).fill(false));
    const animateSlide = (bgColor)=>{
        switch(style){
            case "zoom":
                setSlideBgColor(bgColor);
                break;
        }
    };
    // const triggerZoom = (setZoom: boolean, i: number) => {
    //   console.log(myRefs.current[i].style)
    //   if (setZoom) {
    //     myRefs.current[i].style.transform = 'scale(1.1)'
    //   } else {
    //     myRefs.current[i].style.transform = 'scale(1)'
    //   }
    // }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full max-w-7xl m-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:flex lg:flex-row pb-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:flex lg:w-2/4 text-center lg:text-left",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${color2} text-4xl lg:text-5xl font-bebas font-bold italic`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `${color1} text-4xl lg:text-5xl font-bebas font-bold italic pr-2`,
                                    children: title1
                                }),
                                title2
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center lg:justify-end lg:w-2/4 py-8 lg:py-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: link || "#",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `w-52 h-12 mb-2 bg-transparent text-black-373933 ${border} ${btnBorder} hover:text-red-bc2026 hover:border-red-bc2026 rounded-lg font-bebas`,
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "font-bold",
                                    children: btnText
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-black-1c2023 lg:w-2/3 pb-8 text-center lg:text-left",
                children: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container mt-16 mx-auto"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__.Splide, {
                ref: sliderRef,
                options: {
                    pagination: false,
                    gap: "1rem",
                    type: "loop",
                    width: "100%",
                    autoWidth: false,
                    perPage: 3,
                    perMove: 1
                },
                renderControls: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "slider-progress",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "slider-progress-bar"
                        })
                    }),
                onMoved: (splide)=>{
                    // Update the bar width. CSS is found on components.css
                    const end = splide.Components.Controller.getEnd() + 1;
                    const bar = sliderRef.current.splideRef.current.getElementsByClassName("slider-progress-bar")[0];
                    bar.style.width = String(100 * (splide.index + 1) / end) + "%";
                },
                children: bgImage.map((b, i)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__.SplideSlide, {
                        className: "flex",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `${height} relative w-full bg-black bg-opacity-25 hover:bg-opacity-0 transition duration-500`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    //@ts-ignore
                                    ref: myRefs.current[i],
                                    className: `object-cover w-full ${height} transform transition duration-500`,
                                    src: b.url,
                                    alt: "",
                                    style: {}
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full h-full absolute block top-0 bg-black opacity-25 hover:bg-opacity-0 transition duration-500"
                                }),
                                b.link !== undefined ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        b.topTitle !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: b.link,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "absolute flex ml-10 mt-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "cursor-pointer text-4xl font-bebas font-bold italic absolute text-white",
                                                    style: {
                                                        letterSpacing: "1px"
                                                    },
                                                    children: b.topTitle
                                                })
                                            })
                                        }) : null,
                                        b.downTitle !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: b.link,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "absolute flex items-end h-full ml-7 pb-7",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "cursor-pointer text-xl font-roboto text-white",
                                                    style: {
                                                        letterSpacing: "1px"
                                                    },
                                                    children: b.downTitle
                                                })
                                            })
                                        }) : null
                                    ]
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        b.topTitle !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "absolute flex ml-10 mt-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-5xl font-bebas font-bold italic absolute text-white",
                                                style: {
                                                    letterSpacing: "1px"
                                                },
                                                children: b.topTitle
                                            })
                                        }) : null,
                                        b.downTitle !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "absolute flex items-end h-full ml-7 pb-7",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-xl font-roboto text-white",
                                                style: {
                                                    letterSpacing: "1px"
                                                },
                                                children: b.downTitle
                                            })
                                        }) : null
                                    ]
                                })
                            ]
                        })
                    }, i);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slider);


/***/ })

};
;