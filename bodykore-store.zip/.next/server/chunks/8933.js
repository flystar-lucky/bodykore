"use strict";
exports.id = 8933;
exports.ids = [8933];
exports.modules = {

/***/ 7341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_1__);


const SeoHeader = ({ seo  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_1__.NextSeo, {
        title: seo?.title,
        description: seo?.description,
        noindex: seo.noIndex || false,
        nofollow: seo.nofollow || false,
        openGraph: {
            title: seo?.title,
            description: seo?.description,
            images: [
                {
                    url: seo?.image?.url,
                    width: 800,
                    height: 600,
                    alt: seo?.title
                }
            ],
            site_name: seo?.title
        },
        twitter: {
            handle: "@handle",
            site: "@site",
            cardType: "summary_large_image"
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoHeader);


/***/ }),

/***/ 8099:
/***/ ((module) => {

module.exports = JSON.parse('{"Wt":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"Jr":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"av":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"Qk":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"vS":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"n_":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"LE":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"sX":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"m2":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"NR":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"ej":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"cn":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"ob":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"Od":{"title":"{product} - Bodykore","description":"","image":{"alt":"Bodykore","url":""}},"PE":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"Ls":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"oD":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"bK":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"nr":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"tQ":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"v_":{"title":"{title} - Bodykore","description":"","image":{"alt":"Bodykore","url":""}},"iI":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"Bl":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}},"PX":{"title":"Bodykore","description":"Bodykore","image":{"alt":"Bodykore","url":""}}}');

/***/ })

};
;