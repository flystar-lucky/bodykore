"use strict";
exports.id = 2322;
exports.ids = [2322];
exports.modules = {

/***/ 2322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ES": () => (/* binding */ getProjectsOfCategory),
/* harmony export */   "Zj": () => (/* binding */ getAllProjectsSlug),
/* harmony export */   "e5": () => (/* binding */ getProject),
/* harmony export */   "eJ": () => (/* binding */ getProjectCategories)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getProjectCategories = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProjectCategories {
      projectCategories {
        slug
        title
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.projectCategories;
};
const getProjectsOfCategory = async (slug, first)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProjectsOfCategory($slug: String!, $first: Int) {
      projectCategory(where: { slug: $slug }) {
        projects(first: $first) {
          slug
          title
          image(first: 1) {
            url
          }
        }
      }
    }
  `;
    const variables = {
        slug,
        first
    };
    const res = await graphcms.request(query, variables);
    return res.projectCategory === null ? [] : res.projectCategory.projects;
};
const getAllProjectsSlug = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllProjectsSlug {
      projects {
        slug
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.projects;
};
const getProject = async (slug)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query Project($slug: String!) {
      project(where: { slug: $slug }) {
        title
        subtitle
        image {
          url
        }
        products {
          handle
        }
        related {
          slug
          title
          image(first: 1) {
            url
          }
        }
      }
    }
  `;
    const variables = {
        slug
    };
    const res = await graphcms.request(query, variables);
    return res.project === null ? undefined : res.project;
};


/***/ })

};
;