"use strict";
exports.id = 6566;
exports.ids = [6566];
exports.modules = {

/***/ 2101:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _state_atoms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7239);
/* harmony import */ var _ui_bodykore_Cart_SingleCartItem__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6308);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const CartSidebar = ({ items , checkoutUrl , cartTotal  })=>{
    const [sidebarOpen, setSidebarOpen] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_5__/* .cartSidebarOpenState */ .Dy);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Root, {
        show: sidebarOpen,
        as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog, {
            as: "div",
            className: "fixed inset-0 flex z-50 flex-row-reverse",
            onClose: setSidebarOpen,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                    as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                    enter: "transition-opacity ease-linear duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog.Overlay, {
                        className: "fixed inset-0 bg-gray-600 bg-opacity-75"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                    as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                    enter: "transition ease-in-out duration-300 transform",
                    enterFrom: "translate-x-full",
                    enterTo: "translate-x-0",
                    leave: "transition ease-in-out duration-300 transform",
                    leaveFrom: "translate-x-0",
                    leaveTo: "translate-x-full",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative flex-1 flex flex-col max-w-xs w-full bg-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                                as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                                enter: "ease-in-out duration-300",
                                enterFrom: "opacity-0",
                                enterTo: "opacity-100",
                                leave: "ease-in-out duration-300",
                                leaveFrom: "opacity-100",
                                leaveTo: "opacity-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute top-0 left-0 -ml-12 pt-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        type: "button",
                                        className: "ml-1 flex items-center justify-center h-10 w-10 rounded-full",
                                        onClick: ()=>setSidebarOpen(false),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "sr-only",
                                                children: "Close sidebar"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_2__.XIcon, {
                                                className: "h-6 w-6 text-white",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex-1 h-0 pt-8 pb-4 overflow-y-auto flex flex-col justify-between",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex-shrink-0 flex justify-center items-center px-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-2xl font-bebas font-bold italic text-black-373933",
                                                    style: {
                                                        letterSpacing: "1px"
                                                    },
                                                    children: "Cart"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                                className: "mt-5 px-2 space-y-1 flex flex-col gap-4",
                                                children: items.map((item, i)=>{
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex flex-col gap-4",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_bodykore_Cart_SingleCartItem__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                                name: item.name,
                                                                amount: item.amount,
                                                                available: item.available,
                                                                option: item.option,
                                                                price: item.price,
                                                                image: item.image,
                                                                lineId: item.lineId,
                                                                cartId: item.cartId
                                                            })
                                                        ]
                                                    }, i);
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border-b border-gray-400 mx-8"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-between px-8 py-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "text-2xl font-bebas font-bold italic text-black-373933",
                                                        style: {
                                                            letterSpacing: "1px"
                                                        },
                                                        children: "SUBTOTAL"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        className: "text-2xl font-bebas font-bold italic text-red-bc2026",
                                                        style: {
                                                            letterSpacing: "1px"
                                                        },
                                                        children: [
                                                            "$",
                                                            cartTotal || "0"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border-b border-gray-400 mx-8"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bg-black-373933 uppercase rounded-lg text-white text-center px-8 py-4 mx-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-bold",
                                            href: checkoutUrl,
                                            children: "Checkout"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-center items-center",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        className: "font-roboto text-black-373933",
                                                        children: [
                                                            " ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "font-bold",
                                                                children: "Pay over the time"
                                                            }),
                                                            " with"
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: "/Product/affirm.jpg",
                                                        alt: ""
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                    className: "font-roboto text-black-373933 text-sm",
                                                    children: [
                                                        "As low as ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font-bold",
                                                            children: "$30/mo"
                                                        }),
                                                        " or ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font-bold",
                                                            children: "0%"
                                                        }),
                                                        " APR"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-shrink-0 w-16"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartSidebar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2980:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9641);





const abouts = [
    {
        name: "#WeAreBodyKore",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].about.path */ .Z.about.path
    },
    {
        name: "Inspiration",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].portfolio.path */ .Z.portfolio.path
    },
    {
        name: "Manuals",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].manuals.path */ .Z.manuals.path
    },
    {
        name: "Loyalty Program",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].loyaltyProgram.path */ .Z.loyaltyProgram.path
    },
    {
        name: "Ambassador Program",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].ambassadors.path */ .Z.ambassadors.path
    },
    {
        name: "Blog",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].blog.path */ .Z.blog.path
    }, 
];
const supports = [
    {
        name: "Store Locator",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].stores.path */ .Z.stores.path
    },
    {
        name: "Financing",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].financing.path */ .Z.financing.path
    },
    {
        name: "Tutorials",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].videos.path */ .Z.videos.path
    },
    {
        name: "Warranty",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].warranty.path */ .Z.warranty.path
    },
    {
        name: "Returns Policy",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].returnPolicy.path */ .Z.returnPolicy.path
    }, 
];
const Footer = ({ productCat  })=>{
    const { 0: submit , 1: setSubmit  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const handleSubmit = async (event)=>{
        event.preventDefault();
        if (submit !== 0) {
            console.log("Stopped");
            return;
        }
        setSubmit(1);
    //const Email = event.currentTarget.email.vale;    
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: "w-full h-fit bg-black pt-16 pb-5",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap max-w-7xl m-auto justify-start lg:justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "px-16",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/svg/LogoFooter.svg",
                                alt: "",
                                className: "w-44"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "text-gray-200 font-roboto pt-5",
                                children: [
                                    "Global Leaders in Fitness Center Designs ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    " and Equipment Distribution."
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center text-white font-roboto font-bold pt-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "40",
                                        height: "40",
                                        viewBox: "0 0 40 40",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                            id: "Phonecall",
                                            transform: "translate(0 0)",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                    id: "Rect\xe1ngulo_7",
                                                    "data-name": "Rect\xe1ngulo 7",
                                                    width: "40",
                                                    height: "40",
                                                    transform: "translate(0 0)",
                                                    fill: "#fff",
                                                    opacity: "0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    id: "Icon_feather-phone-call",
                                                    "data-name": "Icon feather-phone-call",
                                                    d: "M14.048,4.857A4.2,4.2,0,0,1,17.37,8.173M14.048,1.5a7.561,7.561,0,0,1,6.686,6.665m-.841,6.7v2.518a1.681,1.681,0,0,1-1.833,1.679A16.663,16.663,0,0,1,10.8,16.483a16.383,16.383,0,0,1-5.046-5.036A16.59,16.59,0,0,1,3.175,4.169a1.68,1.68,0,0,1,1.674-1.83H7.371A1.681,1.681,0,0,1,9.053,3.783a10.761,10.761,0,0,0,.589,2.359,1.676,1.676,0,0,1-.378,1.771L8.2,8.979a13.443,13.443,0,0,0,5.046,5.036l1.068-1.066a1.684,1.684,0,0,1,1.774-.378,10.815,10.815,0,0,0,2.363.588A1.68,1.68,0,0,1,19.893,14.863Z",
                                                    transform: "translate(7.92 9.587)",
                                                    fill: "none",
                                                    stroke: "#fff",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "1.7"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "pl-4",
                                        children: "949-325-3088"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center text-gray-200 font-roboto",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                        id: "Sales",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "40",
                                        height: "40",
                                        viewBox: "0 0 40 40",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                id: "Rect\xe1ngulo_7",
                                                "data-name": "Rect\xe1ngulo 7",
                                                width: "40",
                                                height: "40",
                                                fill: "#fff",
                                                opacity: "0"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                id: "Icon_ionic-md-paper-plane",
                                                "data-name": "Icon ionic-md-paper-plane",
                                                d: "M3.375,14.832l6.111,2.292.761,7.633,3.819-5.345,5.345,5.345L24.757,3.375Zm15.157,6.476-4.261-4.292,5.906-8.3L10.859,15.8,7.328,14.528,22.284,6.5Z",
                                                transform: "translate(5.625 5.625)",
                                                fill: "#fff"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "pl-4",
                                        children: "sales@bodykore.com"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center text-gray-200 font-roboto lg:pt-2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                        id: "Clock",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        width: "40",
                                        height: "40",
                                        viewBox: "0 0 40 40",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                id: "Rect\xe1ngulo_7",
                                                "data-name": "Rect\xe1ngulo 7",
                                                width: "40",
                                                height: "40",
                                                fill: "#fff",
                                                opacity: "0"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                id: "Icon_feather-clock",
                                                "data-name": "Icon feather-clock",
                                                transform: "translate(7 7)",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        id: "Trazado_8824",
                                                        "data-name": "Trazado 8824",
                                                        d: "M23,13A10,10,0,1,1,13,3,10,10,0,0,1,23,13Z",
                                                        transform: "translate(0)",
                                                        fill: "none",
                                                        stroke: "#fff",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: "2"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        id: "Trazado_8825",
                                                        "data-name": "Trazado 8825",
                                                        d: "M17.873,11,18,18l5.25,2.333",
                                                        transform: "translate(-6.25 -3.333)",
                                                        fill: "none",
                                                        stroke: "#fff",
                                                        strokeLinecap: "round",
                                                        strokeLinejoin: "round",
                                                        strokeWidth: "2"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "pl-4",
                                        children: [
                                            "MON-FRI (9AM-5PM PST) ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            " Sat - Sun (Closed )"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-wrap justify-start lg:pt-0",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-16 py-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-bebas italic text-2xl text-white pb-1",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: "Products"
                                    }),
                                    productCat.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: `${_config_routes__WEBPACK_IMPORTED_MODULE_3__/* ["default"].collection.path */ .Z.collection.path}/${item.slug}`,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "flex flex-wrap text-gray-200 font-roboto cursor-pointer py-2",
                                                children: item.title
                                            })
                                        }, index))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-16 py-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-bebas italic text-2xl text-white pb-1",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: "About"
                                    }),
                                    abouts.map((about, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: about.link,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "flex-wrap text-gray-200 font-roboto cursor-pointer py-2",
                                                children: about.name
                                            })
                                        }, i))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-16 py-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-bebas italic text-2xl text-white pb-1",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: "Support"
                                    }),
                                    supports.map((support, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: support.link,
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                className: "flex-wrap text-gray-200 font-roboto cursor-pointer py-2",
                                                children: support.name
                                            })
                                        }, i))
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center lg:justify-start lg:pl-16 items-center pt-10 xl:pt-3 max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        onSubmit: handleSubmit,
                        className: "flex items-center bg-white shadow-md rounded-lg w-64",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-1 sm:mt-0 sm:col-span-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                name: "email",
                                id: "email",
                                className: "flex items-center pl-3 bg-white rounded-lg w-64 h-10",
                                placeholder: "Email",
                                required: true
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "bg-transparent hover:bg-white text-white hover:text-black py-2 px-6 border-2 border-gray-200 hover:border-transparent rounded-lg text-md font-semibold ml-4",
                        style: {
                            letterSpacing: "1.5px"
                        },
                        children: "SUBSCRIBE"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "border-b border-gray-500 pt-10 lg:pt-5 xl:pt-5 max-w-7xl m-auto"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex lg:flex-row flex-wrap justify-center lg:justify-between py-8 max-w-7xl m-auto px-16",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:w-2/3 w-full flex justify-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex text-gray-200 text-center lg:text-left flex-wrap",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "pr-2",
                                        children: "\xa92021 BodyKore -All rights reserved. -"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "hidden lg:block",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/terms-of-us",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "underline cursor-pointer w-24",
                                                    children: "Terms of Use"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "px-2",
                                                children: "|"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/privacy-policy",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "underline cursor-pointer w-24",
                                                    children: "Privacy Policy"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "px-2",
                                                children: "|"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                href: "/cookies-policy",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "underline cursor-pointer w-28",
                                                    children: "Cookies Policy"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "block lg:hidden pb-5",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex text-gray-200 text-center lg:text-left",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/terms-of-us",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "underline cursor-pointer w-24",
                                        children: "Terms of Use"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "px-2",
                                    children: "|"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/privacy-policy",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "underline cursor-pointer w-24",
                                        children: "Privacy Policy"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "px-2",
                                    children: "|"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/cookies-policy",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "underline cursor-pointer w-28",
                                        children: "Cookies Policy"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:w-1/3 flex justify-end",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "px-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "https://www.instagram.com/bodykore/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/svg/instagram-footer.svg",
                                                alt: "",
                                                className: "cursor-pointer"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "px-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "https://www.facebook.com/BodyKore/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/svg/facebook-footer.svg",
                                                alt: "",
                                                className: "cursor-pointer"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "px-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "https://twitter.com/bodykore",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/svg/twitter-footer.svg",
                                                alt: "",
                                                className: "cursor-pointer"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "px-5",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "https://www.youtube.com/user/BodyKore",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/svg/youtube-footer.svg",
                                                alt: "",
                                                className: "cursor-pointer"
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 8969:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9641);
/* harmony import */ var _utils_checkout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8576);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6734);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5003);
/* harmony import */ var _state_atoms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7239);
/* harmony import */ var _MobileMenu__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9366);
/* harmony import */ var _CartSidebar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2101);
/* harmony import */ var _ui_bodykore_Dropdown_ProductsDD__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8181);
/* harmony import */ var _ui_bodykore_Dropdown_ResourcesDD__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8763);
/* harmony import */ var _ui_bodykore_SearchModal__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2447);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CartSidebar__WEBPACK_IMPORTED_MODULE_9__, _ui_bodykore_Dropdown_ProductsDD__WEBPACK_IMPORTED_MODULE_10__, _ui_bodykore_Dropdown_ResourcesDD__WEBPACK_IMPORTED_MODULE_11__, _ui_bodykore_SearchModal__WEBPACK_IMPORTED_MODULE_12__, _MobileMenu__WEBPACK_IMPORTED_MODULE_13__]);
([_CartSidebar__WEBPACK_IMPORTED_MODULE_9__, _ui_bodykore_Dropdown_ProductsDD__WEBPACK_IMPORTED_MODULE_10__, _ui_bodykore_Dropdown_ResourcesDD__WEBPACK_IMPORTED_MODULE_11__, _ui_bodykore_SearchModal__WEBPACK_IMPORTED_MODULE_12__, _MobileMenu__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const categories = [
    {
        name: "Inspiration",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path
    },
    {
        name: "Stores",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].stores.path */ .Z.stores.path
    },
    {
        name: "Contact",
        link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].contact.path */ .Z.contact.path
    }, 
];
const Header = ({ productCat , dynamicPages  })=>{
    const setMenuSidebarOpen = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useSetRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .menuSidebarOpenState */ .iy);
    const setCartSidebarOpen = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useSetRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .cartSidebarOpenState */ .Dy);
    const setSearchOpen = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useSetRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .searchOpenState */ .rn);
    const [cartItems, setCartItems] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .cartItemsState */ .uZ);
    const [checkoutUrl, setcheckoutUrl] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .checkoutUrlState */ .g0);
    const [cartTotal, setCartTotal] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .cartTotalState */ .jJ);
    const fetchCart = async ()=>{
        const checkoutId = js_cookie__WEBPACK_IMPORTED_MODULE_1___default().get("checkoutId");
        const email = js_cookie__WEBPACK_IMPORTED_MODULE_1___default().get("email");
        if (checkoutId !== undefined) {
            const checkout = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__/* .getCheckout */ .Om)(checkoutId);
            if (checkout !== undefined) {
                setCartItems((0,_utils_checkout__WEBPACK_IMPORTED_MODULE_8__/* .mapCheckout */ .e)(checkout));
                setcheckoutUrl(checkout.webUrl);
                setCartTotal(checkout.subtotalPriceV2.amount);
                if (email && checkout.email !== email) {
                    await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__/* .updateCheckoutEmail */ .Yj)(checkoutId, email);
                }
            } else {
                js_cookie__WEBPACK_IMPORTED_MODULE_1___default().remove("checkoutId");
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        fetchCart();
    }, []);
    const mapDynamicSearch = ()=>{
        const collections = productCat.map((item)=>({
                name: `${item.title} (Collection)`,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].collection.path */ .Z.collection.path}/${item.slug}`
            }));
        const projects = dynamicPages.projects.map((item)=>({
                name: `${item.title} (Portfolio)`,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path}/${item.slug}`
            }));
        const articles = dynamicPages.articles.map((item)=>({
                name: `${item.title} (Blog)`,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].blog.path */ .Z.blog.path}/${item.slug}`
            }));
        return [
            ...collections,
            ...projects,
            ...articles
        ];
    };
    const handleSearch = async (product)=>{};
    return /*Nav section*/ /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
        className: "sticky top-0 z-50",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-auto bg-black text-center tracking-wide text-sm py-1 px-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-white font-semibold",
                    children: "ENJOY THE BLACK FRIDAY - 30% OFF ON SELECTED ITEMS"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full bg-white sticky top-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-8 bg-white max-w-8xl m-auto",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CartSidebar__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            items: cartItems,
                            checkoutUrl: checkoutUrl,
                            cartTotal: cartTotal
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-start items-center xl:pl-16",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden xl:block",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/",
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/header/logo.png",
                                                alt: "BodyKore Logo",
                                                className: "cursor-pointer",
                                                style: {
                                                    maxWidth: "170px",
                                                    height: "max-content"
                                                }
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-center items-center xl:pr-20",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden xl:block",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex gap-12",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center gap-6",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex-1",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_bodykore_Dropdown_ProductsDD__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                                category: "Products",
                                                                subCategories: productCat.map((category)=>({
                                                                        name: category.title,
                                                                        img: category.image,
                                                                        slug: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].collection.path */ .Z.collection.path}/${category.slug}`,
                                                                        options: category.subcategories.map((subcat)=>{
                                                                            if (category.slug === "packages") {
                                                                                return {
                                                                                    text: subcat.name,
                                                                                    slug: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}/${subcat.slug}`
                                                                                };
                                                                            }
                                                                            return {
                                                                                text: subcat.name,
                                                                                slug: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=${category.title}&subcategory=${subcat.name}`
                                                                            };
                                                                        })
                                                                    }))
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "hidden flex-1 xl:block",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_bodykore_Dropdown_ResourcesDD__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                                category: "Resources",
                                                                subCategories: [
                                                                    [
                                                                        {
                                                                            name: "INFORMATIONAL",
                                                                            options: [
                                                                                {
                                                                                    text: "WeAreBodyKore",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].about.path */ .Z.about.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Ambassador Program",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].ambassadors.path */ .Z.ambassadors.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Loyalty Program",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].loyaltyProgram.path */ .Z.loyaltyProgram.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Manuals",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].manuals.path */ .Z.manuals.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Videos",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].videos.path */ .Z.videos.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Blog",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].blog.path */ .Z.blog.path,
                                                                                    newTab: "_self"
                                                                                }, 
                                                                            ]
                                                                        }, 
                                                                    ],
                                                                    [
                                                                        {
                                                                            name: "ORDER SUPPORT",
                                                                            options: [
                                                                                {
                                                                                    text: "Full Gym Solutions",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].gymSolutions.path */ .Z.gymSolutions.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Financing",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].financing.path */ .Z.financing.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "My Account",
                                                                                    link: "/auth/signin",
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Warranty Registration",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].warranty.path */ .Z.warranty.path,
                                                                                    newTab: "_self"
                                                                                },
                                                                                {
                                                                                    text: "Return Policy",
                                                                                    link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].returnPolicy.path */ .Z.returnPolicy.path,
                                                                                    newTab: "_self"
                                                                                }, 
                                                                            ]
                                                                        }, 
                                                                    ],
                                                                    [
                                                                        {
                                                                            name: "CATALOGS",
                                                                            options: [
                                                                                {
                                                                                    text: "Equipment Catalog",
                                                                                    link: "/PDFs/Equipment-Catalog.pdf",
                                                                                    newTab: "_blank"
                                                                                },
                                                                                {
                                                                                    text: "Product Catalog",
                                                                                    link: "/PDFs/Product-Catalog.pdf",
                                                                                    newTab: "_blank"
                                                                                },
                                                                                {
                                                                                    text: "HomeGym Catalog",
                                                                                    link: "/PDFs/Home-Gyms-Catalog.pdf",
                                                                                    newTab: "_blank"
                                                                                }, 
                                                                            ]
                                                                        }, 
                                                                    ], 
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "hidden flex-1 xl:block my-7 max-w-lg",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "relative w-full flex gap-20 pt-1",
                                                        children: categories.map((category, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                href: category.link,
                                                                passHref: true,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "text-black font-semibold cursor-pointer hover:text-red-bc2026 text-center",
                                                                    id: "menu-button",
                                                                    "aria-expanded": "true",
                                                                    "aria-haspopup": "true",
                                                                    children: category.name
                                                                })
                                                            }, i))
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-end items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "hidden xl:flex flex-1 gap-2 justify-end",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-end gap-3 my-5 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "cursor-pointer",
                                                    onClick: ()=>setSearchOpen(true),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                        className: "",
                                                        id: "Search",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "50",
                                                        height: "40",
                                                        viewBox: "0 0 40 40",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                                id: "Rect\xe1ngulo_7",
                                                                "data-name": "Rect\xe1ngulo 7",
                                                                width: "40",
                                                                height: "40",
                                                                fill: "#fff",
                                                                opacity: "0"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                id: "Icon_awesome-search",
                                                                "data-name": "Icon awesome-search",
                                                                d: "M19.728,17.294,15.833,13.4a.937.937,0,0,0-.664-.273h-.637a8.122,8.122,0,1,0-1.406,1.406v.637a.937.937,0,0,0,.273.664l3.895,3.895a.934.934,0,0,0,1.324,0l1.106-1.106A.942.942,0,0,0,19.728,17.294Zm-11.6-4.168a5,5,0,1,1,5-5A5,5,0,0,1,8.126,13.126Z",
                                                                transform: "translate(10.5 9.5)",
                                                                stroke: "#fff",
                                                                strokeWidth: "1"
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: "https://" + "bodykore-store.myshopify.com" + "/account",
                                                    passHref: true,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "cursor-pointer",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                            className: "mb-0.5",
                                                            id: "MYACCOUNT",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            width: "50",
                                                            height: "40",
                                                            viewBox: "0 0 40 40",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                                    id: "Rect\xe1ngulo_7",
                                                                    "data-name": "Rect\xe1ngulo 7",
                                                                    width: "40",
                                                                    height: "40",
                                                                    fill: "#fff",
                                                                    opacity: "0"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    id: "Icon_material-person-outline",
                                                                    "data-name": "Icon material-person-outline",
                                                                    d: "M15.545,8.267a2.506,2.506,0,1,1-2.506,2.506,2.505,2.505,0,0,1,2.506-2.506m0,10.739c3.544,0,7.278,1.742,7.278,2.506v1.313H8.267V21.511c0-.764,3.735-2.506,7.278-2.506M15.545,6a4.773,4.773,0,1,0,4.773,4.773A4.771,4.771,0,0,0,15.545,6Zm0,10.739C12.36,16.739,6,18.338,6,21.511v3.58H25.091v-3.58C25.091,18.338,18.731,16.739,15.545,16.739Z",
                                                                    transform: "translate(4.833 4.833)"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    onClick: ()=>setCartSidebarOpen(true),
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                        className: "cursor-pointer",
                                                        id: "Cart",
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "40",
                                                        height: "40",
                                                        viewBox: "0 0 40 40",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                                id: "Rect\xe1ngulo_7",
                                                                "data-name": "Rect\xe1ngulo 7",
                                                                width: "40",
                                                                height: "40",
                                                                fill: "#fff",
                                                                opacity: "0"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                id: "Icon_material-add-shopping-cart",
                                                                "data-name": "Icon material-add-shopping-cart",
                                                                d: "M11.421,9.119H13.4V6.262h2.976v-1.9H13.4V1.5H11.421V4.357H8.444v1.9h2.976ZM7.452,17.69a1.906,1.906,0,1,0,1.984,1.9A1.943,1.943,0,0,0,7.452,17.69Zm9.921,0a1.906,1.906,0,1,0,1.984,1.9A1.943,1.943,0,0,0,17.373,17.69ZM7.621,14.6l.03-.114.893-1.552h7.391a1.989,1.989,0,0,0,1.736-.981L21.5,5.271l-1.726-.914h-.01l-1.091,1.9-2.738,4.762H8.97l-.129-.257-2.222-4.5-.942-1.9-.933-1.9H1.5v1.9H3.484l3.571,7.229L5.716,13.919a1.784,1.784,0,0,0-.248.914,1.951,1.951,0,0,0,1.984,1.9h11.9v-1.9H7.869A.247.247,0,0,1,7.621,14.6Z",
                                                                transform: "translate(8.5 8.5)"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                                id: "numero",
                                                                transform: "translate(28)",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                                        id: "Elipse_1",
                                                                        "data-name": "Elipse 1",
                                                                        cx: "6",
                                                                        cy: "6",
                                                                        r: "6",
                                                                        fill: "#d33500"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("text", {
                                                                        id: "_1",
                                                                        "data-name": "1",
                                                                        transform: "translate(5 8)",
                                                                        fill: "#fff",
                                                                        fontSize: "7",
                                                                        fontFamily: "AcuminProExtraCond-Black, Acumin Pro ExtraCondensed",
                                                                        fontWeight: "800",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tspan", {
                                                                            x: "0",
                                                                            y: "0",
                                                                            children: cartItems.length
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "ml-4",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        href: "tel:949-325-3088",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            className: "bg-transparent text-black hover:text-red-bc2026 border border-black hover:border-red rounded-lg text-md px-3 py-2",
                                                            style: {
                                                                letterSpacing: "1.5px"
                                                            },
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex justify-center items-center",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                        xmlns: "http://www.w3.org/2000/svg",
                                                                        className: "h-5 w-5",
                                                                        fill: "none",
                                                                        viewBox: "0 0 24 24",
                                                                        stroke: "currentColor",
                                                                        strokeWidth: "2",
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                            strokeLinecap: "round",
                                                                            strokeLinejoin: "round",
                                                                            d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        className: "px-2 text-sm font-medium",
                                                                        children: "Call us"
                                                                    })
                                                                ]
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-start items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center pl-2 xl:hidden cursor-pointer",
                                        onClick: ()=>setMenuSidebarOpen(true),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            className: "h-9 w-9",
                                            fill: "none",
                                            viewBox: "0 0 24 24",
                                            stroke: "currentColor",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: "2",
                                                d: "M4 6h16M4 12h16M4 18h16"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_bodykore_SearchModal__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    dynamicItems: mapDynamicSearch()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MobileMenu__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    search: handleSearch,
                                    categories: [
                                        {
                                            title: "Products",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Resources",
                                            icon: "/svg/black-arrow.svg"
                                        }, 
                                    ],
                                    links: [
                                        {
                                            title: "Inspiration",
                                            href: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path
                                        },
                                        {
                                            title: "Stores",
                                            href: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].stores.path */ .Z.stores.path
                                        }, 
                                    ],
                                    linksImg: [
                                        {
                                            title: "Cart",
                                            icon: "/svg/header-cart.svg",
                                            href: "#"
                                        },
                                        {
                                            title: "Account",
                                            icon: "/svg/my-account.svg",
                                            href: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].account.path */ .Z.account.path
                                        }, 
                                    ],
                                    categories1: [
                                        {
                                            title: "Packages",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Benches",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Functional",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Cardio",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Machines",
                                            icon: "/svg/black-arrow.svg"
                                        },
                                        {
                                            title: "Weights",
                                            icon: "/svg/black-arrow.svg"
                                        }, 
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-center items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "xl:hidden",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/",
                                            passHref: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/header/logo.png",
                                                alt: "BodyKore Logo",
                                                className: "cursor-pointer",
                                                style: {
                                                    maxWidth: "170px",
                                                    height: "max-content"
                                                }
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-1/3 flex justify-end items-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "my-7 md:block lg:block xl:hidden",
                                        onClick: ()=>setCartSidebarOpen(true),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                            id: "Cart",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            width: "40",
                                            height: "40",
                                            viewBox: "0 0 40 40",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                                    id: "Rect\xe1ngulo_7",
                                                    "data-name": "Rect\xe1ngulo 7",
                                                    width: "40",
                                                    height: "40",
                                                    fill: "#fff",
                                                    opacity: "0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    id: "Icon_material-add-shopping-cart",
                                                    "data-name": "Icon material-add-shopping-cart",
                                                    d: "M11.421,9.119H13.4V6.262h2.976v-1.9H13.4V1.5H11.421V4.357H8.444v1.9h2.976ZM7.452,17.69a1.906,1.906,0,1,0,1.984,1.9A1.943,1.943,0,0,0,7.452,17.69Zm9.921,0a1.906,1.906,0,1,0,1.984,1.9A1.943,1.943,0,0,0,17.373,17.69ZM7.621,14.6l.03-.114.893-1.552h7.391a1.989,1.989,0,0,0,1.736-.981L21.5,5.271l-1.726-.914h-.01l-1.091,1.9-2.738,4.762H8.97l-.129-.257-2.222-4.5-.942-1.9-.933-1.9H1.5v1.9H3.484l3.571,7.229L5.716,13.919a1.784,1.784,0,0,0-.248.914,1.951,1.951,0,0,0,1.984,1.9h11.9v-1.9H7.869A.247.247,0,0,1,7.621,14.6Z",
                                                    transform: "translate(8.5 8.5)"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                    id: "numero",
                                                    transform: "translate(28)",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                            id: "Elipse_1",
                                                            "data-name": "Elipse 1",
                                                            cx: "6",
                                                            cy: "6",
                                                            r: "6",
                                                            fill: "#d33500"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("text", {
                                                            id: "_1",
                                                            "data-name": "1",
                                                            transform: "translate(5 8)",
                                                            fill: "#fff",
                                                            fontSize: "7",
                                                            fontFamily: "AcuminProExtraCond-Black, Acumin Pro ExtraCondensed",
                                                            fontWeight: "800",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tspan", {
                                                                x: "0",
                                                                y: "0",
                                                                children: cartItems.length
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9366:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MobileMenu)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _state_atoms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7239);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8768);
/* harmony import */ var _heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function MobileMenu({ search , categories , categories1 , links , linksImg  }) {
    const handleSubmit = (event)=>{
        event.preventDefault();
        const term = event.currentTarget.search.value;
        search(term);
    };
    const [sidebarOpen, setSidebarOpen] = (0,recoil__WEBPACK_IMPORTED_MODULE_2__.useRecoilState)(_state_atoms__WEBPACK_IMPORTED_MODULE_5__/* .menuSidebarOpenState */ .iy);
    const { 0: show , 1: setShow  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    const { 0: show1 , 1: setShow1  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Root, {
        show: sidebarOpen,
        as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog, {
            as: "div",
            className: "fixed inset-0 flex z-50 xl:hidden",
            onClose: setSidebarOpen,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                    as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                    enter: "transition-opacity ease-linear duration-300",
                    enterFrom: "opacity-0",
                    enterTo: "opacity-100",
                    leave: "transition-opacity ease-linear duration-300",
                    leaveFrom: "opacity-100",
                    leaveTo: "opacity-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog.Overlay, {
                        className: "fixed inset-0 bg-gray-600 bg-opacity-75"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                    as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                    enter: "transition ease-in-out duration-300 transform",
                    enterFrom: "-translate-x-full",
                    enterTo: "translate-x-0",
                    leave: "transition ease-in-out duration-300 transform",
                    leaveFrom: "translate-x-0",
                    leaveTo: "-translate-x-full",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative flex-1 flex flex-col max-w-sm w-full bg-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                                as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                                enter: "ease-in-out duration-300",
                                enterFrom: "opacity-0",
                                enterTo: "opacity-100",
                                leave: "ease-in-out duration-300",
                                leaveFrom: "opacity-100",
                                leaveTo: "opacity-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute top-0 right-0 -mr-12 pt-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        type: "button",
                                        className: "ml-1 flex items-center justify-center h-10 w-10 rounded-full",
                                        onClick: ()=>setSidebarOpen(false),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "sr-only",
                                                children: "Close sidebar"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_outline__WEBPACK_IMPORTED_MODULE_4__.XIcon, {
                                                className: "h-6 w-6 text-white",
                                                "aria-hidden": "true"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex-1 h-0 pt-5 pb-4 overflow-y-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex-shrink-0 flex items-center px-4 pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: "h-auto w-auto",
                                            style: {
                                                maxWidth: "180px"
                                            },
                                            src: "/header/logo.png",
                                            alt: "Logo BodyKore"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "h-3 bg-red-bc2026"
                                    }),
                                    show ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                                onSubmit: handleSubmit,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "input-group relative flex items-stretch w-full mb-4 rounded px-8 pt-5",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            id: "search",
                                                            type: "text",
                                                            className: "form-control relative flex-auto min-w-0 block w-full px-3 py-1.5 text-base font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none",
                                                            placeholder: "Search...",
                                                            required: true
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            type: "submit",
                                                            className: "input-group-text flex items-center px-3 py-1.5 text-base font-normal text-gray-700 text-center whitespace-nowrap rounded",
                                                            id: "basic-addon2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                "aria-hidden": "true",
                                                                focusable: "false",
                                                                "data-prefix": "fas",
                                                                "data-icon": "search",
                                                                className: "w-4",
                                                                role: "img",
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                viewBox: "0 0 512 512",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    fill: "currentColor",
                                                                    d: "M505 442.7L405.3 343c-4.5-4.5-10.6-7-17-7H372c27.6-35.3 44-79.7 44-128C416 93.1 322.9 0 208 0S0 93.1 0 208s93.1 208 208 208c48.3 0 92.7-16.4 128-44v16.3c0 6.4 2.5 12.5 7 17l99.7 99.7c9.4 9.4 24.6 9.4 33.9 0l28.3-28.3c9.4-9.4 9.4-24.6.1-34zM208 336c-70.7 0-128-57.2-128-128 0-70.7 57.2-128 128-128 70.7 0 128 57.2 128 128 0 70.7-57.2 128-128 128z"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                                                className: "mt-5 space-y-1 px-4",
                                                children: [
                                                    categories.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    onClick: ()=>{
                                                                        setShow(false);
                                                                        setShow1(true);
                                                                    },
                                                                    className: "group flex items-center px-2 py-2 text-base font-medium hover:text-red-bc2026 rounded-md",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex justify-between items-center w-full",
                                                                        children: [
                                                                            item.title,
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                src: item.icon,
                                                                                alt: "",
                                                                                className: "h-5 w-5"
                                                                            })
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "border-t border-gray-300 mt-2"
                                                                })
                                                            ]
                                                        }, i)),
                                                    links.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    href: item.href,
                                                                    className: "group flex items-center px-2 py-2 text-base font-medium hover:text-red-bc2026 rounded-md",
                                                                    children: item.title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "border-t border-gray-300 mt-2"
                                                                })
                                                            ]
                                                        }, i)),
                                                    linksImg.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    href: item.href,
                                                                    className: "group flex items-center px-2 py-2 text-base font-medium hover:text-red-bc2026 rounded-md",
                                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                        className: "flex items-center w-full",
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                                src: item.icon,
                                                                                alt: "",
                                                                                className: "h-8 w-8 mr-3"
                                                                            }),
                                                                            item.title
                                                                        ]
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "border-t border-gray-300 mt-2"
                                                                })
                                                            ]
                                                        }, i))
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center pt-10",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "bg-transparent text-black hover:text-red-bc2026 border border-black hover:border-red rounded-lg text-md px-16 py-2",
                                                    style: {
                                                        letterSpacing: "1.5px"
                                                    },
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex justify-center items-center",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                                xmlns: "http://www.w3.org/2000/svg",
                                                                className: "h-5 w-5",
                                                                fill: "none",
                                                                viewBox: "0 0 24 24",
                                                                stroke: "currentColor",
                                                                strokeWidth: "2",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                                    strokeLinecap: "round",
                                                                    strokeLinejoin: "round",
                                                                    d: "M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "px-2 text-sm font-medium",
                                                                children: "Call us"
                                                            })
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    }) : null,
                                    show1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                                        className: "mt-5 space-y-1 px-4",
                                        children: categories1.map((item, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "group flex items-center px-2 py-2 text-base font-medium hover:text-red-bc2026 rounded-md",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex justify-between items-center w-full",
                                                            children: [
                                                                item.title,
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                    src: item.icon,
                                                                    alt: "",
                                                                    className: "h-5 w-5"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "border-t border-gray-300 mt-2"
                                                    })
                                                ]
                                            }, i))
                                    }) : null
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-shrink-0 w-14"
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6308:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SingleCartItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_checkout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8576);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5003);
/* harmony import */ var state_atoms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7239);






// Changed option to indicate selected variant.
// Changed amount to indicate quantity in the cart,
// change the selector UI to a number input.
function SingleCartItem({ available , shippingDays , name , option , price , amount , image , lineId , cartId  }) {
    const setCartItems = (0,recoil__WEBPACK_IMPORTED_MODULE_2__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_3__/* .cartItemsState */ .uZ);
    const setCartTotal = (0,recoil__WEBPACK_IMPORTED_MODULE_2__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_3__/* .cartTotalState */ .jJ);
    const removeLine = async ()=>{
        const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_4__/* .removeItemFromCheckout */ .pw)(cartId, lineId);
        if (res.checkout !== undefined) {
            setCartItems((0,_utils_checkout__WEBPACK_IMPORTED_MODULE_5__/* .mapCheckout */ .e)(res.checkout));
            setCartTotal(res.checkout.subtotalPriceV2.amount);
        }
    };
    const updateLine = async (quantity)=>{
        if (quantity === 0) {
            // Dont allow 0 to avoid accidental removal,
            // as the item would disapear from the cart
            return;
        }
        const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_4__/* .updateQuantityCheckout */ .LD)(cartId, lineId, quantity);
        if (res.checkout !== undefined) {
            setCartItems((0,_utils_checkout__WEBPACK_IMPORTED_MODULE_5__/* .mapCheckout */ .e)(res.checkout));
            setCartTotal(res.checkout.subtotalPriceV2.amount);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex gap-4",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 justify-center items-center relative",
                    children: image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: image,
                        layout: "fill",
                        objectFit: "contain",
                        alt: ""
                    }) : null
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-1 flex flex-col justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "font-bold",
                                    children: name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xs",
                                    children: option !== "Default Title" ? option : null
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    className: "font-bold",
                                    children: [
                                        "$",
                                        price.toFixed(2)
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex gap-4",
                            children: [
                                available ? "" : "",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "In Stock"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-xs",
                                    children: "Quantity"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    className: "w-20 text-gray-700 py-1 px-4 pr-4 leading-tight",
                                    type: "number",
                                    min: "1",
                                    step: "1",
                                    onKeyPress: (event)=>{
                                        if (!/[0-9]/.test(event.key)) {
                                            event.preventDefault();
                                        }
                                    },
                                    defaultValue: amount,
                                    onChange: (event)=>{
                                        updateLine(+event.target.value);
                                    }
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: removeLine,
                                children: "Remove"
                            })
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 8181:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductsDD)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* This example requires Tailwind CSS v2.0+ */ 



function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function ProductsDD({ category , subCategories  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover, {
        className: "z-0",
        children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "z-10 bg-white",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-7xl mx-auto flex px-4 py-6 sm:px-6 lg:px-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Button, {
                                className: classNames(open ? "text-gray-900" : "text-gray-500", "group bg-white rounded-md inline-flex items-center text-base font-medium hover:text-gray-900 focus:outline-none"),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "hover:text-red-bc2026",
                                    children: category
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                        as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                        enter: "transition ease-out duration-200",
                        enterFrom: "opacity-0 -translate-y-1",
                        enterTo: "opacity-100 translate-y-0",
                        leave: "transition ease-in duration-150",
                        leaveFrom: "opacity-100 translate-y-0",
                        leaveTo: "opacity-0 -translate-y-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Panel, {
                            className: "absolute transform shadow-lg w-full left-0",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `max-w-7xl mx-auto flex justify-between gap-10 py-8`,
                                    children: subCategories.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                    href: item.slug,
                                                    passHref: true,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "text-md font-roboto font-bold text-gray-900 uppercase cursor-pointer",
                                                        children: item.name
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "py-3",
                                                    children: item.img ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        src: item.img,
                                                        height: 78,
                                                        width: 153
                                                    }) : null
                                                }),
                                                item.options.map((o, i)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-44 py-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: o.slug,
                                                            passHref: true,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "cursor-pointer hover:text-red-bc2026 font-medium text-sm",
                                                                children: o.text
                                                            })
                                                        })
                                                    }, i);
                                                })
                                            ]
                                        }, item.name))
                                })
                            })
                        })
                    })
                ]
            })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8763:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ResourcesDD)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1185);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_2__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* This example requires Tailwind CSS v2.0+ */ 


function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
}
function ResourcesDD({ category , subCategories  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover, {
        className: "z-0 relative",
        children: ({ open  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative z-10 bg-white",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "max-w-7xl mx-auto flex px-4 py-6 sm:px-6 lg:px-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Button, {
                                className: classNames(open ? "text-gray-900" : "text-gray-500", "group bg-white rounded-md inline-flex items-center text-base font-medium hover:text-gray-900 focus:outline-none"),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "hover:text-red-bc2026",
                                    children: category
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Transition, {
                        as: react__WEBPACK_IMPORTED_MODULE_1__.Fragment,
                        enter: "transition ease-out duration-200",
                        enterFrom: "opacity-0 -translate-y-1",
                        enterTo: "opacity-100 translate-y-0",
                        leave: "transition ease-in duration-150",
                        leaveFrom: "opacity-100 translate-y-0",
                        leaveTo: "opacity-0 -translate-y-1",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_2__.Popover.Panel, {
                            className: "absolute transform shadow-lg w-fit",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "bg-white",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `max-w-7xl mx-auto flex justify-between gap-10 px-10 py-8`,
                                    children: subCategories.map(([item])=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-base font-medium text-gray-900 uppercase pb-2",
                                                    children: item.name
                                                }),
                                                item.options.map((o, i)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-44 py-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: o.link,
                                                            passHref: true,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                target: `${o.newTab}`,
                                                                className: "cursor-pointer hover:text-red-bc2026 font-medium text-sm",
                                                                children: o.text
                                                            })
                                                        })
                                                    }, i);
                                                })
                                            ]
                                        }, item.name))
                                })
                            })
                        })
                    })
                ]
            })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2447:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SearchModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9641);
/* harmony import */ var _config_siteConfig__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5076);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4305);
/* harmony import */ var lodash_debounce__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_debounce__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5852);
/* harmony import */ var state_atoms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function SearchModal({ dynamicItems  }) {
    const [isOpen, setIsOpen] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_5__/* .searchOpenState */ .rn);
    const { 0: products , 1: setProducts  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const { 0: pages , 1: setPages  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    async function closeModal() {
        await new Promise((r)=>setTimeout(r, 200));
        setIsOpen(false);
        setProducts([]);
        setPages([]);
    }
    function openModal() {
        setIsOpen(true);
    }
    const searchContent = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const searchInput = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const iconOptions = {
        a: "M15.707 14.293v.001a1 1 0 01-1.414 1.414L11.185 12.6A6.935 6.935 0 017 14a7.016 7.016 0 01-5.173-2.308l-1.537 1.3L0 8l4.873 1.12-1.521 1.285a4.971 4.971 0 008.59-2.835l1.979.454a6.971 6.971 0 01-1.321 3.157l3.107 3.112zM14 6L9.127 4.88l1.521-1.28a4.971 4.971 0 00-8.59 2.83L.084 5.976a6.977 6.977 0 0112.089-3.668l1.537-1.3L14 6z",
        b: "M14 0H2c-.6 0-1 .4-1 1v14c0 .6.4 1 1 1h8l5-5V1c0-.6-.4-1-1-1zM3 2h10v8H9v4H3V2z"
    };
    const pageList = [];
    Object.keys(_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z).forEach((key)=>{
        const value = _config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z[key];
        if (!value.hidden) {
            const name = key.charAt(0).toUpperCase() + key.replace(/([A-Z])/g, " $1").trim().slice(1);
            pageList.push({
                name: name,
                link: value.path
            });
        }
    });
    pageList.push(...dynamicItems);
    const handleSearch = lodash_debounce__WEBPACK_IMPORTED_MODULE_2___default()(async (input)=>{
        if (input.length == 0) {
            setProducts([]);
            setPages([]);
        }
        if (input.length > 2) {
            const produtResults = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__/* .searchProducts */ .s3)(_config_siteConfig__WEBPACK_IMPORTED_MODULE_8__/* .NUM_SEARCH */ .fj, input);
            setProducts(produtResults.map((item)=>({
                    name: item.node.title,
                    link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}/${item.node.handle}`
                })));
            setPages(pageList.filter((item)=>item.name.toLowerCase().startsWith(input)));
        }
    }, 500);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition, {
            appear: true,
            show: isOpen,
            as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Dialog, {
                as: "div",
                className: "fixed inset-0 z-50 bg-gray-600 bg-opacity-75 overflow-hidden",
                onClose: closeModal,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "px-4 text-center",
                    onFocus: openModal,
                    onBlur: closeModal,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition.Child, {
                        as: react__WEBPACK_IMPORTED_MODULE_3__.Fragment,
                        enter: "ease-out duration-300",
                        enterFrom: "opacity-0 scale-95",
                        enterTo: "opacity-100 scale-100",
                        leave: "ease-in duration-200",
                        leaveFrom: "opacity-100 scale-100",
                        leaveTo: "opacity-0 scale-95",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-white overflow-auto max-w-2xl w-full max-h-full rounded shadow-lg m-auto mt-12",
                            ref: searchContent,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                    className: "border-b border-gray-200",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "modal-search",
                                                className: "sr-only",
                                                children: "Search"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                id: "modal-search",
                                                className: "w-full border-0 placeholder-gray-400 appearance-none py-3 pl-10 pr-4",
                                                type: "search",
                                                placeholder: "Search Anything\u2026",
                                                ref: searchInput,
                                                onInput: (event)=>handleSearch(event.currentTarget.value.trim().toLowerCase())
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "absolute inset-0 right-auto group",
                                                type: "submit",
                                                "aria-label": "Search",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                                    className: "w-4 h-4 flex-shrink-0 fill-current text-gray-400 group-hover:text-gray-500 ml-4 mr-2",
                                                    viewBox: "0 0 16 16",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M7 14c-3.86 0-7-3.14-7-7s3.14-7 7-7 7 3.14 7 7-3.14 7-7 7zM7 2C4.243 2 2 4.243 2 7s2.243 5 5 5 5-2.243 5-5-2.243-5-5-5z"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            d: "M15.707 14.293L13.314 11.9a8.019 8.019 0 01-1.414 1.414l2.393 2.393a.997.997 0 001.414 0 .999.999 0 000-1.414z"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "py-4 px-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchItems, {
                                            title: "Pages",
                                            icon: iconOptions.a,
                                            items: pages
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SearchItems, {
                                            title: "Products",
                                            icon: iconOptions.b,
                                            items: products
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            })
        })
    });
};
function SearchItems({ title , icon , items  }) {
    const mapItems = ()=>{
        return items.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: item.link,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        // Changed on hover color as the background is also white
                        className: "flex items-center p-2 text-gray-800 hover:text-gray-500 hover:bg-blue-500 rounded group",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "w-4 h-4 fill-current text-gray-400 hover:text-gray-500 group-hover:text-opacity-50 flex-shrink-0 mr-3",
                                viewBox: "0 0 16 16",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: icon
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: item.name
                            })
                        ]
                    })
                })
            }, index));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mb-3 last:mb-0",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-xs font-semibold text-gray-400 uppercase px-2 mb-2",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "text-sm",
                children: mapItems()
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9641:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const routes = {
    home: {
        path: "/"
    },
    account: {
        path: "https://localhost:3000/account/login"
    },
    blog: {
        path: "/blog"
    },
    portfolio: {
        path: "/portfolio"
    },
    products: {
        path: "/products"
    },
    collection: {
        hidden: true,
        path: "/product-category"
    },
    manuals: {
        path: "/manuals"
    },
    about: {
        path: "/about"
    },
    ambassadors: {
        path: "/ambassadors"
    },
    loyaltyProgram: {
        path: "/loyaltyProgram"
    },
    videos: {
        path: "/videos"
    },
    gymSolutions: {
        path: "/gymSolutions"
    },
    financing: {
        path: "/finance"
    },
    warranty: {
        path: "/warranty"
    },
    returnPolicy: {
        path: "/returnPolicy"
    },
    stores: {
        path: "/storeLocator"
    },
    contact: {
        path: "/contact"
    },
    api: {
        hidden: true,
        path: "/api",
        wishlist: {
            path: "/api/wishlist"
        },
        coordinates: {
            path: "/api/coordinates"
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (routes);


/***/ }),

/***/ 5076:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gr": () => (/* binding */ NUM_ARTICLES),
/* harmony export */   "MU": () => (/* binding */ NUM_TOP_PRODUCTS),
/* harmony export */   "fj": () => (/* binding */ NUM_SEARCH),
/* harmony export */   "sL": () => (/* binding */ NUM_PROJECTS),
/* harmony export */   "tP": () => (/* binding */ NUM_PRODUCTS),
/* harmony export */   "uA": () => (/* binding */ NUM_FEATURED)
/* harmony export */ });
const NUM_ARTICLES = 12;
const NUM_PROJECTS = 3;
const NUM_FEATURED = 3;
const NUM_PRODUCTS = 12;
const NUM_SEARCH = 6;
const NUM_TOP_PRODUCTS = 4;


/***/ }),

/***/ 1061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getGraphcms)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

let graphcms;
function getGraphcms() {
    if (!graphcms) {
        graphcms = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient(process.env.GRAPHCMS_ENDPOINT, {
            headers: {
                Authorization: `Bearer ${process.env.GRAPHCMS_ACCESS_TOKEN}`
            }
        });
        return graphcms;
    }
    return graphcms;
};


/***/ }),

/***/ 2780:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d5": () => (/* binding */ getCMSCollectionPage),
/* harmony export */   "kI": () => (/* binding */ getAllCategoriesSlug),
/* harmony export */   "so": () => (/* binding */ getTypesOf)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getTypesOf = async (slug)=>{
    // console.log('services', slug);
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query TypesOf($slug: String!) {
      category(where: { slug: $slug }) {
        subcaterogies {
          name
        }
      }
    }
  `;
    const variables = {
        slug
    };
    // console.log('services', slug, query)
    const res = await graphcms.request(query, variables);
    return res.category?.subcategories || [];
};
const getAllCategoriesSlug = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProductCategories {
      categories {
        slug
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.categories;
};
const getCMSCollectionPage = async (slug)=>{
    // console.log('serives 1', slug);
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query CollectionPage($slug: String!) {
      category(where: { slug: $slug }) {
        cover {
          url
        }
        discover {
          url
        }
        feature {
          description
          image {
            url
          }
        }
        subcaterogies {
          name
          image {
            url
          }
        }
      }
      projectCategories {
        title
        projects(first: 1, orderBy: publishedAt_DESC) {
          slug
          image() {
            url
          }
        }
      }
    }
  `;
    const variables = {
        slug
    };
    // console.log('query', query);
    const res = await graphcms.request(query, variables);
    return res;
};


/***/ }),

/***/ 5003:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LD": () => (/* binding */ updateQuantityCheckout),
/* harmony export */   "Om": () => (/* binding */ getCheckout),
/* harmony export */   "Vx": () => (/* binding */ addItemToCheckout),
/* harmony export */   "Yj": () => (/* binding */ updateCheckoutEmail),
/* harmony export */   "_R": () => (/* binding */ createCheckout),
/* harmony export */   "pw": () => (/* binding */ removeItemFromCheckout)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);


const storefront = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
/**
 * Checkouts last for 3 months if not completed before.
 */ const createCheckout = async (variantId, email)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation checkoutCreate($input: CheckoutCreateInput!) {
      checkoutCreate(input: $input) {
        checkout {
          id
          email
          subtotalPriceV2 {
            amount
          }
          webUrl
          lineItems(first: 100) {
            edges {
              node {
                id
                quantity
                variant {
                  id
                  availableForSale
                  title
                  product {
                    title
                    featuredImage {
                      url
                    }
                  }
                  priceV2 {
                    amount
                  }
                }
              }
            }
          }
        }
        checkoutUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        input: {
            email,
            lineItems: {
                variantId,
                quantity: 1
            }
        }
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.checkoutCreate;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            checkoutUserErrors: []
        };
    }
};
const getCheckout = async (checkoutId)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query getCheckout($checkoutId: ID!) {
      node(id: $checkoutId) {
        ... on Checkout {
          id
          email
          subtotalPriceV2 {
            amount
          }
          webUrl
          lineItems(first: 100) {
            edges {
              node {
                id
                quantity
                variant {
                  id
                  availableForSale
                  title
                  product {
                    title
                    featuredImage {
                      url
                    }
                  }
                  priceV2 {
                    amount
                  }
                }
              }
            }
          }
        }
      }
    }
  `;
    const variables = {
        checkoutId
    };
    try {
        const res = await storefront.request(query, variables);
        return res.node === null ? undefined : res.node;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
    }
};
const updateCheckoutEmail = async (checkoutId, email)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation checkoutEmailUpdateV2($checkoutId: ID!, $email: String!) {
      checkoutEmailUpdateV2(checkoutId: $checkoutId, email: $email) {
        checkout {
          id
          email
        }
        checkoutUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        checkoutId,
        email
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.checkoutEmailUpdateV2.checkout !== null && res.checkoutEmailUpdateV2.checkoutUserErrors === [];
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return false;
    }
};
const addItemToCheckout = async (checkoutId, variantId)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation checkoutLineItemsAdd(
      $checkoutId: ID!
      $lineItems: [CheckoutLineItemInput!]!
    ) {
      checkoutLineItemsAdd(checkoutId: $checkoutId, lineItems: $lineItems) {
        checkout {
          id
          email
          subtotalPriceV2 {
            amount
          }
          webUrl
          lineItems(first: 100) {
            edges {
              node {
                id
                quantity
                variant {
                  id
                  availableForSale
                  title
                  product {
                    title
                    featuredImage {
                      url
                    }
                  }
                  priceV2 {
                    amount
                  }
                }
              }
            }
          }
        }
        checkoutUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        checkoutId,
        lineItems: [
            {
                variantId,
                quantity: 1
            }, 
        ]
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.checkoutLineItemsAdd;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            checkoutUserErrors: []
        };
    }
};
const removeItemFromCheckout = async (checkoutId, lineId)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation checkoutLineItemsRemove($checkoutId: ID!, $lineItemIds: [ID!]!) {
      checkoutLineItemsRemove(
        checkoutId: $checkoutId
        lineItemIds: $lineItemIds
      ) {
        checkout {
          id
          email
          subtotalPriceV2 {
            amount
          }
          webUrl
          lineItems(first: 100) {
            edges {
              node {
                id
                quantity
                variant {
                  id
                  availableForSale
                  title
                  product {
                    title
                    featuredImage {
                      url
                    }
                  }
                  priceV2 {
                    amount
                  }
                }
              }
            }
          }
        }
        checkoutUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        checkoutId,
        lineItemIds: [
            lineId
        ]
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.checkoutLineItemsRemove;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            checkoutUserErrors: []
        };
    }
};
const updateQuantityCheckout = async (checkoutId, lineId, quantity)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation checkoutLineItemsUpdate(
      $checkoutId: ID!
      $lineItems: [CheckoutLineItemUpdateInput!]!
    ) {
      checkoutLineItemsUpdate(checkoutId: $checkoutId, lineItems: $lineItems) {
        checkout {
          id
          email
          subtotalPriceV2 {
            amount
          }
          webUrl
          lineItems(first: 100) {
            edges {
              node {
                id
                quantity
                variant {
                  id
                  availableForSale
                  title
                  product {
                    title
                    featuredImage {
                      url
                    }
                  }
                  priceV2 {
                    amount
                  }
                }
              }
            }
          }
        }
        checkoutUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        checkoutId,
        lineItems: [
            {
                quantity,
                id: lineId
            }, 
        ]
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.checkoutLineItemsUpdate;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            checkoutUserErrors: []
        };
    }
};


/***/ }),

/***/ 5841:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ getStorefront)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);

let graphcms;
function getStorefront() {
    if (!graphcms) {
        graphcms = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient("https://bodykore-store.myshopify.com/api/2022-01/graphql.json", {
            headers: {
                "Content-Type": "application/json",
                "X-Shopify-Storefront-Access-Token": "564fcac3455c50fb3902b13b8bb6e315"
            }
        });
        return graphcms;
    }
    return graphcms;
};


/***/ }),

/***/ 5852:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B2": () => (/* binding */ getShopifyCollectionPage),
/* harmony export */   "Dg": () => (/* binding */ getAllProducts),
/* harmony export */   "KV": () => (/* binding */ getCollectionsHeader),
/* harmony export */   "Kk": () => (/* binding */ getCountOfAllProducts),
/* harmony export */   "PE": () => (/* binding */ Sort),
/* harmony export */   "V_": () => (/* binding */ getProductsOfCollection),
/* harmony export */   "_s": () => (/* binding */ getAllProductsSlug),
/* harmony export */   "rE": () => (/* binding */ getProductCard),
/* harmony export */   "s3": () => (/* binding */ searchProducts),
/* harmony export */   "ue": () => (/* binding */ getCountOfProductsOfCollection),
/* harmony export */   "vp": () => (/* binding */ getProductRecommendations),
/* harmony export */   "wv": () => (/* binding */ getProduct)
/* harmony export */ });
/* unused harmony exports getProductsWithTitle, getProductCollections */
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);


const storefront = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
var Sort;
(function(Sort) {
    Sort[Sort["TitleAsc"] = 0] = "TitleAsc";
    Sort[Sort["TitleDesc"] = 1] = "TitleDesc";
    Sort[Sort["PriceAsc"] = 2] = "PriceAsc";
    Sort[Sort["PriceDesc"] = 3] = "PriceDesc";
    Sort[Sort["BestSelling"] = 4] = "BestSelling";
})(Sort || (Sort = {}));
const getAllProducts = async (numProducts, cursor, { title , type , tag , minPrice , maxPrice  } = {}, sort)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllProducts(
      $numProducts: Int!
      $cursor: String
      $query: String
      $sortKey: ProductSortKeys
      $reverse: Boolean
    ) {
      products(
        first: $numProducts
        after: $cursor
        query: $query
        sortKey: $sortKey
        reverse: $reverse
      ) {
        pageInfo {
          hasPreviousPage
          hasNextPage
        }
        edges {
          cursor
          node {
            id
            handle
            title
            description
            availableForSale
            featuredImage {
              url
              height
              width
            }
            variants(first: 1) {
              edges {
                node {
                  id
                  priceV2 {
                    amount
                    currencyCode
                  }
                  compareAtPriceV2 {
                    amount
                    currencyCode
                  }
                }
              }
            }
          }
        }
      }
    }
  `;
    let filters = "";
    if (title !== undefined) {
        filters += `title:${title}* `;
    }
    if (type !== undefined) {
        filters += `product_type:${type} `;
    }
    if (tag !== undefined) {
        filters += `tag:${tag} `;
    }
    if (minPrice !== undefined) {
        filters += `variants.price:>=${minPrice.toFixed(2)} `;
    }
    if (maxPrice !== undefined) {
        filters += `variants.price:<=${maxPrice.toFixed(2)} `;
    }
    let sortKey, reverse;
    switch(sort){
        case Sort.TitleAsc:
            reverse = false;
            sortKey = "TITLE";
            break;
        case Sort.TitleDesc:
            reverse = true;
            sortKey = "TITLE";
            break;
        case Sort.PriceAsc:
            reverse = false;
            sortKey = "PRICE";
            break;
        case Sort.PriceDesc:
            reverse = true;
            sortKey = "PRICE";
            break;
        case Sort.BestSelling:
            reverse = false;
            sortKey = "BEST_SELLING";
            break;
        default:
            break;
    }
    const variables = {
        numProducts,
        cursor,
        query: filters !== "" ? filters : undefined,
        sortKey,
        reverse
    };
    const res = await storefront.request(query, variables);
    return res.products;
};
const getCountOfAllProducts = async ({ title , type , tag , minPrice , maxPrice  } = {})=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllProducts($query: String) {
      products(first: 250, query: $query) {
        edges {
          node {
            handle
          }
        }
      }
    }
  `;
    let filters = "";
    if (title !== undefined) {
        filters += `title:${title}* `;
    }
    if (type !== undefined) {
        filters += `product_type:${type} `;
    }
    if (tag !== undefined) {
        filters += `tag:${tag} `;
    }
    if (minPrice !== undefined) {
        filters += `variants.price:>=${minPrice.toFixed(2)} `;
    }
    if (maxPrice !== undefined) {
        filters += `variants.price:<=${maxPrice.toFixed(2)} `;
    }
    const variables = {
        query: filters !== "" ? filters : undefined
    };
    const res = await storefront.request(query, variables);
    return res.products.edges.length;
};
const getAllProductsSlug = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllProductsSlug {
      products(first: 100) {
        edges {
          node {
            handle
          }
        }
      }
    }
  `;
    const res = await storefront.request(query);
    return res.products.edges;
};
/**
 * Unlike allProducts, it can only filter by price.
 * @param handle
 * @param numProducts
 * @param cursor
 * @param param3
 * @param sort
 * @returns
 */ const getProductsOfCollection = async (handle, numProducts, cursor, { minPrice , maxPrice  } = {}, sort)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProductsOfCollection(
      $handle: String!
      $numProducts: Int!
      $cursor: String
      $filters: [ProductFilter!]
      $sortKey: ProductCollectionSortKeys
      $reverse: Boolean
    ) {
      collection(handle: $handle) {
        products(
          first: $numProducts
          after: $cursor
          filters: $filters
          sortKey: $sortKey
          reverse: $reverse
        ) {
          pageInfo {
            hasPreviousPage
            hasNextPage
          }
          edges {
            cursor
            node {
              id
              handle
              title
              description
              availableForSale
              featuredImage {
                url
                height
                width
              }
              variants(first: 1) {
                edges {
                  node {
                    id
                    priceV2 {
                      amount
                      currencyCode
                    }
                    compareAtPriceV2 {
                      amount
                      currencyCode
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  `;
    let sortKey, reverse;
    switch(sort){
        case Sort.TitleAsc:
            reverse = false;
            sortKey = "TITLE";
            break;
        case Sort.TitleDesc:
            reverse = true;
            sortKey = "TITLE";
            break;
        case Sort.PriceAsc:
            reverse = false;
            sortKey = "PRICE";
            break;
        case Sort.PriceDesc:
            reverse = true;
            sortKey = "PRICE";
            break;
        case Sort.BestSelling:
            reverse = false;
            sortKey = "BEST_SELLING";
            break;
        default:
            break;
    }
    const filters = [
        {
            price: {
                min: minPrice,
                max: maxPrice
            }
        }, 
    ];
    const variables = {
        handle,
        numProducts,
        cursor,
        filters,
        sortKey,
        reverse
    };
    const res = await storefront.request(query, variables);
    return res.collection.products;
};
const getCountOfProductsOfCollection = async (handle, { minPrice , maxPrice  } = {})=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProductsOfCollection($handle: String!, $filters: [ProductFilter!]) {
      collection(handle: $handle) {
        products(first: 250, filters: $filters) {
          edges {
            node {
              handle
            }
          }
        }
      }
    }
  `;
    const filters = [
        {
            price: {
                min: minPrice,
                max: maxPrice
            }
        }, 
    ];
    const variables = {
        handle,
        query: filters
    };
    const res = await storefront.request(query, variables);
    return res.collection.products.edges.length;
};
const getProductsWithTitle = async (term)=>{
    const query = gql`
    query ProductsWithTitle($query: String!) {
      products(first: 10, query: $query) {
        edges {
          node {
            id
            title
            handle
            productType
          }
        }
      }
    }
  `;
    const variables = {
        query: `title:*${term}*`
    };
    const res = await storefront.request(query, variables);
    return res.products;
};
const getProduct = async (handle)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query SingleProduct($handle: String!) {
      product(handle: $handle) {
        id
        handle
        title
        availableForSale
        description
        images(first: 10) {
          edges {
            node {
              url
              height
              width
            }
          }
        }
        collections(first: 1) {
          edges {
            node {
              title
              handle
            }
          }
        }
        productType
        descSummary: metafield(
          namespace: "global"
          key: "Description-Summary"
        ) {
          value
        }
        descFeatures: metafield(
          namespace: "global"
          key: "Description-Features"
        ) {
          value
        }
        descImage: metafield(namespace: "global", key: "Description-Image") {
          value
        }
        highList: metafield(namespace: "global", key: "Highlights-List") {
          value
        }
        highImages: metafield(namespace: "global", key: "Highlights-Images") {
          value
        }
        keyFactor: metafield(
          namespace: "global"
          key: "Key-Factor-Perfomance"
        ) {
          value
        }
        specList: metafield(namespace: "global", key: "Specification-List") {
          value
        }
        specImages: metafield(
          namespace: "global"
          key: "Specification-Images"
        ) {
          value
        }
        variants(first: 100) {
          edges {
            node {
              id
              title
              availableForSale
              image {
                url
              }
              priceV2 {
                amount
                currencyCode
              }
              compareAtPriceV2 {
                amount
                currencyCode
              }
            }
          }
        }
      }
    }
  `;
    const variables = {
        handle
    };
    const res = await storefront.request(query, variables);
    return res?.product === null ? undefined : res.product;
};
const getProductCard = async (handle)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query SingleProductCard($handle: String!) {
      product(handle: $handle) {
        id
        handle
        title
        description
        availableForSale
        featuredImage {
          url
          height
          width
        }
        variants(first: 1) {
          edges {
            node {
              id
              priceV2 {
                amount
                currencyCode
              }
              compareAtPriceV2 {
                amount
                currencyCode
              }
            }
          }
        }
      }
    }
  `;
    const variables = {
        handle
    };
    const res = await storefront.request(query, variables);
    return res?.product === null ? undefined : res.product;
};
/**
 * Returns a maximum of 10 products, but it may also be empty.
 * @param productId
 * @returns
 */ const getProductRecommendations = async (productId)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ProductRecommendations($productId: ID!) {
      productRecommendations(productId: $productId) {
        id
        handle
        title
        description
        availableForSale
        featuredImage {
          url
          height
          width
        }
        variants(first: 1) {
          edges {
            node {
              id
              priceV2 {
                amount
                currencyCode
              }
              compareAtPriceV2 {
                amount
                currencyCode
              }
            }
          }
        }
      }
    }
  `;
    const variables = {
        productId
    };
    const res = await storefront.request(query, variables);
    return res.productRecommendations;
};
const getProductCollections = async ()=>{
    const query = gql`
    query ProductCollections {
      collections(first: 100) {
        edges {
          node {
            title
            handle
            products(first: 10) {
              edges {
                node {
                  productType
                }
              }
            }
          }
        }
      }
    }
  `;
    const res = await storefront.request(query);
    return res.collections.edges;
};
const searchProducts = async (numProducts, term)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query SearchProducts($numProducts: Int!, $query: String) {
      products(first: $numProducts, query: $query) {
        edges {
          node {
            handle
            title
          }
        }
      }
    }
  `;
    const variables = {
        numProducts,
        query: term
    };
    try {
        const res = await storefront.request(query, variables);
        return res.products.edges;
    } catch (error) {
        console.error(error);
        return [];
    }
};
const getCollectionsHeader = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query CollectionsHeader {
      collections(first: 100) {
        edges {
          node {
            title
            handle
            image {
              url
            }
          }
        }
      }
      collection(handle: "packages") {
        products(first: 6, sortKey: BEST_SELLING) {
          edges {
            node {
              title
              handle
            }
          }
        }
      }
    }
  `;
    const res = await storefront.request(query);
    return res;
};
const getShopifyCollectionPage = async (handle)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query CollectionPage($handle: String!) {
      collection(handle: $handle) {
        title
        description
        products(first: 4, sortKey: BEST_SELLING) {
          edges {
            node {
              id
              handle
              title
              description
              availableForSale
              metafield(namespace: "global", key: "Bundle-Items") {
                value
              }
              featuredImage {
                url
                height
                width
              }
              variants(first: 1) {
                edges {
                  node {
                    id
                    priceV2 {
                      amount
                      currencyCode
                    }
                    compareAtPriceV2 {
                      amount
                      currencyCode
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  `;
    const variables = {
        handle
    };
    const res = await storefront.request(query, variables);
    return res.collection || undefined;
};


/***/ }),

/***/ 7239:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Dy": () => (/* binding */ cartSidebarOpenState),
/* harmony export */   "g0": () => (/* binding */ checkoutUrlState),
/* harmony export */   "iy": () => (/* binding */ menuSidebarOpenState),
/* harmony export */   "jJ": () => (/* binding */ cartTotalState),
/* harmony export */   "rn": () => (/* binding */ searchOpenState),
/* harmony export */   "uZ": () => (/* binding */ cartItemsState)
/* harmony export */ });
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);

const menuSidebarOpenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "menuSidebarOpen",
    default: false
});
const cartSidebarOpenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "cartSidebarOpen",
    default: false
});
const searchOpenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "searchOpen",
    default: false
});
const cartItemsState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "cartItems",
    default: []
});
const checkoutUrlState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "checkoutUrl",
    default: undefined
});
const cartTotalState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({
    key: "cartTotal",
    default: undefined
});


/***/ }),

/***/ 8576:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ mapCheckout)
/* harmony export */ });
const mapCheckout = (checkout)=>{
    const res = checkout.lineItems.edges.map((item)=>({
            name: item.node.variant.product.title,
            amount: item.node.quantity,
            available: item.node.variant.availableForSale,
            option: item.node.variant.title,
            price: +item.node.variant.priceV2.amount * item.node.quantity,
            image: item.node.variant.product.featuredImage?.url,
            lineId: item.node.id,
            cartId: checkout.id
        }));
    return res;
};


/***/ }),

/***/ 4725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "P": () => (/* binding */ getHeader)
});

// EXTERNAL MODULE: external "graphql-request"
var external_graphql_request_ = __webpack_require__(5805);
// EXTERNAL MODULE: ./services/graphCMS/config.ts
var config = __webpack_require__(1061);
;// CONCATENATED MODULE: ./services/graphCMS/search.ts


const graphcms = (0,config/* default */.Z)();
const getSearchItems = async ()=>{
    const query = external_graphql_request_.gql`
    query Search {
      projects {
        title
        slug
      }
      articles {
        title
        slug
      }
    }
  `;
    const res = await graphcms.request(query);
    return res;
};

// EXTERNAL MODULE: ./services/graphCMS/product.ts
var product = __webpack_require__(2780);
// EXTERNAL MODULE: ./services/shopify/storefront/product.ts
var storefront_product = __webpack_require__(5852);
;// CONCATENATED MODULE: ./utils/header.ts


const getHeader = async ()=>{
    const res = await (0,storefront_product/* getCollectionsHeader */.KV)();
    const headerCat = res.collections.edges;
    // We put the packages collection first
    headerCat.sort((a, b)=>a.node.handle === "packages" ? -1 : b.node.handle === "packages" ? 1 : 0);
    const categories = await Promise.all(headerCat.map(async (item)=>{
        let subcategories;
        if (item.node.handle == "packages") {
            subcategories = res.collection.products.edges.map((item)=>({
                    name: item.node.title,
                    slug: item.node.handle
                }));
        } else {
            subcategories = await (0,product/* getTypesOf */.so)(item.node.handle);
        }
        return {
            title: item.node.title,
            slug: item.node.handle,
            image: item.node.image.url,
            subcategories: subcategories
        };
    }));
    const pages = await getSearchItems();
    return {
        categories,
        pages
    };
};


/***/ })

};
;