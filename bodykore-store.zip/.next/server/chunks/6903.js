"use strict";
exports.id = 6903;
exports.ids = [6903];
exports.modules = {

/***/ 6903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8702);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);





const SliderProgress = ({ title1 , title2 , color1 , color2 , description , btnText , bgImage , id , link , gap , width , textPosition , pb  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        id: id,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `flex flex-row flex-wrap justify-center items-center max-w-7xl pt-6 m-auto lg:px-32 ${gap} pb-5`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `flex ${width} ${textPosition}`,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${color2} text-4xl lg:text-5xl font-bebas font-bold italic`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `${color1} text-4xl lg:text-5xl font-bebas font-bold italic pr-2`,
                                    children: title1
                                }),
                                title2
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `h-12 flex justify-end ${width}`,
                        children: btnText !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: link || "#",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "border uppercase border-black rounded-lg px-8 md:px-16 font-bebas font-bold text-black-373933 hover:border-red-bc2026 hover:text-red-bc2026",
                                style: {
                                    letterSpacing: "1.5px"
                                },
                                children: btnText
                            })
                        }) : null
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: `font-roboto text-black-1c2023 lg:w-2/3 text-center lg:text-left ${pb}`,
                children: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full max-w-7xl m-auto pb-28",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__.Splide, {
                    ref: sliderRef,
                    options: {
                        pagination: false,
                        gap: "1rem",
                        type: "loop",
                        width: "100%",
                        autoWidth: false,
                        autoplay: false
                    },
                    renderControls: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex justify-center pt-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "slider-progress",
                                style: {
                                    width: "563px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "slider-progress-bar"
                                })
                            })
                        }),
                    onMoved: (splide)=>{
                        // Update the bar width. CSS is found on components.css
                        const end = splide.Components.Controller.getEnd() + 1;
                        const bar = sliderRef.current.splideRef.current.getElementsByClassName("slider-progress-bar")[0];
                        bar.style.width = String(100 * (splide.index + 1) / end) + "%";
                    },
                    children: bgImage.map((b, i)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_2__.SplideSlide, {
                            className: "flex justify-center items-start",
                            children: b.link !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: b.link,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `bg-no-repeat bg-center bg-cover cursor-pointer w-full lg:w-10/12`,
                                    style: {
                                        backgroundImage: `url('${b.url}')`,
                                        height: "550px"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `flex justify-center items-end bg-black bg-opacity-25`,
                                        style: {
                                            height: "550px"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "cursor-pointer w-4/6 text-4xl lg:text-5xl font-bebas italic font-bold absolute text-white pb-8 lg:pb-16 text-left",
                                            style: {
                                                letterSpacing: "1px"
                                            },
                                            children: b.title
                                        })
                                    })
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `bg-no-repeat bg-center bg-cover w-full lg:w-10/12`,
                                style: {
                                    backgroundImage: `url('${b.url}')`,
                                    height: "550px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `flex justify-center items-end bg-black bg-opacity-25`,
                                    style: {
                                        height: "550px"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "cursor-pointer w-4/6 text-4xl lg:text-5xl font-bebas italic font-bold absolute text-white pb-8 lg:pb-16 text-left",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: b.title
                                    })
                                })
                            })
                        }, i);
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliderProgress);


/***/ })

};
;