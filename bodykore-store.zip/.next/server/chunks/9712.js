"use strict";
exports.id = 9712;
exports.ids = [9712];
exports.modules = {

/***/ 9712:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h_": () => (/* binding */ createCustomerToken),
/* harmony export */   "wK": () => (/* binding */ createCustomer)
/* harmony export */ });
/* unused harmony exports recoverCustomerPassword, getCustomerOrders, getCustomerId */
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5841);


const storefront = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const createCustomer = async (email, password, firstName, lastName, phone, acceptsMarketing)=>{
    const mutation = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation CustomerCreate($input: CustomerCreateInput!) {
      customerCreate(input: $input) {
        customerUserErrors {
          code
          field
          message
        }
        customer {
          id
        }
      }
    }
  `;
    const variables = {
        input: {
            email,
            password,
            firstName,
            lastName,
            phone,
            acceptsMarketing
        }
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.customerCreate;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            customerUserErrors: []
        };
    }
};
const createCustomerToken = async (email, password)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    mutation customerAccessTokenCreate(
      $input: CustomerAccessTokenCreateInput!
    ) {
      customerAccessTokenCreate(input: $input) {
        customerUserErrors {
          code
          field
          message
        }
        customerAccessToken {
          accessToken
          expiresAt
        }
      }
    }
  `;
    const variables = {
        input: {
            email,
            password
        }
    };
    try {
        const res = await storefront.request(query, variables);
        return res.customerAccessTokenCreate;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            customerUserErrors: []
        };
    }
};
const recoverCustomerPassword = async (email)=>{
    const mutation = gql`
    mutation customerRecover($email: String!) {
      customerRecover(email: $email) {
        customerUserErrors {
          code
          field
          message
        }
      }
    }
  `;
    const variables = {
        email
    };
    try {
        const res = await storefront.request(mutation, variables);
        return res.customerRecover;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            customerUserErrors: []
        };
    }
};
const getCustomerOrders = async (customerAccessToken)=>{
    const query = gql`
    query Orders($customerAccessToken: String!) {
      customer(customerAccessToken: $customerAccessToken) {
        orders(first: 10) {
          edges {
            node {
              id
            }
          }
        }
      }
    }
  `;
    const variables = {
        customerAccessToken
    };
    try {
        const res = await storefront.request(query, variables);
        return res.customer === null ? [] : res.customer.orders.edges;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return [];
    }
};
const getCustomerId = async (customerAccessToken)=>{
    const query = gql`
    query CustomerID($customerAccessToken: String!) {
      customer(customerAccessToken: $customerAccessToken) {
        id
      }
    }
  `;
    const variables = {
        customerAccessToken
    };
    try {
        const res = await storefront.request(query, variables);
        return res.customer === null ? undefined : res.customer.id;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return undefined;
    }
};


/***/ })

};
;