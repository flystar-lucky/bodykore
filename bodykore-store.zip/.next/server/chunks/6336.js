"use strict";
exports.id = 6336;
exports.ids = [6336];
exports.modules = {

/***/ 4488:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BlogCards)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9641);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);



function BlogCards({ mainTitle , card  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-w-7xl m-auto pt-16",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-wrap justify-center gap-6",
                children: card.map((c, i)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-white",
                            style: {
                                width: "348px"
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: `${_config_routes__WEBPACK_IMPORTED_MODULE_2__/* ["default"].blog.path */ .Z.blog.path}/${c.slug}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `flex justify-between bg-no-repeat bg-center h-64 bg-cover pb-2`,
                                        children: c.img ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: c.img,
                                            width: "348",
                                            height: "256"
                                        }) : null
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between py-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-grey-8C8C8C font-bebas text-lg font-bold italic",
                                            style: {
                                                letterSpacing: "0.5px"
                                            },
                                            children: c.topic
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-grey-8C8C8C font-roboto text-sm",
                                            style: {
                                                letterSpacing: "0.5px"
                                            },
                                            children: c.date
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-black-1c2023 font-bebas text-2xl font-bold italic",
                                    style: {
                                        letterSpacing: "0.5px"
                                    },
                                    children: c.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-black-1c2023 font-roboto text-sm py-2",
                                    children: c.description
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: `${_config_routes__WEBPACK_IMPORTED_MODULE_2__/* ["default"].blog.path */ .Z.blog.path}/${c.slug}`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "text-sm text-red-bc2026 font-roboto pr-3",
                                                children: "Read more"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                xmlns: "http://www.w3.org/2000/svg",
                                                width: "12.885",
                                                height: "8.525",
                                                viewBox: "0 0 12.885 8.525",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    id: "Vector_7",
                                                    "data-name": "Vector 7",
                                                    d: "M0,3.343H11.316m0,0L7.972,0m3.343,3.343L7.972,6.687",
                                                    transform: "translate(0.65 0.919)",
                                                    fill: "none",
                                                    stroke: "#bc2026",
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: "1.3"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }, i);
                })
            })
        })
    });
};


/***/ }),

/***/ 7858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Blacktitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Blacktitle({ title , textSize , textColor , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center lg:justify-start",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: `${textColor} ${textSize} font-bebas font-bold italic text-center md:text-left`,
                    children: title
                })
            })
        })
    });
};


/***/ }),

/***/ 2247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Um": () => (/* binding */ getArticleCategories),
/* harmony export */   "fq": () => (/* binding */ getArticle),
/* harmony export */   "mz": () => (/* binding */ getAllArticlesSlug),
/* harmony export */   "zC": () => (/* binding */ getAllArticles)
/* harmony export */ });
/* unused harmony export getArticlesOfCategory */
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getAllArticles = async (first)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllArticles($first: Int) {
      articles(first: $first) {
        slug
        title
        description
        image {
          url
        }
        category {
          title
          slug
        }
        date
        readTime
      }
    }
  `;
    const variables = {
        first
    };
    const res = await graphcms.request(query, variables);
    return res.articles;
};
const getAllArticlesSlug = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllArticlesSlug {
      articles {
        slug
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.articles;
};
const getArticle = async (slug)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query Article($slug: String!) {
      article(where: { slug: $slug }) {
        title
        image {
          url
        }
        category {
          title
        }
        date
        readTime
        content {
          html
        }
      }
    }
  `;
    const variables = {
        slug
    };
    const res = await graphcms.request(query, variables);
    return res.article === null ? undefined : res.article;
};
const getArticleCategories = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ArticleCategories {
      articleCategories {
        slug
        title
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.articleCategories;
};
const getArticlesOfCategory = async (slug)=>{
    const query = gql`
    query ArticlesOfCategory($slug: String!) {
      articleCategory(where: { slug: $slug }) {
        articles {
          slug
          title
          image {
            url
          }
          category {
            title
          }
          date
          readTime
        }
      }
    }
  `;
    const variables = {
        slug
    };
    const res = await graphcms.request(query, variables);
    return res.articleCategory === null ? [] : res.articleCategory.articles;
};


/***/ }),

/***/ 1223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ dateFormat)
/* harmony export */ });
function dateFormat(dateISO) {
    const [y, m, d] = dateISO.split("-");
    const tmp = new Date(+y, +m - 1, +d);
    const day = new Intl.DateTimeFormat("en", {
        day: "numeric"
    }).format(tmp);
    const month = new Intl.DateTimeFormat("en", {
        month: "long"
    }).format(tmp);
    const year = new Intl.DateTimeFormat("en", {
        year: "numeric"
    }).format(tmp);
    return `${month} ${day}, ${year}`;
}


/***/ })

};
;