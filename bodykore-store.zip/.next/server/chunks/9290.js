"use strict";
exports.id = 9290;
exports.ids = [9290];
exports.modules = {

/***/ 9290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NavOptions)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function NavOptions({ title1 , titles , type , setter  }) {
    const scrollDown = (id)=>{
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }
    };
    function setCategory(category) {
        if (setter) {
            setter({
                page: 1,
                category: category
            });
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-center flex-wrap gap-4 lg:gap-8 font-bebas font-bold text-xl lg:text-2xl italic pt-10 lg:pt-20 pb-8",
            style: {
                letterSpacing: "1px"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: type === "" || type === undefined ? "text-red-bc2026" : "cursor-pointer",
                    onClick: ()=>{
                        if (type !== "") {
                            setCategory("");
                        }
                    },
                    children: title1
                }),
                titles.map((t, i)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: type === t.id ? "text-black-373933" : "cursor-pointer",
                        onClick: ()=>{
                            if (t.id && type !== t.id) {
                                scrollDown(t.id);
                                setCategory(t.id);
                            }
                        },
                        children: t.text
                    }, i);
                })
            ]
        })
    });
};


/***/ })

};
;