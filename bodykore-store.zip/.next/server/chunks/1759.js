"use strict";
exports.id = 1759;
exports.ids = [1759];
exports.modules = {

/***/ 8134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ InvisibleBanner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function InvisibleBanner({ height , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${height}`,
            id: id
        })
    });
};


/***/ }),

/***/ 733:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IK": () => (/* binding */ getHomeReviews),
/* harmony export */   "Vb": () => (/* binding */ voteReview),
/* harmony export */   "XU": () => (/* binding */ createReview),
/* harmony export */   "nX": () => (/* binding */ getReviewsOfProduct)
/* harmony export */ });
/* unused harmony exports getReviewsPrivate, getReviewsOfUser */
const getReviewsPrivate = async ()=>{
    const myHeaders = new Headers();
    myHeaders.append("Authorization", `Basic ${btoa(`${"pubkey-LwW1AZ2BD7458YZ6331616KHz44X79"}:${process.env.STAMPED_API_KEY_PRIVATE}`)}`);
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    const requestOptions = {
        method: "GET",
        headers: myHeaders,
        redirect: "follow"
    };
    fetch(`https://stamped.io/api/v2/${"249421"}/dashboard/reviews`, requestOptions).then((response)=>response.json()).then((result)=>console.log(JSON.stringify(result))).catch((error)=>console.log("error", error));
};
const getReviewsOfProduct = async (productId)=>{
    const requestOptions = {
        method: "GET",
        redirect: "follow"
    };
    const params = new URLSearchParams();
    params.append("productId", productId);
    params.append("minRating", "1"); // Without this it only returns 5 stars
    params.append("storeUrl", "249421");
    params.append("apiKey", "pubkey-LwW1AZ2BD7458YZ6331616KHz44X79");
    try {
        const res = await fetch(`http://stamped.io/api/widget/reviews?${params.toString()}`, requestOptions);
        const resJson = await res.json();
        // The request also return metadata and more review information than explicit
        // in the interface
        return resJson.data;
    } catch (error) {
        console.error(error);
        return;
    }
};
const getHomeReviews = async ()=>{
    const requestOptions = {
        method: "GET",
        redirect: "follow"
    };
    const params = new URLSearchParams();
    params.append("sortReviews", "highest-rating");
    params.append("minRating", "1"); // Without this it only returns 5 stars
    params.append("storeUrl", "249421");
    params.append("apiKey", "pubkey-LwW1AZ2BD7458YZ6331616KHz44X79");
    params.append("take", "6");
    try {
        const res = await fetch(`http://stamped.io/api/widget/reviews?${params.toString()}`, requestOptions);
        const resJson = await res.json();
        // The request also return metadata and more review information than explicit
        // in the interface
        return resJson.data;
    } catch (error) {
        console.error(error);
        return [];
    }
};
const getReviewsOfUser = async (email)=>{
    const requestOptions = {
        method: "GET",
        redirect: "follow"
    };
    const params = new URLSearchParams();
    params.append("email", email);
    params.append("storeUrl", "249421");
    params.append("apiKey", "pubkey-LwW1AZ2BD7458YZ6331616KHz44X79");
    try {
        const res = await fetch(`http://stamped.io/api/widget/reviews?${params.toString()}`, requestOptions);
        const resJson = await res.json();
        // The request also return metadata and more review information than explicit
        // in the interface
        return resJson.data;
    } catch (error) {
        console.error(error);
        return;
    }
};
/**
 * Use shopify's id for productId so that the elements link on Stamped.
 * When using the Storefront API, shopify returns the id encoded in Base64,
 * decode it and then take the id from the link obtained.
 * @param param0
 * @returns
 */ const createReview = async ({ productId , authorName , authorEmail , authorLocation , reviewRating , reviewTitle , reviewMessage , reviewRecommend  })=>{
    const myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    const formdata = new URLSearchParams();
    formdata.append("productId", productId);
    formdata.append("author", authorName);
    formdata.append("email", authorEmail);
    formdata.append("location", authorLocation || "");
    formdata.append("reviewRating", reviewRating.toString());
    formdata.append("reviewTitle", reviewTitle);
    formdata.append("reviewMessage", reviewMessage);
    formdata.append("reviewRecommendProduct", reviewRecommend ? "true" : "false");
    // formdata.append('productName', productTitle);
    // formdata.append('productSKU', "Product's Sku");
    // formdata.append(
    //   'productImageUrl',
    //   'https://example.com/image/product-image.png'
    // );
    // formdata.append(
    //   'productUrl',
    //   'https://example.com/products/product-image.png'
    // );
    formdata.append("reviewSource", "api");
    // formdata.append('photo0', fileInput.files[0], 'file');
    // formdata.append('video0', fileInput.files[0], 'file');
    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: formdata,
        redirect: "follow"
    };
    const params = new URLSearchParams();
    params.append("apiKey", "pubkey-LwW1AZ2BD7458YZ6331616KHz44X79");
    params.append("sId", "249421");
    try {
        const res = await fetch(`https://stamped.io/api/reviews3?${params.toString()}`, requestOptions);
        // The query also return information about the review if needed
        // console.log(await res.text());
        return res.ok;
    } catch (error) {
        console.error(error);
        return false;
    }
};
const voteReview = async (reviewId, vote)=>{
    const formdata = new URLSearchParams();
    formdata.append("reviewId", reviewId);
    formdata.append("vote", vote ? "1" : "-1");
    formdata.append("apikey", "pubkey-LwW1AZ2BD7458YZ6331616KHz44X79");
    formdata.append("sId", "249421");
    const requestOptions = {
        method: "POST",
        body: formdata,
        redirect: "follow"
    };
    try {
        const res = await fetch("https://stamped.io/api/reviews/vote", requestOptions);
        return res.ok;
    } catch (error) {
        console.error(error);
        return false;
    }
};


/***/ })

};
;