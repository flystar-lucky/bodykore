"use strict";
exports.id = 3214;
exports.ids = [3214];
exports.modules = {

/***/ 3214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ OneReview)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function OneReview({ img , reviews  }) {
    const { 0: displayed , 1: setDisplayed  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const mapRating = (rating)=>{
        const arr = [];
        for(let i = 0; i < 5; i++){
            arr.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: Math.round(rating) > i ? "/svg/star.svg" : "/svg/starEmpty.svg",
                width: 22,
                height: 21,
                alt: ""
            }, i));
        }
        return arr;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center items-center w-full h-fit max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:pr-28",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: img,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pt-16 lg:pt-14 lg:w-1/3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "flex justify-center lg:justify-start font-bebas text-black-373933 italic font-bold text-5xl",
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: [
                                    "\u201C",
                                    reviews[displayed].reviewTitle,
                                    "\u201D"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center pt-6 lg:justify-start gap-1",
                                children: mapRating(reviews[displayed].reviewRating)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "font-roboto text-black-1c2023 text-center px-10 lg:px-0 pt-8 lg:text-left leading-relaxed",
                                children: [
                                    '"',
                                    reviews[displayed].reviewMessage,
                                    '"'
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                className: "flex justify-center lg:justify-start pt-5 font-bebas text-red-bc2026 italic font-bold text-2xl",
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: [
                                    "- ",
                                    reviews[displayed].author
                                ]
                            }),
                            reviews.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center pt-8 lg:pt-0 lg:justify-end",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "h-10 w-7",
                                    onClick: ()=>{
                                        setDisplayed((prev)=>(prev + 1) % reviews.length);
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/svg/reviewArrow.svg",
                                        alt: ""
                                    })
                                })
                            }) : null
                        ]
                    })
                ]
            })
        })
    });
};


/***/ })

};
;