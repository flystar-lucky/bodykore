"use strict";
exports.id = 6731;
exports.ids = [6731];
exports.modules = {

/***/ 6731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SellCards)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./config/routes.ts
var routes = __webpack_require__(9641);
// EXTERNAL MODULE: ./utils/checkout.ts
var utils_checkout = __webpack_require__(8576);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6734);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
// EXTERNAL MODULE: external "localstorage-slim"
var external_localstorage_slim_ = __webpack_require__(4342);
var external_localstorage_slim_default = /*#__PURE__*/__webpack_require__.n(external_localstorage_slim_);
;// CONCATENATED MODULE: ./services/api/wishlist.ts

/**
 * Return the wishlist in string format, use JSON.parse()
 */ const getWishlistAPI = async (id)=>{
    const res = await fetch(`${routes/* default.api.wishlist.path */.Z.api.wishlist.path}?id=${id}`, {
        method: "GET"
    });
    const resJson = await res.json();
    return resJson.metafield?.value;
};
const updateWishlistAPI = async (id, wishlist)=>{
    const data = {
        id,
        wishlist
    };
    const body = JSON.stringify(data);
    const res = await fetch(routes/* default.api.wishlist.path */.Z.api.wishlist.path, {
        method: "POST",
        body
    });
    const resJson = await res.json();
    return resJson.metafields[0].id;
};

;// CONCATENATED MODULE: ./utils/wishlist.ts



const initWishlist = async ()=>{
    const customerId = external_js_cookie_default().get("customerId");
    const local = external_localstorage_slim_default().get("wishlist", {
        decrypt: true
    });
    if (customerId !== undefined) {
        const res = await getWishlistAPI(customerId);
        let wishlist = new Set();
        if (res) {
            wishlist = new Set(JSON.parse(res));
        }
        if (local) {
            local.forEach((item)=>wishlist.add(item));
            updateWishlist(wishlist);
        }
        external_localstorage_slim_default().remove("wishlist");
        return wishlist;
    } else if (local) {
        return new Set(local);
    }
    return new Set();
};
const updateWishlist = async (wishlist)=>{
    const customerId = external_js_cookie_default().get("customerId");
    if (customerId !== undefined) {
        await updateWishlistAPI(customerId, [
            ...wishlist
        ]);
    } else {
        external_localstorage_slim_default().set("wishlist", [
            ...wishlist
        ], {
            encrypt: true
        });
    }
};

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "recoil"
var external_recoil_ = __webpack_require__(9755);
// EXTERNAL MODULE: ./services/shopify/storefront/checkout.ts
var storefront_checkout = __webpack_require__(5003);
// EXTERNAL MODULE: ./state/atoms.ts
var atoms = __webpack_require__(7239);
;// CONCATENATED MODULE: ./components/ui/bodykore/Cards/SellCards.tsx










function SellCards({ title , gap , cards  }) {
    const setCartItems = (0,external_recoil_.useSetRecoilState)(atoms/* cartItemsState */.uZ);
    const setcheckoutUrl = (0,external_recoil_.useSetRecoilState)(atoms/* checkoutUrlState */.g0);
    const setCartTotal = (0,external_recoil_.useSetRecoilState)(atoms/* cartTotalState */.jJ);
    const addProduct = async (id)=>{
        const checkoutId = external_js_cookie_default().get("checkoutId");
        const email = external_js_cookie_default().get("email");
        let checkout;
        if (checkoutId !== undefined) {
            const res = await (0,storefront_checkout/* addItemToCheckout */.Vx)(checkoutId, id);
            if (res.checkout !== undefined) {
                checkout = res.checkout;
            }
        } else {
            const res1 = await (0,storefront_checkout/* createCheckout */._R)(id, email);
            if (res1.checkout !== undefined) {
                checkout = res1.checkout;
                external_js_cookie_default().set("checkoutId", checkout.id, {
                    expires: 90
                });
            }
        }
        if (checkout !== undefined) {
            setCartItems((0,utils_checkout/* mapCheckout */.e)(checkout));
            setcheckoutUrl(checkout.webUrl);
            setCartTotal(checkout.subtotalPriceV2.amount);
        } else {
            console.error("Failed to add product");
        }
    };
    const { 0: wishlist , 1: setWishlist  } = (0,external_react_.useState)(new Set());
    const fetchWishlist = async ()=>{
        setWishlist(await initWishlist());
    };
    (0,external_react_.useEffect)(()=>{
        // Cookies.set('customerId', '6154246979804', {expires: 90})
        fetchWishlist();
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-7xl m-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                    className: "flex justify-center lg:justify-start font-bebas italic font-bold text-5xl text-black-373933 pr-2 pb-12 lg:pl-16",
                    style: {
                        letterSpacing: "1px"
                    },
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `flex flex-wrap justify-center ${gap}`,
                    children: cards.map((item, index)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "px-8 lg:px-0",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "shadow-lg bg-white",
                                style: {
                                    height: "385px",
                                    width: "280px"
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: `flex justify-between bg-no-repeat bg-center h-48 bg-cover relative`,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: `${routes/* default.products.path */.Z.products.path}/${item.slug}`,
                                                className: "relative h-full w-full",
                                                children: [
                                                    item.bgImg !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                        src: item.bgImg,
                                                        layout: "fill",
                                                        objectFit: "cover",
                                                        objectPosition: "absolute"
                                                    }) : null,
                                                    item.comparePrice !== undefined ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "flex justify-center items-center bg-red-bc2026 w-32 h-8 z-10 absolute",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                            className: "font-bebas text-white",
                                                            children: "DROPPED PRICE"
                                                        })
                                                    }) : null,
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "z-10 absolute right-0",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                    id: "Componente_152_2",
                                                    "data-name": "Componente 152 \u2013 2",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "32",
                                                    height: "35",
                                                    viewBox: "0 0 32 35",
                                                    onClick: (event)=>{
                                                        const add = !wishlist.has(item.slug);
                                                        if (add) {
                                                            wishlist.add(item.slug);
                                                        } else {
                                                            wishlist.delete(item.slug);
                                                        }
                                                        updateWishlist(wishlist);
                                                        event.currentTarget.querySelector("path")?.setAttribute("fill", add ? "crimson" : "none");
                                                    },
                                                    className: "cursor-pointer",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                                            id: "Rect\xe1ngulo_7",
                                                            "data-name": "Rect\xe1ngulo 7",
                                                            width: "32",
                                                            height: "35",
                                                            fill: "#fff",
                                                            opacity: "0"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            id: "Icon_feather-heart",
                                                            "data-name": "Icon feather-heart",
                                                            d: "M16.685,5.8a3.862,3.862,0,0,0-5.792,0l-.789.86L9.315,5.8a3.862,3.862,0,0,0-5.792,0,4.748,4.748,0,0,0,0,6.31l.789.86,5.792,6.31,5.792-6.31.789-.86a4.747,4.747,0,0,0,0-6.31Z",
                                                            transform: "translate(6.512 6.133)",
                                                            fill: wishlist.has(item.slug) ? "crimson" : "none",
                                                            stroke: "#000",
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: "2"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "px-3",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex items-center h-20",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                            className: "text-black-1c2023 font-roboto font-bold pt-5 w-32",
                                                            children: item.title
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex justify-center items-center shadow-lg bg-white h-9 w-32 mt-6",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                                className: "font-bebas italic font-bold text-red-bc2026 line-through pr-4",
                                                                children: item.comparePrice !== undefined ? `$${item.comparePrice}` : null
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                                                className: "font-bebas italic font-bold text-2xl text-black-373933",
                                                                children: [
                                                                    "$",
                                                                    item.price
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-gray-700 text-base mb-4 h-10 flex items-center",
                                                children: item.description
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                className: `w-full h-12 mb-2 border-2 border-black-373933 rounded-md font-bebas ${item.available ? "bg-black-373933 text-white" : "cursor-default"}`,
                                                style: {
                                                    letterSpacing: "1.5px"
                                                },
                                                onClick: ()=>{
                                                    addProduct(item.id);
                                                },
                                                disabled: !item.available,
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex justify-between px-16 items-center",
                                                    children: [
                                                        item.available ? /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            width: "16.193",
                                                            height: "16.193",
                                                            viewBox: "0 0 16.193 16.193",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                                id: "Icon_material-add-shopping-cart",
                                                                "data-name": "Icon material-add-shopping-cart",
                                                                d: "M9.532,7.669h1.606V5.355h2.41V3.813h-2.41V1.5H9.532V3.813H7.122V5.355h2.41Zm-3.213,6.94A1.543,1.543,0,1,0,7.926,16.15,1.573,1.573,0,0,0,6.319,14.608Zm8.032,0a1.543,1.543,0,1,0,1.606,1.542A1.573,1.573,0,0,0,14.351,14.608ZM6.456,12.1l.024-.093L7.2,10.753h5.984a1.61,1.61,0,0,0,1.406-.794l3.1-5.405-1.4-.74h-.008L15.4,5.355,13.187,9.211H7.548L7.444,9l-1.8-3.647L4.881,3.813,4.126,2.271H1.5V3.813H3.106L6,9.666,4.914,11.555a1.445,1.445,0,0,0-.2.74,1.58,1.58,0,0,0,1.606,1.542h9.638V12.3h-9.3A.2.2,0,0,1,6.456,12.1Z",
                                                                transform: "translate(-1.5 -1.5)",
                                                                fill: "#fff"
                                                            })
                                                        }) : null,
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                            className: "w-full",
                                                            children: item.available ? "ADD TO CART" : "OUT OF STOCK"
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }, index);
                    })
                })
            ]
        })
    });
};


/***/ })

};
;