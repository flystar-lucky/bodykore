"use strict";
(() => {
var exports = {};
exports.id = 9163;
exports.ids = [9163];
exports.modules = {

/***/ 5649:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ PlainRedBanner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function PlainRedBanner() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "h-4 bg-red-bc2026 mb-10"
        })
    });
};


/***/ }),

/***/ 9211:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const SubmissionForm = ({})=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        className: "max-w-7xl m-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap -mx-3 mb-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-name",
                                children: "Name *"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-name",
                                type: "text",
                                placeholder: "Enter your name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-email-address",
                                children: "Email address *"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-email-address",
                                type: "text",
                                placeholder: "Enter your email"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-phone-number",
                                children: "Phone Number"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-phone-number",
                                type: "text",
                                placeholder: "Phone Number"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap -mx-3 mb-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-date-purchase",
                                children: "Date of purchase *"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-date-purchase",
                                type: "text",
                                placeholder: "dd / mm / yyyy"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-item-name",
                                children: "Item name *"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-item-name",
                                type: "text",
                                placeholder: "Item name"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-order-number",
                                children: "Order Number *"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-order-number",
                                type: "text",
                                placeholder: "Order number"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap -mx-3 mb-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-2/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-street-address",
                                children: "Address"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-street-address",
                                type: "text",
                                placeholder: "Street Address"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-country",
                                children: "Country"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-country",
                                type: "text",
                                placeholder: "Country"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap -mx-3 mb-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-2/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-street-address",
                                children: "Address"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-street-address",
                                type: "text",
                                placeholder: "Street Address"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-state",
                                children: "State"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-state",
                                type: "text",
                                placeholder: "State/Province"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap -mx-3 mb-6",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3 mb-6 md:mb-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-city",
                                children: "City"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-city",
                                type: "text",
                                placeholder: "City"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-zip",
                                children: "ZIP"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 mb-3 leading-tight",
                                id: "grid-zip",
                                type: "text",
                                placeholder: "ZIP/Postal Code"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full md:w-1/3 px-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "block tracking-wide text-black-1c2023 text-sm font-roboto mb-2",
                                htmlFor: "grid-marketplace",
                                children: "Marketplace purchase from"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                className: "appearance-none block w-full bg-white text-grey-848484 border-2 border-black-1c2023 py-3 px-4 leading-tight",
                                id: "grid-marketplace",
                                type: "text",
                                placeholder: "Marketplace"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pb-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                        className: "pb-1 block text-sm font-roboto text-black-1c2023 sm:mt-px sm:pt-2",
                        children: "Comments"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mt-1 sm:mt-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                            id: "comments",
                            name: "comments",
                            rows: 3,
                            className: "shadow-sm block w-full text-sm border-2 border-black-1c2023 pl-4 pt-2 h-44",
                            defaultValue: "",
                            required: true
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "block",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-2",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            className: "inline-flex items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "checkbox",
                                    className: "form-checkbox"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "ml-2",
                                    children: "Accept Terms and Conditions"
                                })
                            ]
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SubmissionForm);


/***/ }),

/***/ 7858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Blacktitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Blacktitle({ title , textSize , textColor , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center lg:justify-start",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: `${textColor} ${textSize} font-bebas font-bold italic text-center md:text-left`,
                    children: title
                })
            })
        })
    });
};


/***/ }),

/***/ 1711:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_bodykore_Banners_PlainRedBanner__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5649);
/* harmony import */ var _components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7858);
/* harmony import */ var _components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4348);
/* harmony import */ var _components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9358);
/* harmony import */ var _components_ui_bodykore_Sections_SubmissionForm__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9211);
/* harmony import */ var _components_ui_bodykore_Buttons_TransparentBtn__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7326);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8969);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4725);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_5__]);
_components_Header__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const getStaticProps = async (context)=>{
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_2__/* .getHeader */ .P)();
    return {
        props: {
            header
        },
        revalidate: 30 * 60
    };
};
const Warranty = ({ header  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_4__/* .warranty */ .Jr
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_PlainRedBanner__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "WARRANTY SPECIFICATIONS",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-5 mb-5 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            textPosition: "lg:text-left",
                            paragraphs: [
                                {
                                    description: "Strength Equipment: Offers an industry leading 10 year warranty on our commercial equipment\u2019s frame and 5 years on parts. We stand by our products and our industry leading 10 years prove this."
                                },
                                {
                                    description: "Cardio Equipment: 2 Years Frame, 1 year mechanical."
                                },
                                {
                                    description: "Weights and Bars: 2 Years."
                                },
                                {
                                    description: "As a part of our commitment to customer service, our Warranty Team is here to assist you with any troublesome equipment you may have purchased from us. We keep spare parts to most of the machines we sell and where we don\u2019t have, we can do the leg work to get parts in for you. In order for us to assist you, we ask that you retain your invoice for proof of purchase. We also may request that you return a part to the warehouse as proof of the issue, however in most cases, clear photographs of the damaged part will suffice. To lodge a warranty claim, please use our warranty claim form or call us at 949-325-3088"
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "CONDITIONS AND RESTRICTIONS",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-5 pb-2 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            textPosition: "lg:text-left",
                            paragraphs: [
                                {
                                    description: "This warranty is valid only in accordance with the conditions set forth below:"
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-10 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            List: [
                                {
                                    text: "The warranty applies to product sold by BodyKore only if:",
                                    subText: "- It has been serviced by an authorized BodyKore service provider",
                                    subText1: "- It remains in the possession of the original purchaser and proof of purchase is demonstrated",
                                    subText2: "- It has not been subjected to accident, misuse, abuse, improper service, or non-manufacturer modification"
                                },
                                {
                                    text: "Claims are made within the warranty period."
                                },
                                {
                                    text: "This warranty does not cover damage or equipment failure caused by electrical wiring not in compliance with electrical codes advised or stipulated in the product owner\u2019s manual specifications, or failure to provide reasonable and necessary maintenance as outlined in the owner\u2019s manual."
                                },
                                {
                                    text: "BodyKore is not responsible for Internet connectivity to its products. This restriction applies to services, such as those provided by an Internet service provider (ISP), and also to hardware related to Internet connectivity, such as Ethernet cabling, routers, servers and switches."
                                },
                                {
                                    text: "BodyKore is not responsible for the quality of television, video, audio, or other media supplied to its products. This restriction applies to services, such as those provided by a cable or satellite television provider; to signal strength and clarity; and also to hardware related to the reception and delivery of television, video, audio, and other media. Such hardware can include (but is not limited to) audio, video, and radio-frequency (RF) cabling, connectors, receivers, modulators, combiners, distribution amplifiers, splitters, and so on."
                                },
                                {
                                    text: "BodyKore cannot guarantee that the heart rate measurement system on its products will work for all users. Heart rate measurement accuracy varies based on a number of factors, including the user\u2019s physiology and age, the method in which the heart rate measurement system is used, external interference, and other factors that may influence heart rate acquisition."
                                },
                                {
                                    text: "BodyKore does not warranty the work or product of third party companies (e.g., head end systems, low voltage wiring, etc.)."
                                },
                                {
                                    text: "BodyKore does not pay labour outside of the USA. Equipment limited warranty is void when equipment is installed in a country other than where sold."
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "WHAT IS COVERED?",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-5 mb-5 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            textPosition: "lg:text-left",
                            paragraphs: [
                                {
                                    description: "Equipment is warranted to be free from defects in materials and manufacturing."
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "WHO PAYS SHIPPING FOR SERVICE:",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-5 mb-5 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            textPosition: "lg:text-left",
                            paragraphs: [
                                {
                                    description: "If the equipment or any warranted part must be returned to a service facility for repairs, BodyKore will pay all shipping charges during the covered warranty period. The purchaser is responsible for shipping after the warranty has expired."
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "WHAT WE WILL DO TO CORRECT COVERED DEFECTS:",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-5 mb-5 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            textPosition: "lg:text-left",
                            paragraphs: [
                                {
                                    description: "We will repair, or if unable to be repaired, at our discretion, replace the covered equipment when it fails to perform as intended during normal usage. Parts will be replaced with like kind and quality, and may be new or remanufactured. If the covered equipment cannot be repaired or if parts are no longer available due to the age of the equipment or are discontinued by the Manufacturer, the unit will be replaced with a product of equal or similar features and functionality. Replacement parts and equipment are warranted for the remaining portion of the original warranty period."
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "NOT COVERED",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-5 mb-5 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            textColor: "text-black-373933",
                            List: [
                                {
                                    text: "Damages or failure due to accident, abuse, neglect and misuse of equipment for anything other than its intended purpose."
                                },
                                {
                                    text: "Improper assembly or installation of parts or accessories not originally intended for the equipment."
                                },
                                {
                                    text: "General wear and tear, including upholstery and rust corrosion."
                                },
                                {
                                    text: "Lack of general maintenance and or failure to service or maintain the equipment correctly. This includes a lack of/over lubrication between the deck and the running belt or incorrect alignment/ adjustment of treadmill belts that result in damage."
                                },
                                {
                                    text: "Damages or failure due to the use of an improper power supply"
                                },
                                {
                                    text: "Please note BodyKore requires an individual power circuit be used for each treadmill, along with surge protectors on all equipment that plugs in or warranty will be void."
                                },
                                {
                                    text: "Replacement of flat or corroded batteries due to non-use."
                                },
                                {
                                    text: "Damage caused by the surrounding environment or weather and failure to keep the equipment in a clean, dry environment (natural disasters, equipment used outdoors or near water, entry of foreign matter, dust or particles etc.)"
                                },
                                {
                                    text: "Belts requiring tensioning due to stretching after use are not covered under warranty. A maintenance kit is provided on delivery with all orders to keep the equipment serviced as required."
                                },
                                {
                                    text: "A service callout fee will be applicable where no damage or failure can be found or if determined to be caused by a matter not covered under the warranty conditions."
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            title: "WARRANTY SUBMISSION",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-8 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_SubmissionForm__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-5 pb-36 px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Buttons_TransparentBtn__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            width: "w-52",
                            fontSize: "text-sm",
                            text: "SUBMIT"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Warranty);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,1864,7326], () => (__webpack_exec__(1711)));
module.exports = __webpack_exports__;

})();