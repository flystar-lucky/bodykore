"use strict";
(() => {
var exports = {};
exports.id = 8034;
exports.ids = [8034];
exports.modules = {

/***/ 5262:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ImageBanner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);


function ImageBanner({ height , bgImage  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `bg-no-repeat ${height} w-full bg-center bg-cover relative`,
            children: bgImage !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: bgImage,
                layout: "fill",
                objectFit: "cover",
                alt: ""
            }) : null
        })
    });
};


/***/ }),

/***/ 8052:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ImgDarkEffect)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9641);


function ImgDarkEffect({ title1 , title2 , buttonsText , images  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "relative",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center lg:justify-start py-6 max-w-7xl m-auto lg:pl-16",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-red-bc2026 text-5xl font-bebas font-bold italic",
                            children: title1
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-black-373933 text-5xl pl-2 font-bebas font-bold italic",
                            children: title2
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap justify-center gap-4 lg:gap-20",
                    children: images.map((img, i)=>{
                        return img.image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "bg-black hover:bg-opacity-0 transition duration-500",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: `${_config_routes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].portfolio.path */ .Z.portfolio.path}/${img.slug}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: img.image,
                                    alt: "",
                                    className: "h-80 w-80 object-cover"
                                })
                            })
                        }, i) : null;
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: _config_routes__WEBPACK_IMPORTED_MODULE_1__/* ["default"].portfolio.path */ .Z.portfolio.path,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "mt-16 lg:mt-16 mb-44 bg-transparent text-black-373933 hover:text-red-bc2026 py-3 px-16 border-2 border-black-373933 hover:border-red-bc2026 rounded-lg text-lg font-bold font-bebas",
                            style: {
                                letterSpacing: "2px"
                            },
                            children: buttonsText.text
                        })
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 7101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DoubleText)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function DoubleText({ title1 , title2 , title3 , items  }) {
    const mapItems = ()=>{
        return items?.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-black",
                    children: item
                })
            }, index));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center lg:justify-start py-6 gap-16 lg:gap-28 pt-16",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lg:pl-24 w-7/12",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-black-373933 text-5xl font-bebas font-bold italic text-center md:text-left",
                                children: title1
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-black-373933 text-2xl font-bebas text-center md:text-left",
                                children: title2
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-black-373933 text-sm font-roboto text-center md:text-left",
                                children: "In the beachy city of Malibu, Los Angeles, a new family with a custom house decided to build out a sunroom along the hillside overlooking the Pacific Ocean. After deciding to put in a gym in the sunroom, the family needed a set of equipment that would help meet their training goals without compromising their beachfront view. We were able to recommend an MX1162 Universal Trainer, 5-50lb Dumbbell Set, G206 Adjustable Bench, among others. With this equipment, the family now has access to a versatile and satisfying workout in the brightest spot in their home."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                className: "text-black-373933 text-2xl font-bebas pb-2 text-center md:text-left",
                                children: "EQUIPMENT"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "text-red leading-6 list-disc font-roboto font-bold text-sm",
                                children: mapItems()
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 4065:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8969);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7341);
/* harmony import */ var _components_ui_bodykore_Banners_ImageBanner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5262);
/* harmony import */ var _components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6731);
/* harmony import */ var _components_ui_bodykore_ImgDarkEffect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8052);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6903);
/* harmony import */ var _components_ui_bodykore_Text_DoubleText__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7101);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4725);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2322);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5852);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8099);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_7__]);
_components_Header__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














const getStaticPaths = async ()=>{
    const projects = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getAllProjectsSlug */ .Zj)();
    const paths = projects.map(({ slug  })=>({
            params: {
                slug
            }
        })).flat();
    return {
        paths: [
            ...paths
        ],
        fallback: "blocking"
    };
};
const getStaticProps = async (context)=>{
    const { slug  } = context.params;
    const project = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getProject */ .e5)(slug);
    if (project === undefined) {
        return {
            notFound: true
        };
    }
    const products = [];
    for (let product of project.products){
        const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .getProductCard */ .rE)(product.handle);
        if (res !== undefined) {
            products.push(res);
        }
    }
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_4__/* .getHeader */ .P)();
    return {
        props: {
            project,
            products,
            header
        },
        revalidate: 30 * 60
    };
};
const SingleProject = ({ project , products , header  })=>{
    const related = project.related.map((item)=>({
            image: item.image[0]?.url,
            slug: item.slug
        }));
    const mapProducts = ()=>{
        return products.map((item)=>({
                id: item.variants.edges[0].node.id,
                slug: item.handle,
                bgImg: item.featuredImage?.url,
                title: item.title,
                price: item.variants.edges[0].node.priceV2.amount,
                comparePrice: item.variants.edges[0].node.compareAtPriceV2?.amount,
                description: item.description,
                available: item.availableForSale
            }));
    };
    // dynamically change seo title
    const dinamycSeo = ()=>{
        return _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_5__/* .portfolioProject */ .ob;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                seo: dinamycSeo()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_ImageBanner__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        height: "h-80",
                        bgImage: project.image[0]?.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_DoubleText__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            title1: project.title,
                            title2: project.subtitle,
                            items: products.map((item)=>item.title)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            bgImage: project.image,
                            link: ""
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            title: "FIND THE EQUIPMENT",
                            gap: "gap-3",
                            cards: mapProducts()
                        })
                    }),
                    related.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_ImgDarkEffect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title1: "OTHER",
                            title2: "PROJECTS",
                            title3: "EQUIPMENT",
                            images: related,
                            buttonsText: {
                                text: "SEE ALL",
                                color: "transparent"
                            }
                        })
                    }) : null
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleProject);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 8702:
/***/ ((module) => {

module.exports = require("@splidejs/react-splide");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4342:
/***/ ((module) => {

module.exports = require("localstorage-slim");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,6903,6731,2322], () => (__webpack_exec__(4065)));
module.exports = __webpack_exports__;

})();