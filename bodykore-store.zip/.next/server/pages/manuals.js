"use strict";
(() => {
var exports = {};
exports.id = 6241;
exports.ids = [6241];
exports.modules = {

/***/ 9749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ManualCards)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);


function ManualCards({ card  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-w-7xl m-auto pt-16",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-wrap justify-center lg:justify-between lg:px-16",
                children: card.map((c, i)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-12 px-8 lg:px-0",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-white w-64",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `flex justify-between bg-no-repeat bg-center h-64 bg-cover`,
                                    children: c.image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: c.image,
                                        width: "256",
                                        height: "256",
                                        objectFit: "contain",
                                        alt: ""
                                    }) : null
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "px-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-grey-848484 font-roboto text-sm pt-2",
                                            children: c.category
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "h-24",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-black-1c2023 font-bebas text-3xl font-bold italic pr-2",
                                                    style: {
                                                        letterSpacing: "1px"
                                                    },
                                                    children: `${c.title} -`
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-red-bc2026 font-bebas text-3xl font-bold italic",
                                                    style: {
                                                        letterSpacing: "1px"
                                                    },
                                                    children: c.ref
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-black-1c2023 font-roboto text-sm mb-4 h-14",
                                            children: `Assembly instructions for the BodyKore ${c.title} - ${c.ref}`
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: c.file,
                                            target: "_blank",
                                            rel: "noreferrer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "w-52 h-12 mb-2 bg-transparent text-black-373933 hover:text-red-bc2026 border-2 border-black-373933 hover:border-red-bc2026 rounded-lg font-bebas",
                                                style: {
                                                    letterSpacing: "1.5px"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "mr-2",
                                                    children: "DOWNLOAD MANUAL"
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    }, i);
                })
            })
        })
    });
};


/***/ }),

/***/ 5554:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_bodykore_Banners_FadingBanner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9913);
/* harmony import */ var _components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9290);
/* harmony import */ var _components_ui_bodykore_Cards_ManualCards__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9749);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6148);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4725);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8969);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2980);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_6__]);
_components_Header__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const getStaticProps = async (context)=>{
    const manuals = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getAllManuals */ .s3)();
    const categories = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getManualCategories */ .jn)();
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_3__/* .getHeader */ .P)();
    return {
        props: {
            manuals,
            categories,
            header
        },
        revalidate: 30 * 60
    };
};
const Manuals = ({ manuals , categories , header  })=>{
    const { 0: filter , 1: setFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        page: 1,
        category: ""
    });
    const { 0: manualsShow , 1: setManualsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(manuals);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const { category  } = filter;
        let displayedManuals = manuals;
        if (category !== "") {
            displayedManuals = manuals.filter((item)=>item.manualCategory?.slug === category);
        }
        setManualsShow(displayedManuals);
    }, [
        filter
    ]);
    const mapCategories = ()=>{
        return categories.map((item)=>({
                text: item.title,
                id: item.slug
            }));
    };
    const mapManuals = ()=>{
        return manualsShow.map((item)=>({
                image: item.image?.url,
                category: item.manualCategory?.title,
                title: item.title,
                ref: item.reference,
                file: item.file?.url
            }));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_5__/* .manuals */ .PE
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_FadingBanner__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        title: "ALL MANUALS",
                        bgImage: "bg-manuals-image",
                        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non velit sapien. Quisque vel mauris odio. Mauris et ante in quam pretium malesuada ac a massa.",
                        height: "h-72"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        title1: "ALL",
                        titles: mapCategories(),
                        type: filter.category,
                        setter: setFilter
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-20",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_ManualCards__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            card: mapManuals()
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Manuals);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6148:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jn": () => (/* binding */ getManualCategories),
/* harmony export */   "s3": () => (/* binding */ getAllManuals)
/* harmony export */ });
/* unused harmony export getManualsOfCategory */
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getAllManuals = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query AllManuals {
      manuals {
        title
        reference
        image {
          url
        }
        manualCategory {
          title
          slug
        }
        file {
          url
        }
        product {
          handle
        }
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.manuals;
};
const getManualCategories = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query ManualCategories {
      manualCategories {
        slug
        title
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.manualCategories;
};
const getManualsOfCategory = async (slug)=>{
    const query = gql`
    query ManualsOfCategory($slug: String!) {
      manualCategory(where: { slug: $slug }) {
        manuals {
          title
          image {
            url
          }
          manualCategory {
            title
            slug
          }
          file {
            url
          }
          product {
            handle
          }
        }
      }
    }
  `;
    const variables = {
        slug
    };
    const res = await graphcms.request(query, variables);
    return res.manualCategory === null ? [] : res.manualCategory.manuals;
};


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,9290,9913], () => (__webpack_exec__(5554)));
module.exports = __webpack_exports__;

})();