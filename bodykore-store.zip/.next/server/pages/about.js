"use strict";
(() => {
var exports = {};
exports.id = 2521;
exports.ids = [2521];
exports.modules = {

/***/ 609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ OurVision)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function OurVision({ title1 , title2 , description , options  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto lg:px-28 pb-28",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                id: "belowBanner",
                className: "w-full h-fit max-w-7xl m-auto pt-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-center",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center font-bebas text-5xl font-bold italic",
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 pr-2",
                                        children: title1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: " text-red-bc2026 pr-1",
                                        children: title2
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "px-20 pt-8 font-roboto text-black-1c2023",
                                children: description
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap justify-center items-center px-56 pt-20 gap-6 lg:gap-24 xl:gap-32 text-black",
                        children: options.map((o, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col pb-16 lg:pb-0 px-16 lg:px-0",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex justify-center items-end h-12 w-full",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: o.icon,
                                            className: "w-full",
                                            style: {
                                                maxWidth: o.width,
                                                height: o.height
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full flex items-center justify-center h-12 pt-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-acumin-pro",
                                            children: o.title
                                        })
                                    })
                                ]
                            }, i);
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 2253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WeAreBK)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function WeAreBK({ title1 , title2 , description1 , description2 , btnText , img  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center w-full h-fit pt-32 lg:pt-36 max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mx-20 lg:mx-0 lg:w-2/5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center lg:justify-start font-bebas italic font-bold text-5xl pb-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 pr-2",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: title1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-red-bc2026",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: title2
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-roboto text-black-1c2023 leading-relaxed text-center lg:text-left",
                                children: description1
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-roboto text-black-1c2023 leading-relaxed text-center lg:text-left pt-5",
                                children: description2
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center lg:justify-start",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "w-48 h-12 mt-5 bg-transparent text-black hover:text-red-bc2026 border-2 border-black hover:border-red-bc2026 rounded-lg font-bebas",
                                    style: {
                                        letterSpacing: "1.5px"
                                    },
                                    children: btnText
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-16 lg:pt-0 lg:pl-36",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: img,
                            alt: ""
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 9982:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WhatWeDo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function WhatWeDo({ title1 , title2 , description1 , description2 , img  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center items-center w-full h-fit pt-56 lg:pt-64 max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-16 lg:pb-2 lg:pr-36",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: img,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mx-20 lg:mx-0 lg:w-2/5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center lg:justify-start font-bebas italic font-bold text-5xl pb-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 pr-2",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: title1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-red-bc2026",
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        children: title2
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-roboto text-black-1c2023 leading-relaxed text-center lg:text-left",
                                children: description1
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-roboto text-black-1c2023 leading-relaxed text-center lg:text-left pt-5",
                                children: description2
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 4228:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8969);
/* harmony import */ var _components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8134);
/* harmony import */ var _components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(658);
/* harmony import */ var _components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6731);
/* harmony import */ var _components_ui_bodykore_Sections_AboutSection1__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(609);
/* harmony import */ var _components_ui_bodykore_Sections_AboutSection2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2253);
/* harmony import */ var _components_ui_bodykore_Sections_AboutSection3__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9982);
/* harmony import */ var _components_ui_bodykore_Sections_AboutSection4__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3214);
/* harmony import */ var _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5076);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4725);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8099);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5852);
/* harmony import */ var services_stamped__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(733);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_8__]);
_components_Header__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

















const getStaticProps = async (context)=>{
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_2__/* .getHeader */ .P)();
    const products = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .getAllProducts */ .Dg)(_config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_TOP_PRODUCTS */ .MU, undefined, undefined, services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .Sort.BestSelling */ .PE.BestSelling);
    const reviews = await (0,services_stamped__WEBPACK_IMPORTED_MODULE_5__/* .getHomeReviews */ .IK)();
    return {
        props: {
            header,
            products,
            reviews
        },
        revalidate: 30 * 60
    };
};
const About = ({ header , products , reviews  })=>{
    const mapProducts = ()=>{
        return products.edges.map((item)=>({
                id: item.node.variants.edges[0].node.id,
                slug: item.node.handle,
                bgImg: item.node.featuredImage?.url,
                title: item.node.title,
                price: item.node.variants.edges[0].node.priceV2.amount,
                comparePrice: item.node.variants.edges[0].node.compareAtPriceV2?.amount,
                description: item.node.description,
                available: item.node.availableForSale,
                cursor: item.cursor
            }));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__/* .aboutUs */ .NR
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            bgImage: "/AboutUs/coverImage.jpg",
                            title: "ABOUT US",
                            description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non velit sapien. Mauris et ante in quam pretium malesuada ac a massa. Vestibulum lacinia augue et dolor ullamcorper efficitur."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            height: "h-20",
                            id: "belowBanner"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_AboutSection1__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            title1: "OUR",
                            title2: "VISION",
                            description: "BodyKore\u2019s mission is to remain at the forefront of the global fitness industry by continually providing state of the art commercial fitness equipment, innovative design, and excellent service. We focus our time and efforts on producing high quality products to help each individual achieve their fitness goals, while providing a great experience for our customers.",
                            options: [
                                {
                                    icon: "/svg/advance.svg",
                                    title: "ADVANCE",
                                    width: "50px",
                                    height: "50px"
                                },
                                {
                                    icon: "/svg/innovation.svg",
                                    title: "INNOVATION",
                                    width: "50px",
                                    height: "50px"
                                },
                                {
                                    icon: "/svg/progress.svg",
                                    title: "PROGRESS",
                                    width: "76.5px",
                                    height: "25px"
                                }, 
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_AboutSection2__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title1: "WE ARE",
                            title2: "#BODYKORE",
                            description1: "BodyKore is a leading innovator in creating prestige commercial fitness equipment worldwide. Founded in Los Angeles, California, in 2005, BodyKore has grown into a full service fitness provider, which now has locations in three countries around the world.",
                            description2: "The BodyKore team includes individuals who live for fitness and promote a healthy lifestyle. Our team is made up of product specialists, engineers, Kinesiologists, designers, and hands on specialists who all have a mutual passion for fitness. Our industry expertise and desire, drives our success.",
                            btnText: "JOIN OUR TEAM",
                            img: "/AboutUs/weAre.jpg"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_AboutSection3__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            img: "/AboutUs/whatWeDo.jpg",
                            title1: "WHAT WE",
                            title2: "DO",
                            description1: "Through our team of experts and prestige production capabilities, we are able to produce equipment at the highest bio-mechanical caliber. Customer value comes first and it is displayed through our one on one interaction and compelling problem solving. We do not limit our mission by solely delivering high quality equipment and great customer experience.",
                            description2: "We have taken it upon ourselves to go one step further by directly engaging with our users through our online community and social network. Through these avenues we are able to interact with our users on a daily basis, share product knowledge, and get a better understanding of the industries wants and needs. We make sure to provide our customers with the best fitness experience by combining our knowledge for the industry, with hard work and love for fitness."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "pt-64",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                title: "TOP SELLS",
                                gap: "gap-3",
                                cards: mapProducts()
                            })
                        }),
                        reviews.length !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "py-64 px-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_AboutSection4__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                img: "/frontPage/Review.jpg",
                                reviews: reviews
                            })
                        }) : null
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4342:
/***/ ((module) => {

module.exports = require("localstorage-slim");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,658,6731,1759,3214], () => (__webpack_exec__(4228)));
module.exports = __webpack_exports__;

})();