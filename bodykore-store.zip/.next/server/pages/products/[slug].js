"use strict";
(() => {
var exports = {};
exports.id = 7905;
exports.ids = [7905];
exports.modules = {

/***/ 6292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Image = ({ img , buttons  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "max-w-7xl m-auto",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex justify-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    className: "relative",
                    src: img,
                    alt: ""
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute",
                    children: buttons.map((b, i)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: " mt-80 mr-96 w-9 h-9 rounded-full bg-red-bc2026 flex justify-center items-center font-bebas text-2xl text-white-f2f9fa",
                            children: b.textBottomL
                        }, i);
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Image);


/***/ }),

/***/ 864:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BlackNavOptions)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function BlackNavOptions({ options , height  }) {
    const scrollDown = (id)=>{
        const element = document.getElementById(id);
        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `flex flex-wrap justify-center items-center gap-6 xl:gap-24 py-8 font-roboto text-sm text-white bg-black ${height} max-w-7xl m-auto`,
            style: {
                letterSpacing: "1px"
            },
            children: options.map((o, i)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-2 px-6",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: o.icon,
                            alt: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "cursor-pointer",
                            onClick: ()=>scrollDown(o.id),
                            children: o.text
                        })
                    ]
                }, i);
            })
        })
    });
};


/***/ }),

/***/ 6673:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ SwitchPagesOptions)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function SwitchPagesOptions({ options  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex max-w-7xl m-auto",
            children: options.map((o, i)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: o.icon,
                            alt: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: o.link || "#",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "cursor-pointer text-sm text-black-373933 font-roboto",
                                children: o.text
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: o.arrow,
                            alt: ""
                        })
                    ]
                }, i);
            })
        })
    });
};


/***/ }),

/***/ 8432:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Factors)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Factors({ factors , textSize , division , imgHeight , imgWidth  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "max-w-7xl m-auto",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `flex flex-wrap flex-row items-center ${division}`,
            children: factors.map((f, i)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full lg:w-1/3 h-16 flex flex-row justify-between items-center mb-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-1/3 flex justify-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: f.icon,
                                alt: "",
                                className: `${imgHeight} ${imgWidth}`
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-2/3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: `font-bebas text-black-373933 ${textSize}`,
                                    style: {
                                        letterSpacing: "0.5px"
                                    },
                                    children: f.title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: `font-roboto text-black-373933 ${textSize}`,
                                    style: {
                                        letterSpacing: "0.5px"
                                    },
                                    children: f.description
                                })
                            ]
                        })
                    ]
                }, i);
            })
        })
    });
};


/***/ }),

/***/ 1573:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1143);
/* harmony import */ var _heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_checkout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8576);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6734);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5003);
/* harmony import */ var state_atoms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7239);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const SingleProduct = ({ affirmMonthly , affirmTax , affirmLogo , rating , numReviews , description , shippingCost , options , reviewOnClick  })=>{
    const setCartItems = (0,recoil__WEBPACK_IMPORTED_MODULE_6__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_7__/* .cartItemsState */ .uZ);
    const setcheckoutUrl = (0,recoil__WEBPACK_IMPORTED_MODULE_6__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_7__/* .checkoutUrlState */ .g0);
    const setCartTotal = (0,recoil__WEBPACK_IMPORTED_MODULE_6__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_7__/* .cartTotalState */ .jJ);
    const { 0: selected , 1: setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const multipleOptions = !(options.length === 1 && options[0].title === "Default Title");
    const addProduct = async ()=>{
        const checkoutId = js_cookie__WEBPACK_IMPORTED_MODULE_3___default().get("checkoutId");
        const email = js_cookie__WEBPACK_IMPORTED_MODULE_3___default().get("email");
        let checkout;
        if (checkoutId !== undefined) {
            const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_8__/* .addItemToCheckout */ .Vx)(checkoutId, options[selected].id);
            if (res.checkout !== undefined) {
                checkout = res.checkout;
            }
        } else {
            const res1 = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_8__/* .createCheckout */ ._R)(options[selected].id, email);
            if (res1.checkout !== undefined) {
                checkout = res1.checkout;
                js_cookie__WEBPACK_IMPORTED_MODULE_3___default().set("checkoutId", checkout.id, {
                    expires: 90
                });
            }
        }
        if (checkout !== undefined) {
            setCartItems((0,_utils_checkout__WEBPACK_IMPORTED_MODULE_9__/* .mapCheckout */ .e)(checkout));
            setcheckoutUrl(checkout.webUrl);
            setCartTotal(checkout.subtotalPriceV2.amount);
        } else {
            console.error("Failed to add product");
        }
    };
    const mapRating = ()=>{
        const arr = [];
        for(let i = 0; i < 5; i++){
            arr.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                src: Math.round(rating) > i ? "/svg/star.svg" : "/svg/starEmpty.svg",
                width: 11,
                height: 10,
                alt: ""
            }, i));
        }
        return arr;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "max-w-7xl m-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "font-bebas italic font-bold text-3xl text-black-373933",
                                children: [
                                    "$",
                                    (+options[selected].price).toFixed(2)
                                ]
                            }),
                            options[selected].prevPrice !== undefined ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                className: "font-roboto italic text-lg text-red-bc2026 line-through pr-4",
                                children: [
                                    "$",
                                    (+options[selected].prevPrice).toFixed(2)
                                ]
                            }) : null
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-6 w-52",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/svg/share.svg",
                                width: "23",
                                height: "15",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/svg/instagram.svg",
                                width: "16",
                                height: "16",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/svg/facebook.svg",
                                width: "9",
                                height: "16",
                                alt: ""
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: "/svg/twitter.svg",
                                width: "18",
                                height: "15",
                                alt: ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-xs text-black-373933",
                children: "As low as"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center gap-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "font-bebas font-bold text-5xl",
                        children: affirmMonthly
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "font-bebas font-bold text-3xl",
                        children: affirmTax
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        className: "h-10",
                        src: affirmLogo,
                        alt: ""
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-center items-center lg:justify-start pb-2 gap-1",
                children: [
                    mapRating(),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-red-bc2026 font-roboto font-bold text-sm pl-2",
                        children: rating.toFixed(1)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "text-grey-8C8C8C font-roboto text-xs pl-5",
                        onClick: reviewOnClick,
                        children: [
                            numReviews,
                            " reviews \\ Write a Review"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-sm",
                children: description
            }),
            multipleOptions ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full py-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Listbox, {
                    value: selected,
                    onChange: setSelected,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative mt-1",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Listbox.Button, {
                                className: "relative w-full py-2 pl-3 pr-10 text-left text-gray-700 bg-gray-100 rounded-lg border border-red-bc2026 cursor-default focus:bg-white focus:border-gray-500",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "block truncate",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex gap-8 items-center pl-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: options[selected].img,
                                                    alt: "",
                                                    className: "h-8 w-12"
                                                }),
                                                options[selected].title
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__.SelectorIcon, {
                                            className: "w-5 h-5 text-gray-400",
                                            "aria-hidden": "true"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Transition, {
                                as: react__WEBPACK_IMPORTED_MODULE_5__.Fragment,
                                leave: "transition ease-in duration-100",
                                leaveFrom: "opacity-100",
                                leaveTo: "opacity-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Listbox.Options, {
                                    className: "absolute w-full py-1 mt-1 overflow-auto text-base bg-white rounded-md shadow-lg max-h-60 ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm",
                                    children: options.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Listbox.Option, {
                                            className: ({ active  })=>`cursor-default select-none relative py-2 pl-10 pr-4 ${active ? "text-amber-900 bg-amber-100" : "text-gray-900"}`,
                                            value: index,
                                            children: ({ selected  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: `block truncate ${selected ? "font-medium" : "font-normal"}`,
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex items-center gap-8",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: item.img,
                                                                        alt: "",
                                                                        className: "h-8 w-12"
                                                                    }),
                                                                    item.title
                                                                ]
                                                            })
                                                        }),
                                                        selected ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "absolute inset-y-0 left-0 flex items-center pl-3 text-amber-600",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heroicons_react_solid__WEBPACK_IMPORTED_MODULE_2__.CheckIcon, {
                                                                className: "w-5 h-5",
                                                                "aria-hidden": "true"
                                                            })
                                                        }) : null
                                                    ]
                                                })
                                        }, index))
                                })
                            })
                        ]
                    })
                })
            }) : null,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-sm",
                children: shippingCost
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-grey-8C8C8C font-roboto text-xs pt-1",
                children: "The final shipping cost will be apply in the check out page"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: `w-full h-12 mt-6 mb-2 border-2 border-black-373933 rounded-md font-bebas ${options[selected].available ? "bg-black-373933 text-white" : "cursor-default"}`,
                style: {
                    letterSpacing: "1.5px"
                },
                onClick: addProduct,
                disabled: !options[selected].available,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center items-center",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "mr-2",
                        children: options[selected].available ? "ADD TO CART" : "OUT OF STOCK"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleProduct);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6490:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ReviewForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1185);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_stamped__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(733);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_headlessui_react__WEBPACK_IMPORTED_MODULE_1__]);
_headlessui_react__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function ReviewForm({ productId  }) {
    const { 0: rating , 1: setRating  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(5);
    const { 0: submit , 1: setSubmit  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);
    const handleSubmit = async (event)=>{
        event.preventDefault();
        if (submit !== 0) {
            console.log("Stopped");
            return;
        }
        setSubmit(1);
        const authorName = event.currentTarget.author.value;
        const authorEmail = event.currentTarget.email.vale;
        const reviewTitle = event.currentTarget.reviewTitle.value;
        const reviewMessage = event.currentTarget.experience.value;
        const reviewRecommend = event.currentTarget.option.checked;
        const res = await (0,services_stamped__WEBPACK_IMPORTED_MODULE_3__/* .createReview */ .XU)({
            productId,
            authorName,
            authorEmail,
            reviewTitle,
            reviewMessage,
            reviewRecommend,
            reviewRating: rating
        });
        if (res) {
            console.log("Submitted");
            setSubmit(2);
        } else {
            // Failed to create review
            setSubmit(0);
        }
    };
    const mapStars = ()=>{
        const res = [];
        for(let i = 1; i <= 5; i++){
            res.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                className: "pr-1 cursor-pointer",
                src: rating >= i ? "/svg/star.svg" : "/svg/starEmpty.svg",
                alt: "",
                onClick: ()=>{
                    setRating(i);
                }
            }, i));
        }
        return res;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full px-4",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full max-w-2xl p-2 mx-auto bg-white rounded-2xl",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Disclosure, {
                children: ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Disclosure.Button, {
                                    className: `flex justify-center font-medium text-left w-36 text-xs bg-transparent text-black-373933 border-2 border-black-373933 rounded-lg font-bebas' style={{ letterSpacing: '1.5px' }}`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-center items-center h-12 gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: "/svg/pencil.svg",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "font-bold",
                                                children: "Write a review"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headlessui_react__WEBPACK_IMPORTED_MODULE_1__.Disclosure.Panel, {
                                className: "px-4 pt-4 pb-2",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSubmit,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-row justify-center gap-14",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "pb-1 block text-sm font-medium text-black-1c2023 sm:mt-px sm:pt-2",
                                                            htmlFor: "author",
                                                            children: "Name"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "mt-1 sm:mt-0 sm:col-span-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "text",
                                                                name: "author",
                                                                id: "author",
                                                                className: "max-w-lg shadow-sm block w-full text-sm border border-black-373933 pl-4 py-2",
                                                                placeholder: "Enter your name",
                                                                required: true
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "pb-1 block text-sm font-medium text-black-1c2023 sm:mt-px sm:pt-2",
                                                            htmlFor: "email",
                                                            children: "Email"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "mt-1 sm:mt-0 sm:col-span-2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "text",
                                                                name: "email",
                                                                id: "email",
                                                                className: "max-w-lg shadow-sm block w-full text-sm border border-black-373933 pl-4 py-2",
                                                                placeholder: "john.smith@example.com",
                                                                required: true
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pt-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "font-medium text-sm text-black-1c2023 pb-1",
                                                    children: "Rating"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "flex justify-start",
                                                    children: mapStars()
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full pt-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "pb-1 block text-sm font-medium text-black-1c2023",
                                                    htmlFor: "reviewTitle",
                                                    children: "Title of Review"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        name: "reviewTitle",
                                                        id: "reviewTitle",
                                                        className: "shadow-sm block w-full text-sm border border-black-373933 pl-4 py-2",
                                                        placeholder: "Give your review a title",
                                                        required: true
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "pt-5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "pb-1 block text-sm font-medium text-black-1c2023 sm:mt-px sm:pt-2",
                                                    htmlFor: "experience",
                                                    children: "How was your overall experience?"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mt-1 sm:mt-0",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                        id: "experience",
                                                        name: "experience",
                                                        rows: 3,
                                                        className: "shadow-sm block w-full text-sm border border-black-373933 pl-4 pt-2",
                                                        defaultValue: "",
                                                        placeholder: "Describe the experience with the product",
                                                        required: true
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "pt-7",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "max-w-lg flex items-center gap-8",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "relative flex items-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex items-center h-5",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                id: "option",
                                                                name: "option",
                                                                type: "checkbox",
                                                                className: "focus:ring-red-bc2026 h-4 w-4 text-red-bc2026 border-gray-300 rounded",
                                                                defaultChecked: true
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "ml-3 text-sm",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                className: "font-medium text-gray-700",
                                                                htmlFor: "checkbox",
                                                                children: "I recommend this product"
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "pt-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-end",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "submit",
                                                    className: "ml-3 inline-flex justify-center py-2 px-4 w-32 border border-transparent shadow-sm text-sm font-roboto rounded-lg text-white bg-black",
                                                    disabled: submit !== 0,
                                                    children: submit === 0 ? "Submit" : submit === 1 ? "Submitting..." : "Submitted"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var services_stamped__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(733);




const Reviews = ({ reviews  })=>{
    const mapRating = (rating)=>{
        const arr = [];
        for(let i = 0; i < 5; i++){
            arr.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: Math.round(rating) > i ? "/svg/star.svg" : "/svg/starEmpty.svg",
                width: 22,
                height: 21,
                alt: ""
            }, i));
        }
        return arr;
    };
    const handleVote = async (index, vote)=>{
        const res = await (0,services_stamped__WEBPACK_IMPORTED_MODULE_3__/* .voteReview */ .Vb)(reviews[index].id, vote);
        if (res) {
            if (vote) {
                document.getElementById(`${index}up`)?.setAttribute("fill", "#bc2026");
                document.getElementById(`${index}down`)?.setAttribute("fill", "#373933");
            } else {
                document.getElementById(`${index}up`)?.setAttribute("fill", "#373933");
                document.getElementById(`${index}down`)?.setAttribute("fill", "#bc2026");
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: reviews.map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-12 h-12 rounded-full bg-red-bc2026 mr-4 mt-1 flex justify-center items-center font-bebas text-2xl italic text-white-f2f9fa",
                                    children: item.name.split(" ").map((i)=>i.charAt(0).toUpperCase())
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-2/4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-black-373933 font-bebas font-bold italic text-2xl w-2/4",
                                                    children: item.name
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-2/4 flex justify-end",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-gray-char font-roboto",
                                                    children: item.date
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex justify-center lg:justify-start pb-2",
                                        children: mapRating(item.rating)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 font-bebas font-bold italic text-2xl",
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-black-1c2023 font-roboto",
                                        children: item.description
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex justify-end items-center gap-3",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                children: "Was this helpful?"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>{
                                                    handleVote(index, true);
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "16.76",
                                                    height: "15.236",
                                                    viewBox: "0 0 16.76 15.236",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        id: `${index}up`,
                                                        "data-name": "Icon material-thumb-up",
                                                        d: "M1.5,16.736H4.547V7.594H1.5Zm16.76-8.38a1.528,1.528,0,0,0-1.524-1.524H11.929l.724-3.481.023-.244a1.147,1.147,0,0,0-.335-.808l-.808-.8L6.52,6.52a1.49,1.49,0,0,0-.449,1.074v7.618a1.528,1.528,0,0,0,1.524,1.524h6.856a1.513,1.513,0,0,0,1.4-.929l2.3-5.371a1.505,1.505,0,0,0,.107-.556V8.425l-.008-.008Z",
                                                        transform: "translate(-1.5 -1.5)",
                                                        fill: "#373933"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                children: item.numLikes
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ()=>{
                                                    handleVote(index, false);
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "16.76",
                                                    height: "15.236",
                                                    viewBox: "0 0 16.76 15.236",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        id: `${index}down`,
                                                        "data-name": "Icon material-thumb-up",
                                                        d: "M1.5,16.736H4.547V7.594H1.5Zm16.76-8.38a1.528,1.528,0,0,0-1.524-1.524H11.929l.724-3.481.023-.244a1.147,1.147,0,0,0-.335-.808l-.808-.8L6.52,6.52a1.49,1.49,0,0,0-.449,1.074v7.618a1.528,1.528,0,0,0,1.524,1.524h6.856a1.513,1.513,0,0,0,1.4-.929l2.3-5.371a1.505,1.505,0,0,0,.107-.556V8.425l-.008-.008Z",
                                                        transform: "translate(18.26 16.736) rotate(180)",
                                                        fill: "#373933"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                children: item.numDislikes
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b text-gray-char max-w-7xl m-auto pt-2"
                    })
                ]
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Reviews);


/***/ }),

/***/ 6721:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8702);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);





const ImgPagSlider = ({ bgImage  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    if (false) { var current, thumbnails; }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full max-w-7xl m-auto",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.Splide, {
                ref: sliderRef,
                options: {
                    pagination: false,
                    gap: "1rem",
                    type: "loop",
                    width: "100%",
                    autoWidth: false
                },
                /*onClick={(splide) => {
          
          for ( var i = 0; i < thumbnails.length; i++ ) {
            initThumbnail( thumbnails[ i ], i );
          }
          
          function initThumbnail( thumbnail: Element, index: number ) {
            thumbnail.addEventListener( 'click', function () {
              splide.go( index );
            } );
          }
        }}*/ onMoved: (splide)=>{
                    // Update the bar width. CSS is found on components.css
                    if (current) {
                        current.classList.remove("is-active");
                    }
                    // Splide#index returns the latest slide index:
                    var thumbnail = thumbnails[splide.index];
                    if (thumbnail) {
                        thumbnail.classList.add("is-active");
                        current = thumbnail;
                    }
                },
                children: bgImage.map((b, i)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.SplideSlide, {
                        className: "flex",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                className: "w-full",
                                src: b.url,
                                alt: ""
                            }, i),
                            b.btn3d ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: "flex items-center justify-center gap-2 absolute bg-white rounded-xl h-9 w-24 border-2 shadow-2xl mt-4 ml-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: "/svg/3d.svg",
                                        width: "24",
                                        height: "24"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 font-roboto text-sm",
                                        children: "View"
                                    })
                                ]
                            }) : null
                        ]
                    }, i);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "thumbnails",
                className: "thumbnails",
                children: bgImage.map((b, i)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "thumbnail",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: b.url,
                            alt: ""
                        })
                    }, i);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgPagSlider);


/***/ }),

/***/ 7858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Blacktitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Blacktitle({ title , textSize , textColor , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center lg:justify-start",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: `${textColor} ${textSize} font-bebas font-bold italic text-center md:text-left`,
                    children: title
                })
            })
        })
    });
};


/***/ }),

/***/ 1724:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8969);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7341);
/* harmony import */ var _components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8134);
/* harmony import */ var _components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6731);
/* harmony import */ var _components_ui_bodykore_Image__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6292);
/* harmony import */ var _components_ui_bodykore_NavOptions_BlackNavOptions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(864);
/* harmony import */ var _components_ui_bodykore_NavOptions_SwitchPagesOptions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6673);
/* harmony import */ var _components_ui_bodykore_Sections_Factors__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8432);
/* harmony import */ var _components_ui_bodykore_Sections_ImgDescription__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(273);
/* harmony import */ var _components_ui_bodykore_Sections_Product__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1573);
/* harmony import */ var _components_ui_bodykore_Sections_ReviewForm__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(6490);
/* harmony import */ var _components_ui_bodykore_Sections_Reviews__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(3195);
/* harmony import */ var _components_ui_bodykore_Sliders_ImgPagSlider__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6721);
/* harmony import */ var _components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(1332);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(6903);
/* harmony import */ var _components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(9358);
/* harmony import */ var _components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(4348);
/* harmony import */ var _components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7858);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9641);
/* harmony import */ var _lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8185);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4725);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2780);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5852);
/* harmony import */ var services_stamped__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(733);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8099);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_10__, _components_ui_bodykore_Sections_Product__WEBPACK_IMPORTED_MODULE_14__, _components_ui_bodykore_Sections_ReviewForm__WEBPACK_IMPORTED_MODULE_23__]);
([_components_Header__WEBPACK_IMPORTED_MODULE_10__, _components_ui_bodykore_Sections_Product__WEBPACK_IMPORTED_MODULE_14__, _components_ui_bodykore_Sections_ReviewForm__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




























const getStaticPaths = async ()=>{
    const products = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__/* .getAllProductsSlug */ ._s)();
    const paths = products.map((item)=>({
            params: {
                slug: item.node.handle
            }
        })).flat();
    return {
        paths: [
            ...paths
        ],
        fallback: "blocking"
    };
};
const getStaticProps = async (context)=>{
    const { slug  } = context.params;
    const product = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__/* .getProduct */ .wv)(slug);
    if (product === undefined) {
        return {
            notFound: true
        };
    }
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_3__/* .getHeader */ .P)();
    let CMSData;
    if (product.collections.edges.length !== 0) {
        CMSData = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_4__/* .getCMSCollectionPage */ .d5)(product.collections.edges[0].node.handle);
    }
    const productIdDecoded = Buffer.from(product.id, "base64").toString();
    const productId = productIdDecoded.slice(productIdDecoded.lastIndexOf("/") + 1);
    const reviews = await (0,services_stamped__WEBPACK_IMPORTED_MODULE_5__/* .getReviewsOfProduct */ .nX)(productId);
    const recommendations = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__/* .getProductRecommendations */ .vp)(product.id);
    return {
        props: {
            product,
            reviews,
            recommendations,
            header,
            CMSData,
            productId
        },
        revalidate: 30 * 60
    };
};
const ProductPage = ({ product , reviews , recommendations , header , CMSData , productId  })=>{
    const mapImages = ()=>{
        return product.images.edges.map((item)=>({
                url: item.node.url,
                btn3d: true
            }));
    };
    const getRating = ()=>{
        if (reviews === undefined || reviews.length === 0) {
            return 0;
        }
        let sum = 0;
        for (let review of reviews){
            sum += review.reviewRating;
        }
        return sum / reviews.length;
    };
    const mapOptions = ()=>{
        return product.variants.edges.map((item)=>({
                title: item.node.title,
                id: item.node.id,
                price: item.node.priceV2.amount,
                prevPrice: item.node.compareAtPriceV2?.amount,
                img: item.node.image?.url,
                available: item.node.availableForSale
            }));
    };
    const mapReviews = ()=>{
        return (reviews || []).map((item, index)=>({
                id: item.id,
                name: item.author,
                rating: item.reviewRating,
                title: item.reviewTitle,
                date: item.reviewDate,
                description: item.reviewMessage,
                numLikes: item.reviewVotesUp,
                numDislikes: item.reviewVotesDown
            }));
    };
    const scrollDown = ()=>{
        const element = document.getElementById("reviews");
        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }
    };
    const mapProducts = ()=>{
        return recommendations.map((item)=>({
                id: item.variants.edges[0].node.id,
                slug: item.handle,
                bgImg: item.featuredImage?.url,
                title: item.title,
                price: item.variants.edges[0].node.priceV2.amount,
                comparePrice: item.variants.edges[0].node.compareAtPriceV2?.amount,
                description: item.description,
                available: item.availableForSale
            }));
    };
    // Only call if CMSData is not undefined, the product belogs to a collection,
    // and it is not 'Packages', as there are no subcategorization.
    const mapSubcategories = ()=>{
        return [];
        return CMSData.category.subcategories.map((item)=>({
                url: item.image?.url,
                topTitle: item.name,
                title: item.name,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}?category=${product.collections.edges[0].node.title}&subcategory=${item.name}`
            }));
    };
    const switchPage = [
        {
            icon: "/svg/home.svg",
            text: "Products",
            arrow: "/svg/rightArrow.svg",
            link: _config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path
        }, 
    ];
    if (product.collections.edges.length !== 0) {
        switchPage.push({
            text: product.collections.edges[0].node.title,
            arrow: "/svg/rightArrow.svg",
            link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].collection.path */ .Z.collection.path}/${product.collections.edges[0].node.handle}`
        });
    }
    if (product.productType !== "") {
        switchPage.push({
            text: product.productType,
            arrow: "/svg/rightArrow.svg",
            link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}?category=${product.collections.edges[0].node.title}&subcategory=${product.productType}`
        });
    }
    switchPage.push({
        text: product.title
    });
    const size = (0,_lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    let widthSize = size.width;
    const keyPerformanceFactors = product.keyFactor?.value.split(",");
    const mapHighlights = ()=>{
        if (!product.highList || !product.highImages) {
            return [];
        }
        const highList = product.highList?.value.split(",");
        return product.highImages?.value.split(",").map((item, index)=>({
                img: item,
                description: highList[index] || ""
            }));
    };
    // dynamically change seo title
    const dinamycSeo = ()=>{
        return _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_8__/* .singleProduct */ .ej;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                seo: dinamycSeo()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-10 px-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_NavOptions_SwitchPagesOptions__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            options: switchPage
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-4 px-6 max-w-7xl m-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: product.title,
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex lg:flex-row flex-wrap justify-center md:justify-start max-w-7xl m-auto px-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "md:w-1/2 w-96 pr-8",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_ImgPagSlider__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    bgImage: [
                                        {
                                            url: "/Product/ProdSlider1.jpg"
                                        },
                                        {
                                            url: "/Product/ProdSlider2.png"
                                        },
                                        {
                                            url: "/Product/ProdSlider3.png"
                                        },
                                        {
                                            url: "/Product/ProdSlider4.png"
                                        }, 
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "md:w-1/2 w-96",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_Product__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                        affirmMonthly: "$60/mo",
                                        affirmTax: "at 0%",
                                        affirmLogo: "/Product/affirm.jpg",
                                        rating: getRating(),
                                        numReviews: reviews?.length || 0,
                                        description: product.description,
                                        shippingCost: "* Estimated Shipping cost: $???.00",
                                        options: mapOptions(),
                                        reviewOnClick: scrollDown
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "pt-8 flex flex-wrap justify-center pb-5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_Factors__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            textSize: "text-xs",
                                            factors: [
                                                {
                                                    icon: "/Product/warranty.jpg",
                                                    title: "10-YEAR INDUSTRY LEADING WARRANTY",
                                                    description: "Conditions may apply."
                                                },
                                                {
                                                    icon: "/Product/commercial.jpg",
                                                    title: "COMMERCIAL GRADE EQUIPMENT",
                                                    description: "Lorem ipsum"
                                                },
                                                {
                                                    icon: "/Product/assembly.jpg",
                                                    title: "EASY ASSEMBLY",
                                                    description: "Professional installation not required."
                                                }, 
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-28'",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_NavOptions_BlackNavOptions__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                            height: "h-fit",
                            options: [
                                {
                                    icon: "/svg/paper.svg",
                                    text: "Description",
                                    id: "description"
                                },
                                {
                                    icon: "/svg/highlight.svg",
                                    text: "Highlights",
                                    id: "highlights"
                                },
                                {
                                    icon: "/svg/key.svg",
                                    text: "Key Performance Factors",
                                    id: "key"
                                },
                                {
                                    icon: "/svg/paper.svg",
                                    text: "Specifications",
                                    id: "specifications"
                                },
                                {
                                    icon: "/svg/reviewStar.svg",
                                    text: "Reviews",
                                    id: "reviews"
                                }, 
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                        height: "h-28",
                        id: "description"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "max-w-7xl m-auto px-8 flex justify-center lg:justify-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "DESCRIPTION",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row flex-wrap justify-center max-w-7xl m-auto pb-20 gap-4 px-8",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "lg:w-2/4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "py-5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            textColor: "text-black-373933",
                                            textPosition: "lg:text-left",
                                            paragraphs: [
                                                {
                                                    description: product.descSummary?.value
                                                }, 
                                            ]
                                        })
                                    }),
                                    product.descFeatures ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "pb-2",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    title: "FEATURES",
                                                    textSize: "text-2xl",
                                                    textColor: "text-red-bc2026"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                textColor: "text-black-1c2023",
                                                List: product.descFeatures?.value.split(",").map((item)=>({
                                                        text: item
                                                    }))
                                            })
                                        ]
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-2/4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Image__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                    img: product.descImage?.value,
                                    buttons: []
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                        height: "h-28",
                        id: "highlights"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center pb-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "HIGHLIGHTS",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-8 pt-10 pb-36",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_ImgDescription__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                            imgHeight: "h-72",
                            imgWidth: "w-72",
                            textSize: "text-sm",
                            images: mapHighlights()
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                        height: "h-28",
                        id: "key"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-4 max-w-7xl m-auto px-8 flex justify-center lg:justify-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "KEY PERFORMANCE FACTORS",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-20 px-8 flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_Factors__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            division: "lg:divide-x divide-black-373933",
                            textSize: "text-lg",
                            factors: [
                                {
                                    icon: "/svg/warranty.svg",
                                    title: keyPerformanceFactors ? keyPerformanceFactors[0] : ""
                                },
                                {
                                    icon: "/svg/dollar.svg",
                                    title: keyPerformanceFactors ? keyPerformanceFactors[1] : ""
                                },
                                {
                                    icon: "/svg/assembly.svg",
                                    title: keyPerformanceFactors ? keyPerformanceFactors[2] : ""
                                }, 
                            ],
                            imgHeight: "h-10 lg:h-16",
                            imgWidth: "h-10 lg:h-16"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                        height: "h-28",
                        id: "specifications"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-4 max-w-7xl m-auto px-8 flex justify-center lg:justify-start",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "SPECIFICATIONS",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "px-8 flex justify-center lg:justify-start",
                        children: [
                            product.specList ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                textColor: "text-black-373933",
                                List: product.specList.value.split(",").map((item)=>({
                                        text: item
                                    }))
                            }) : null,
                            product.specImages ? product.specImages.value.split(",").map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Image__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                    img: item,
                                    buttons: []
                                }, index)) : null
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                        height: "h-28",
                        id: "reviews"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-4 max-w-7xl m-auto px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: `REVIEWS (${reviews?.length || 0})`,
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_Reviews__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                            reviews: mapReviews()
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-20",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_ReviewForm__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                            productId: productId
                        })
                    }),
                    recommendations.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pb-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                title: "PRODUCT RECOMMENDATIONS",
                                textSize: "text-5xl",
                                textColor: "text-black-373933"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                gap: "gap-12",
                                cards: mapProducts()
                            })
                        ]
                    }) : null,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-32 px-8",
                        children: product.collections.edges.length !== 0 && product.collections.edges[0].node.title !== "Packages" && CMSData !== undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (()=>{
                                if (widthSize !== undefined && widthSize >= 800) {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                        title1: "ALL",
                                        title2: product.collections.edges[0].node.title,
                                        btnText: `SEE ALL ${product.collections.edges[0].node.title}`,
                                        btnBorder: "border-black-373933",
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}?category=${product.collections.edges[0].node.title}`,
                                        border: "border-2",
                                        bgImage: mapSubcategories()
                                    });
                                } else {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                        title1: "ALL",
                                        title2: product.collections.edges[0].node.title,
                                        color1: "text-red-bc2026",
                                        color2: "text-black-373933",
                                        btnText: `SEE ALL ${product.collections.edges[0].node.title}`,
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}?category=${product.collections.edges[0].node.title}`,
                                        bgImage: mapSubcategories(),
                                        gap: "gap-20",
                                        pb: "py-4"
                                    });
                                }
                            })()
                        }) : null
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 1143:
/***/ ((module) => {

module.exports = require("@heroicons/react/solid");

/***/ }),

/***/ 8702:
/***/ ((module) => {

module.exports = require("@splidejs/react-splide");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4342:
/***/ ((module) => {

module.exports = require("localstorage-slim");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,6903,6731,8185,1332,1759,1864,273], () => (__webpack_exec__(1724)));
module.exports = __webpack_exports__;

})();