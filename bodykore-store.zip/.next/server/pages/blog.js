"use strict";
(() => {
var exports = {};
exports.id = 9195;
exports.ids = [9195];
exports.modules = {

/***/ 224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Pagination)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Pagination({ title , current , max , setter  }) {
    function setPage(value) {
        setter((prevState)=>({
                ...prevState,
                page: value
            }));
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "py-16",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "flex justify-center gap-8",
                    children: [
                        current > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-red-bc2026 transition-colors duration-150",
                                onClick: ()=>setPage(current - 1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "12.885",
                                    height: "8.525",
                                    viewBox: "0 0 12.885 8.525",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        id: "Vector_7",
                                        "data-name": "Vector 7",
                                        d: "M0,3.343H11.316m0,0L7.972,0m3.343,3.343L7.972,6.687",
                                        transform: "scale(-1 1) translate(-12.235 0.919)",
                                        fill: "none",
                                        stroke: "#bc2026",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.3"
                                    })
                                })
                            })
                        }),
                        current === max && current > 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-gray-char transition-colors duration-150",
                                onClick: ()=>setPage(current - 2),
                                children: current - 2
                            })
                        }),
                        current > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-gray-char transition-colors duration-150",
                                onClick: ()=>setPage(current - 1),
                                children: current - 1
                            })
                        }),
                        max > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-red-bc2026 transition-colors duration-150",
                                children: current
                            })
                        }),
                        current < max && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-gray-char transition-colors duration-150",
                                onClick: ()=>setPage(current + 1),
                                children: current + 1
                            })
                        }),
                        current === 1 && current < max - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-gray-char transition-colors duration-150",
                                onClick: ()=>setPage(current + 2),
                                children: current + 2
                            })
                        }),
                        current < max && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "h-10 text-red-bc2026 transition-colors duration-150",
                                onClick: ()=>setPage(current + 1),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "12.885",
                                    height: "8.525",
                                    viewBox: "0 0 12.885 8.525",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        id: "Vector_7",
                                        "data-name": "Vector 7",
                                        d: "M0,3.343H11.316m0,0L7.972,0m3.343,3.343L7.972,6.687",
                                        transform: "translate(0.65 0.919)",
                                        fill: "none",
                                        stroke: "#bc2026",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "1.3"
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};


/***/ }),

/***/ 8010:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(658);
/* harmony import */ var _components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9290);
/* harmony import */ var _components_ui_bodykore_Cards_BlogCards__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4488);
/* harmony import */ var _components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7858);
/* harmony import */ var _components_ui_bodykore_Pagination__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(224);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var utils_date__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1223);
/* harmony import */ var _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5076);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4725);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8969);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_8__]);
_components_Header__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const getStaticProps = async (context)=>{
    const articles = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getAllArticles */ .zC)();
    const categories = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getArticleCategories */ .Um)();
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_3__/* .getHeader */ .P)();
    return {
        props: {
            articles,
            categories,
            header
        },
        revalidate: 30 * 60
    };
};
const Blog = ({ articles , categories , header  })=>{
    const { 0: filter , 1: setFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        page: 1,
        category: ""
    });
    const { 0: maxArticles , 1: setMaxArticles  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(Math.ceil(articles.length / _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_ARTICLES */ .Gr));
    const { 0: articlesShow , 1: setArticlesShow  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(articles);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const { page , category  } = filter;
        let displayedArticles = articles;
        if (category !== "") {
            displayedArticles = articles.filter((item)=>item.category?.slug === category);
        }
        setArticlesShow(displayedArticles.slice((page - 1) * _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_ARTICLES */ .Gr, page * _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_ARTICLES */ .Gr));
        setMaxArticles(Math.ceil(displayedArticles.length / _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_ARTICLES */ .Gr));
    }, [
        filter
    ]);
    const mapCategories = ()=>{
        return categories.map((item)=>({
                text: item.title,
                id: item.slug
            }));
    };
    const mapArticles = ()=>{
        return articlesShow.map((item)=>({
                img: item.image?.url,
                topic: item.category?.title,
                date: (0,utils_date__WEBPACK_IMPORTED_MODULE_5__/* .dateFormat */ .v)(item.date),
                title: item.title,
                description: item.description,
                slug: item.slug
            }));
    };
    const mapFeatured = ()=>{
        return articles.slice(0, _config_siteConfig__WEBPACK_IMPORTED_MODULE_4__/* .NUM_FEATURED */ .uA).map((item)=>({
                img: item.image?.url,
                topic: item.category?.title,
                date: (0,utils_date__WEBPACK_IMPORTED_MODULE_5__/* .dateFormat */ .v)(item.date),
                title: item.title,
                description: item.description,
                slug: item.slug
            }));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__/* .blog */ .tQ
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        title: "BODYKORE BLOG",
                        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non velit sapien. Mauris et ante in quam pretium malesuada ac a massa. Vestibulum lacinia augue et dolor ullamcorper efficitur.",
                        bgImage: "/Blog/coverImage.jpg"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        id: "belowBanner",
                        className: "flex flex-row flex-wrap-reverse justify-center lg:justify-start max-w-7xl m-auto px-8 gap-8 lg:gap-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-1/2 pt-14 lg:pl-20",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    title: "LATEST ARTICLES",
                                    textSize: "text-5xl",
                                    textColor: "text-black-373933"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:w-1/2 flex justify-end lg:pr-24 pt-10 lg:pt-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    title1: "ALL",
                                    titles: mapCategories(),
                                    type: filter.category,
                                    setter: setFilter
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_BlogCards__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        card: mapArticles()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Pagination__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        current: filter.page,
                        setter: setFilter,
                        max: maxArticles
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:pl-48",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            title: "FEATURED ARTICLES",
                            textSize: "text-5xl",
                            textColor: "text-black-373933"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pb-28",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_BlogCards__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            card: mapFeatured()
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Blog);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,658,9290,6336], () => (__webpack_exec__(8010)));
module.exports = __webpack_exports__;

})();