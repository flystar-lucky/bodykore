"use strict";
(() => {
var exports = {};
exports.id = 4052;
exports.ids = [4052];
exports.modules = {

/***/ 3003:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ bodykore_Video)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-player"
const external_react_player_namespaceObject = require("react-player");
var external_react_player_default = /*#__PURE__*/__webpack_require__.n(external_react_player_namespaceObject);
;// CONCATENATED MODULE: ./components/ui/bodykore/Video.tsx



const Video = ({ title1 , title2 , description , videos , id  })=>{
    const sliderRef = (0,external_react_.useRef)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        id: id,
        className: "max-w-7xl m-auto pb-28 lg:pl-20",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex justify-center lg:justify-start lg:pl-14",
                style: {
                    letterSpacing: "1px"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-red-bc2026 text-5xl font-bebas font-bold italic",
                        children: title1
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-black-373933 text-5xl pl-2 font-bebas font-bold italic",
                        children: title2
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "lg:pl-14 py-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-black-1c2023 text-center lg:text-left",
                    children: description
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex flex-wrap justify-center lg:justify-start gap-12 px-8 lg:px-0 lg:pl-14 h-fit",
                children: videos.map((video, i)=>{
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((external_react_player_default()), {
                                className: "video_player_index",
                                url: video.url,
                                loop: true,
                                controls: true,
                                width: "470px",
                                config: {
                                    file: {
                                        attributes: {
                                            controlsList: "nodownload"
                                        }
                                    }
                                },
                                onPlay: ()=>{}
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "font-bebas text-2xl text-black-373933 pt-4",
                                children: video.title
                            }, i)
                        ]
                    }, i);
                })
            })
        ]
    });
};
/* harmony default export */ const bodykore_Video = (Video);


/***/ }),

/***/ 588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_bodykore_Banners_FadingBanner__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9913);
/* harmony import */ var _components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9290);
/* harmony import */ var _components_ui_bodykore_Video__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3003);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6580);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4725);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8969);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_7__]);
_components_Header__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const getStaticProps = async (context)=>{
    const categories = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getVideoCategories */ .Q)();
    const videos = [];
    for(let i = 0; i < categories.length; i++){
        videos.push(await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getVideosOfCategory */ .B)(categories[i].slug));
    }
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_3__/* .getHeader */ .P)();
    return {
        props: {
            videos,
            categories,
            header
        },
        revalidate: 30 * 60
    };
};
const Videos = ({ videos , categories , header  })=>{
    const mapCategories = ()=>{
        return categories.map((item)=>({
                text: item.title,
                id: item.slug
            }));
    };
    const mapVideos = ()=>{
        return categories.map((item, index)=>{
            const space = item.title.indexOf(" ");
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Video__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                id: item.slug,
                title1: item.title.substring(0, space),
                title2: item.title.substring(space + 1),
                description: item.description,
                videos: videos[index].map((item)=>({
                        url: item.video,
                        title: item.title
                    }))
            }, index);
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_6__/* .videos */ .Ls
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_FadingBanner__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        title: "ALL VIDEOS",
                        bgImage: "bg-manuals-image",
                        description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam non velit sapien. Mauris et ante in quam pretium malesuada ac a massa. Vestibulum lacinia augue et dolor ullamcorper efficitur.",
                        height: "h-72"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_NavOptions_NavOptions__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        title1: "ALL",
                        titles: mapCategories()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "max-w-7xl m-auto pl-14"
                    }),
                    mapVideos()
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Videos);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B": () => (/* binding */ getVideosOfCategory),
/* harmony export */   "Q": () => (/* binding */ getVideoCategories)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getVideoCategories = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query VideoCategories {
      videoCategories {
        title
        slug
        description
      }
    }
  `;
    const res = await graphcms.request(query);
    return res.videoCategories;
};
const getVideosOfCategory = async (slug)=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query VideosOfCategory($slug: String!) {
      videoCategory(where: { slug: $slug }) {
        videos {
          title
          video
        }
      }
    }
  `;
    const variables = {
        slug
    };
    const res = await graphcms.request(query, variables);
    return res.videoCategory === null ? [] : res.videoCategory.videos;
};


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,9290,9913], () => (__webpack_exec__(588)));
module.exports = __webpack_exports__;

})();