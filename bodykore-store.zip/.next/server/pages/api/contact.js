"use strict";
(() => {
var exports = {};
exports.id = 2091;
exports.ids = [2091];
exports.modules = {

/***/ 6521:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
;// CONCATENATED MODULE: ./services/email/config.ts

const EMAIL_CONFIG = {
    EMAIL_TO: process.env.EMAIL_TO,
    HOST: process.env.EMAIL_SMTP_HOST,
    PORT: parseInt(process.env.EMAIL_SMTP_PORT || "0", 10),
    USERNAME: process.env.EMAIL_SMTP_USERNAME,
    PASSWORD: process.env.EMAIL_SMTP_PASSWORD
};
// create reusable transporter object using the default SMTP transport
const getTransporter = ()=>{
    return external_nodemailer_default().createTransport({
        host: EMAIL_CONFIG.HOST,
        port: EMAIL_CONFIG.PORT,
        secure: true,
        pool: true,
        auth: {
            user: EMAIL_CONFIG.USERNAME,
            pass: EMAIL_CONFIG.PASSWORD
        }
    });
};

;// CONCATENATED MODULE: external "dayjs"
const external_dayjs_namespaceObject = require("dayjs");
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_namespaceObject);
;// CONCATENATED MODULE: external "dayjs/plugin/timezone"
const timezone_namespaceObject = require("dayjs/plugin/timezone");
var timezone_default = /*#__PURE__*/__webpack_require__.n(timezone_namespaceObject);
;// CONCATENATED MODULE: external "dayjs/plugin/utc"
const utc_namespaceObject = require("dayjs/plugin/utc");
var utc_default = /*#__PURE__*/__webpack_require__.n(utc_namespaceObject);
;// CONCATENATED MODULE: ./services/email/index.ts




external_dayjs_default().extend((utc_default()));
external_dayjs_default().extend((timezone_default()));
const sendEmail = async (emailData)=>{
    const transporter = getTransporter();
    try {
        const info = await transporter.sendMail({
            from: EMAIL_CONFIG.USERNAME,
            to: EMAIL_CONFIG.EMAIL_TO,
            subject: `Contact inqury from ${emailData.name}`,
            html: toHTML({
                ...emailData
            })
        });
        transporter.close();
        return {
            status: true,
            messageId: info.messageId
        };
    } catch (e) {
        console.error(e); // Uncomment for dev
        transporter.close();
        return {
            status: false,
            messageId: "Failed to send email"
        };
    }
};
const toHTML = ({ name , phone , email , message , timestamp  })=>{
    return `<!DOCTYPE html>
        <html>
        <body>
        <h3>Contact Inquiry</h3>
        <p>First name: ${name || ""}</p>
        <p>Email: ${email || ""}</p>
        <p>Phone: ${phone || ""}</p>
        <p>Message: ${message || ""}</p>
        <p>Date, Time: ${external_dayjs_default()(timestamp).tz("America/Los_Angeles").format("MMM DD YYYY, HH:mm") || ""}</p>
        </body>
        </html>`;
};

;// CONCATENATED MODULE: ./pages/api/contact.tsx

async function handler(req, res) {
    const body = JSON.parse(req.body);
    const emailStatus = await sendEmail({
        ...body
    });
    if (emailStatus.status) {
        return res.status(200).json(true);
    }
    return res.status(200).json(false);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6521));
module.exports = __webpack_exports__;

})();