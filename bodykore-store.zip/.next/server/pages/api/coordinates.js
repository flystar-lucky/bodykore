"use strict";
(() => {
var exports = {};
exports.id = 9334;
exports.ids = [9334];
exports.modules = {

/***/ 6137:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Coordinates)
});

;// CONCATENATED MODULE: ./services/geoapify/index.ts
/**
 * Uses private tokens, functions only on server-side,
 * use method from /services/api for client-side
 * @param zipCode
 * @returns
 */ const getCoordinates = async (zipCode)=>{
    const params = new URLSearchParams();
    params.append("postcode", zipCode);
    params.append("filter", "countrycode:us");
    params.append("format", "json");
    params.append("apiKey", process.env.GEOAPIFY_API_KEY);
    const res = await fetch(`https://api.geoapify.com/v1/geocode/search?${params.toString()}`, {
        method: "GET"
    });
    const resJson = await res.json();
    if (resJson.results.length !== 0) {
        // The query fetches more information than returning below
        return {
            longitude: resJson.results[0].lon,
            latitude: resJson.results[0].lat
        };
    }
    return;
};

;// CONCATENATED MODULE: ./pages/api/coordinates.ts

async function Coordinates(req, res) {
    const coords = await getCoordinates(req.query.zipCode);
    if (coords !== undefined) {
        return res.status(200).json(coords);
    }
    return res.status(400).end();
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6137));
module.exports = __webpack_exports__;

})();