"use strict";
(() => {
var exports = {};
exports.id = 3560;
exports.ids = [3560];
exports.modules = {

/***/ 5313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Wishlist)
});

;// CONCATENATED MODULE: external "graphql-request"
const external_graphql_request_namespaceObject = require("graphql-request");
;// CONCATENATED MODULE: ./services/shopify/admin/config.ts

let graphcms;
function getAdmin() {
    if (!graphcms) {
        graphcms = new external_graphql_request_namespaceObject.GraphQLClient(process.env.SHOPIFY_ADMIN_ENDPOINT, {
            headers: {
                "Content-Type": "application/json",
                "X-Shopify-Access-Token": process.env.SHOPIFY_ADMIN_ACCESS_TOKEN
            }
        });
        return graphcms;
    }
    return graphcms;
};

;// CONCATENATED MODULE: ./services/shopify/admin/customer.ts


const admin = getAdmin();
/**
 * Uses private tokens, functions only on server-side,
 * use method from /services/api for client-side
 * @param ownerId 
 * @param items 
 * @returns 
 */ const updateWishlist = async (ownerId, items)=>{
    const mutation = external_graphql_request_namespaceObject.gql`
    mutation metafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        metafields {
          id
        }
        userErrors {
          field
          message
          code
        }
      }
    }
  `;
    const variables = {
        metafields: [
            {
                ownerId: `gid://shopify/Customer/${ownerId}`,
                namespace: "info",
                key: "wishlist",
                type: "json",
                value: JSON.stringify(items)
            }, 
        ]
    };
    try {
        const res = await admin.request(mutation, variables);
        return res.metafieldsSet;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {
            metafields: [],
            userErrors: []
        };
    }
};
/**
 * Uses private tokens, functions only on server-side,
 * use method from /services/api for client-side
 * @param id 
 * @returns 
 */ const getWishlist = async (id)=>{
    const query = external_graphql_request_namespaceObject.gql`
    query customer($id: ID!) {
      customer(id: $id) {
        metafield(namespace: "info", key: "wishlist") {
          value
        }
      }
    }
  `;
    const variables = {
        id: `gid://shopify/Customer/${id}`
    };
    try {
        const res = await admin.request(query, variables);
        return res.customer === null ? {} : res.customer;
    } catch (error) {
        console.error(JSON.stringify(error, undefined, 2));
        return {};
    }
};

;// CONCATENATED MODULE: ./pages/api/wishlist.ts

async function Wishlist(req, res) {
    let response;
    if (req.method === "POST") {
        const body = JSON.parse(req.body);
        response = await updateWishlist(body.id, body.wishlist);
    } else if (req.method === "GET") {
        response = await getWishlist(req.query.id);
    }
    return res.status(200).json(response);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5313));
module.exports = __webpack_exports__;

})();