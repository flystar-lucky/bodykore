"use strict";
(() => {
var exports = {};
exports.id = 628;
exports.ids = [628];
exports.modules = {

/***/ 9407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DobleColorTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function DobleColorTitle({ title , title2 , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:flex text-center font-bebas text-4xl lg:text-5xl font-bold italic pt-16 max-w-7xl m-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-black-373933 pr-2",
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: " text-red-bc2026 pr-1",
                        children: title2
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 3626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ListTitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function ListTitle({ icon , title , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-start items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: icon,
                        alt: ""
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-black-373933 font-bold text-2xl pl-4",
                        children: title
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 1789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9358);
/* harmony import */ var _components_ui_bodykore_Text_Titles_DobleColorTitle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9407);
/* harmony import */ var _components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3626);
/* harmony import */ var _components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4348);
/* harmony import */ var _components_ui_bodykore_Buttons_TransparentBtn__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7326);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8969);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4725);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_5__]);
_components_Header__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const getStaticProps = async (context)=>{
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_2__/* .getHeader */ .P)();
    return {
        props: {
            header
        },
        revalidate: 30 * 60
    };
};
const AmbTerms = ({ header  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_4__/* .ambTerms */ .Wt
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-4 bg-red-bc2026"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_DobleColorTitle__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            title: "AMBASSADOR PROGRAM",
                            title2: "TERMS AND CONDITIONS"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ml-16 lg:ml-44 lg:mr-72 mt-16 max-w-7xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                icon: "/svg/listLine.svg",
                                title: "Requirements to Join"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-5 px-10 leading-loose",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    textColor: "text-black-1c2023",
                                    textSize: "text-sm lg:text-base",
                                    List: [
                                        {
                                            text: "Currently, BodyKore is only accepting new Affiliates within the U.S."
                                        },
                                        {
                                            text: "Ambassadors must have a health and/or fitness-oriented blog, vlog, website, or social platform to be accepted into the Ambassador."
                                        },
                                        {
                                            text: "Program."
                                        },
                                        {
                                            text: "Pages will be vetted for engagement rate, as well as quality of audience traffic and following."
                                        }, 
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-gray-400 pt-10 mx-44 max-w-7xl m-auto"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ml-16 lg:ml-44 lg:mr-72 mt-16 max-w-7xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                icon: "/svg/listLine.svg",
                                title: "Perks"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-5 px-10 leading-loose",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    textColor: "text-black-1c2023",
                                    textSize: "text-sm lg:text-base",
                                    List: [
                                        {
                                            text: "Commission-based Payouts:",
                                            subText: "- The more customers use your exclusive BodyKore Fitness link, the more money you will make from purchases."
                                        },
                                        {
                                            text: "Exclusive Discount Code:",
                                            subText: "- Discount code provided upon acceptance into the program.",
                                            subText1: "- Code is for personal orders only. Disclosing the code to Family, Friends or Followers will result in removal from the program.",
                                            subText2: "- Discounts have the chance to increase based off performance."
                                        },
                                        {
                                            text: "One-on-One contact with our Ambassador Department",
                                            subText: "- Work with a representative to make manual orders as needed.",
                                            subText1: "- Potential for first dibs on new product drops.",
                                            subText2: "- Allows for quickest shipping times."
                                        }, 
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-gray-400 pt-10 mx-44 max-w-7xl m-auto"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-start pt-10 max-w-7xl m-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Buttons_TransparentBtn__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            text: "SIGN UP",
                            width: "w-48",
                            fontSize: "text-sm"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ml-16 lg:mx-48 lg:mr-72 mt-16 max-w-7xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                icon: "/svg/listLine.svg",
                                title: "Terms and Conditions"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-5 px-10 leading-loose",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    textColor: "text-black-1c2023",
                                    textSize: "text-sm lg:text-base",
                                    List: [
                                        {
                                            text: "You may not use paid advertising in search engines, social media, or other public forums."
                                        },
                                        {
                                            text: "All refunds or returns will be removed from any sales commissions. BodyKore reserves the right to deduct from future commissions for any commissions received from a refunded or returned order."
                                        },
                                        {
                                            text: "You may not receive credit for referring yourself."
                                        },
                                        {
                                            text: "If an Affiliate wishes to announce a new BodyKore product launch, it must be done at least 1 hour after our social media post is released."
                                        },
                                        {
                                            text: "Affiliates/Ambassadors are expected to thoroughly research comparable over-seas manufactured products to ensure they aren\u2019t a BodyKore knock-off prior to engaging in any promotion of the product, especially BodyKore\u2019s top tier products."
                                        },
                                        {
                                            text: "While we understand and appreciate the need to be objective in your reviews, we request a minimum of one (business) days\u2019 notice prior to posting a derogatory or negative review or our products so that we may look to remedy the situation and prepare our responses to customer service inquires accordingly."
                                        },
                                        {
                                            text: "BodyKore will monitor Ambassador content to ensure adherence to new and existing program requirements. BodyKore reserves the right to void Ambassador credit and they will not receive payouts. Additionally, they may be banned from further participation in our Ambassador program."
                                        },
                                        {
                                            text: "If an Ambassador releases a video that contains inaccurate information about a BodyKore product, BodyKore reserves the right to request that Ambassador revise their content with correct information, especially if that information is glaringly incorrect and/or detrimental to sales.",
                                            subText: "- BodyKore reserves the right to stop paying out commissions while videos with incorrect information about BodyKore are active",
                                            subText1: "- BodyKore is happy to answer and clarify any items of importance"
                                        },
                                        {
                                            text: "To remain in the Ambassador program, you must remain an active Ambassador and successfully generate a consistent number of sales: We have the right to terminate any ambassador from the program!"
                                        }, 
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-gray-400 pt-10 mx-44 max-w-7xl m-auto"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ml-16 lg:mx-48 lg:mr-72 mt-16 max-w-7xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                icon: "/svg/listLine.svg",
                                title: "Payout Guidelines"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-5 px-10 leading-loose",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    textColor: "text-black-1c2023",
                                    textSize: "text-sm lg:text-base",
                                    List: [
                                        {
                                            text: "You will need to fill out a W9 form in order to be paid by check at the end of each month."
                                        },
                                        {
                                            text: "You will not receive credit for shipping or sales tax."
                                        },
                                        {
                                            text: "You will not receive credit for referring yourself."
                                        },
                                        {
                                            text: "All earned commissions will be attributed to your account once the sale is displayed as \u201Ccomplete\u201D in our system."
                                        }, 
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-gray-400 pt-10 mx-44 max-w-7xl m-auto"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ml-16 lg:mx-48 lg:mr-80 mt-16 max-w-7xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_ListTitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                icon: "/svg/listLine.svg",
                                title: "Commission Tiers"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-8 pt-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        textSize: "text-sm lg:text-base",
                                        textPosition: "lg:text-left",
                                        paragraphs: [
                                            {
                                                description: "When you become a BodyKore Ambassador, our goal is to develop a win-win, long term relationship with you. We reward your performance and dedication to growing the BodyKore fam by offering the most competitive commission rates in the industry. Each of our two Ambassador tiers feature unique perks like equipment discounts, high earnings, and more! Upon acceptance into the Ambassador program, you\u2019ll automatically become a Tier 1 BodyKore Affiliate. As you grow, you\u2019ll have the opportunity to \u201Cclimb the ladder\u201D to Tier 2 Ambassador."
                                            }, 
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "pt-5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainText__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            textSize: "text-sm lg:text-base",
                                            textPosition: "lg:text-left",
                                            paragraphs: [
                                                {
                                                    description: "More information about how to reach each tier will be provided once you\u2019re accepted in the program. Our commission rates are as follows:"
                                                }, 
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-5 px-10 leading-loose",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_PlainList__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    textColor: "text-black-1c2023",
                                    textSize: "text-sm lg:text-base",
                                    List: [
                                        {
                                            text: "Ambassador \u2013 5% commission"
                                        },
                                        {
                                            text: "Team BodyKore \u2013 10% commission"
                                        }, 
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border-b border-gray-400 pt-10 max-w-7xl m-auto pb-20"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AmbTerms);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,1864,7326], () => (__webpack_exec__(1789)));
module.exports = __webpack_exports__;

})();