"use strict";
(() => {
var exports = {};
exports.id = 8107;
exports.ids = [8107];
exports.modules = {

/***/ 775:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CatPackagesSection1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function CatPackagesSection1({ title1 , title2 , paragraphs , description , img  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto px-8",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center items-center gap-10 lg:gap-32",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "md:w-2/4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "leading-none text-center lg:text-left",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-4xl lg:text-5xl text-red-bc2026 font-bebas font-bold italic text-center lg:text-left",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-black-373933 pr-2",
                                            children: title1
                                        }),
                                        title2
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-2",
                                children: paragraphs.map((p, i)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-black-373933 font-roboto py-3 text-center lg:text-left",
                                        children: p.text
                                    }, i);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: img,
                            alt: ""
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 9561:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9641);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8702);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_checkout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8576);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6734);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9755);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5003);
/* harmony import */ var state_atoms__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7239);











const CatPackagesSection2 = ({ title1 , color1 , title2 , color2 , description , btnText , btnBorder , border , style , link , cards  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const { 0: slideBgColor , 1: setSlideBgColor  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0.5);
    const setCartItems = (0,recoil__WEBPACK_IMPORTED_MODULE_5__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .cartItemsState */ .uZ);
    const setcheckoutUrl = (0,recoil__WEBPACK_IMPORTED_MODULE_5__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .checkoutUrlState */ .g0);
    const setCartTotal = (0,recoil__WEBPACK_IMPORTED_MODULE_5__.useSetRecoilState)(state_atoms__WEBPACK_IMPORTED_MODULE_6__/* .cartTotalState */ .jJ);
    const animateSlide = (bgColor)=>{
        switch(style){
            case "zoom":
                setSlideBgColor(bgColor);
                break;
        }
    };
    const addProduct = async (id)=>{
        const checkoutId = js_cookie__WEBPACK_IMPORTED_MODULE_2___default().get("checkoutId");
        const email = js_cookie__WEBPACK_IMPORTED_MODULE_2___default().get("email");
        let checkout;
        if (checkoutId !== undefined) {
            const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__/* .addItemToCheckout */ .Vx)(checkoutId, id);
            if (res.checkout !== undefined) {
                checkout = res.checkout;
            }
        } else {
            const res1 = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_7__/* .createCheckout */ ._R)(id, email);
            if (res1.checkout !== undefined) {
                checkout = res1.checkout;
                js_cookie__WEBPACK_IMPORTED_MODULE_2___default().set("checkoutId", checkout.id, {
                    expires: 90
                });
            }
        }
        if (checkout !== undefined) {
            setCartItems((0,_utils_checkout__WEBPACK_IMPORTED_MODULE_8__/* .mapCheckout */ .e)(checkout));
            setcheckoutUrl(checkout.webUrl);
            setCartTotal(checkout.subtotalPriceV2.amount);
        } else {
            console.error("Failed to add product");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full max-w-7xl m-auto px-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:flex lg:flex-row pb-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:flex lg:w-2/4 text-center lg:text-left",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${color2} text-4xl xl:text-5xl font-bebas font-bold italic`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `${color1} text-4xl xl:text-5xl font-bebas font-bold italic pr-2`,
                                    children: title1
                                }),
                                title2
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center lg:justify-end lg:w-2/4 py-8 lg:py-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: link || "#",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `w-52 h-12 mb-2 bg-transparent text-black-373933 ${border} ${btnBorder} hover:text-red-bc2026 hover:border-red-bc2026 rounded-lg font-bebas`,
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "font-bold",
                                    children: btnText
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-black-1c2023 lg:w-2/3 pb-8 text-center lg:text-left",
                children: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.Splide, {
                ref: sliderRef,
                options: {
                    pagination: false,
                    gap: "1rem",
                    type: "loop",
                    width: "100%",
                    autoWidth: false,
                    perPage: 3,
                    perMove: 1
                },
                onMoved: (splide)=>{
                    // Update the bar width. CSS is found on components.css
                    const end = splide.Components.Controller.getEnd() + 1;
                },
                children: cards.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.SplideSlide, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: `${_config_routes__WEBPACK_IMPORTED_MODULE_9__/* ["default"].products.path */ .Z.products.path}/${item.slug}`,
                                        passHref: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: item.url,
                                            alt: "",
                                            className: "cursor-pointer"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap items-center justify-between py-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-2xl font-bebas text-black-1c2023",
                                        style: {
                                            letterSpacing: "0.5px"
                                        },
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "font-bebas text-red-bc2026 text-2xl lg:text-4xl font-bold italic pr-2",
                                        children: [
                                            "$",
                                            item.price
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap justify-center gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: `w-56 h-10 mb-2 bg-transparent ${border} ${btnBorder} rounded-md font-bebas ${item.available ? "bg-black-373933 text-white" : "cursor-default"}`,
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        onClick: ()=>{
                                            addProduct(item.id);
                                        },
                                        disabled: !item.available,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-center gap-2",
                                            children: [
                                                item.available ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "16.193",
                                                    height: "16.193",
                                                    viewBox: "0 0 16.193 16.193",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        id: "Icon_material-add-shopping-cart",
                                                        "data-name": "Icon material-add-shopping-cart",
                                                        d: "M9.532,7.669h1.606V5.355h2.41V3.813h-2.41V1.5H9.532V3.813H7.122V5.355h2.41Zm-3.213,6.94A1.543,1.543,0,1,0,7.926,16.15,1.573,1.573,0,0,0,6.319,14.608Zm8.032,0a1.543,1.543,0,1,0,1.606,1.542A1.573,1.573,0,0,0,14.351,14.608ZM6.456,12.1l.024-.093L7.2,10.753h5.984a1.61,1.61,0,0,0,1.406-.794l3.1-5.405-1.4-.74h-.008L15.4,5.355,13.187,9.211H7.548L7.444,9l-1.8-3.647L4.881,3.813,4.126,2.271H1.5V3.813H3.106L6,9.666,4.914,11.555a1.445,1.445,0,0,0-.2.74,1.58,1.58,0,0,0,1.606,1.542h9.638V12.3h-9.3A.2.2,0,0,1,6.456,12.1Z",
                                                        transform: "translate(-1.5 -1.5)",
                                                        fill: "#fff"
                                                    })
                                                }) : null,
                                                item.available ? "ADD TO CART" : "OUT OF STOCK"
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "shadow-lg border border-gray-100 bg-white h-10 w-36",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-xxs pl-2",
                                                children: "As low as"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-end justify-center gap-1",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                        className: "font-bebas text-xl font-bold",
                                                        style: {
                                                            letterSpacing: "0.5px"
                                                        },
                                                        children: item.affirmPrice
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: item.affirmIcon,
                                                        alt: "",
                                                        style: {
                                                            height: "22px",
                                                            width: "44px"
                                                        }
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "pt-8",
                                children: item.options.map((o, i)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center py-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-roboto text-black-1c2023 text-sm lg:text-base",
                                                    children: o
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border-b border-gray-400"
                                            })
                                        ]
                                    }, i);
                                })
                            })
                        ]
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CatPackagesSection2);


/***/ }),

/***/ 8683:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CatPackagesSection3)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


function CatPackagesSection3({ title , description ="" , btnText , bgImage , slug  }) {
    const scrollDown = ()=>{
        const element = document.getElementById("belowBanner");
        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `bg-no-repeat h-screen w-full bg-center bg-cover flex justify-center items-center`,
            style: {
                backgroundImage: `url('${bgImage}'`
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-24 text-center text-white max-w-7xl",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "lg:text-8xl text-6xl w-4/6 italic font-bebas font-bold",
                            style: {
                                letterSpacing: "4px"
                            },
                            children: title
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "w-3/5 pt-10 font-roboto",
                            children: description
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex gap-4 w-full justify-center font-bebas font-bold px-32",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `/${slug}`,
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `mt-16 lg:mt-10 'bg-transparent hover:bg-white text-white hover:text-black' : 'bg-white hover:bg-transparent hover:text-black hover:text-white'} py-3 px-20 border-2 border-white hover:border-transparent rounded-lg text-md`,
                                style: {
                                    letterSpacing: "1.5px"
                                },
                                children: btnText
                            })
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 7854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CatPackagesSection4)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function CatPackagesSection4({ title1 , title2 , paragraphs , bgImage , heightbg , heightGradient  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-4 bg-red-bc2026"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `bg-no-repeat w-full bg-center bg-cover`,
                style: {
                    height: `${heightbg}`,
                    backgroundImage: `url('${bgImage}'`
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `bg-gradient-to-r from-black via-black to-transparent w-full flex items-center`,
                    style: {
                        height: `${heightGradient}`
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row max-w-7xl m-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-white md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex px-14 gap-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "font-bebas text-5xl font-bold italic text-center md:text-left",
                                                style: {
                                                    letterSpacing: "2px"
                                                },
                                                children: title1
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "font-bebas text-5xl font-bold italic text-center md:text-left text-red-bc2026",
                                                style: {
                                                    letterSpacing: "2px"
                                                },
                                                children: title2
                                            })
                                        ]
                                    }),
                                    paragraphs.map((p, i)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-roboto text-sm pt-6 px-12 text-center md:text-left",
                                            children: p.text
                                        }, i);
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-1/2"
                            })
                        ]
                    })
                })
            })
        ]
    });
};


/***/ }),

/***/ 5918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9641);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8702);
/* harmony import */ var _splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);






const SliderPackages = ({ title1 , color1 , title2 , color2 , description , btnText , btnBorder , border , style , link , cards  })=>{
    const sliderRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)();
    const { 0: slideBgColor , 1: setSlideBgColor  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0.5);
    const animateSlide = (bgColor)=>{
        switch(style){
            case "zoom":
                setSlideBgColor(bgColor);
                break;
        }
    };
    const addProduct = async (id)=>{
        return;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full max-w-7xl m-auto px-6",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row pb-2 gap-8 px-16",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex w-1/2",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${color2} text-4xl font-bebas font-bold italic`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: `${color1} text-4xl font-bebas font-bold italic pr-2`,
                                    children: title1
                                }),
                                title2
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-end items-center w-1/2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: link || "#",
                            passHref: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: `w-48 h-10 mb-2 bg-transparent text-black-373933 ${border} ${btnBorder} hover:text-red-bc2026 hover:border-red-bc2026 rounded-lg font-bebas`,
                                style: {
                                    letterSpacing: "1px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "font-bold",
                                    children: btnText
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-roboto text-black-1c2023 lg:w-2/3 pb-8 text-center lg:text-left",
                children: description
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.Splide, {
                ref: sliderRef,
                options: {
                    pagination: false,
                    gap: "1rem",
                    type: "loop",
                    width: "100%",
                    autoWidth: false
                },
                onMoved: (splide)=>{
                    // Update the bar width. CSS is found on components.css
                    const end = splide.Components.Controller.getEnd() + 1;
                },
                children: cards.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_splidejs_react_splide__WEBPACK_IMPORTED_MODULE_1__.SplideSlide, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `${_config_routes__WEBPACK_IMPORTED_MODULE_4__/* ["default"].products.path */ .Z.products.path}/${item.slug}`,
                                    passHref: true,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "bg-no-repeat bg-center bg-cover flex justify-center items-center cursor-pointer mb-5",
                                        style: {
                                            backgroundImage: `url('${item.url}')`,
                                            height: "350px",
                                            width: "600px"
                                        }
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-wrap items-center justify-between pb-5 px-16",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-3xl font-bebas text-black-1c2023",
                                        style: {
                                            letterSpacing: "0.5px"
                                        },
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                        className: "font-bebas text-red-bc2026 text-3xl font-bold italic pr-2",
                                        children: [
                                            "$",
                                            item.price
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row px-16",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-1/2 flex justify-start",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `w-56 h-10 mb-2 bg-transparent ${border} ${btnBorder} rounded-md font-bebas ${item.available ? "bg-black-373933 text-white" : "cursor-default"}`,
                                            style: {
                                                letterSpacing: "1px"
                                            },
                                            onClick: ()=>{
                                                addProduct(item.id);
                                            },
                                            disabled: !item.available,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center justify-center gap-2",
                                                children: [
                                                    item.available ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        width: "16.193",
                                                        height: "16.193",
                                                        viewBox: "0 0 16.193 16.193",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                            id: "Icon_material-add-shopping-cart",
                                                            "data-name": "Icon material-add-shopping-cart",
                                                            d: "M9.532,7.669h1.606V5.355h2.41V3.813h-2.41V1.5H9.532V3.813H7.122V5.355h2.41Zm-3.213,6.94A1.543,1.543,0,1,0,7.926,16.15,1.573,1.573,0,0,0,6.319,14.608Zm8.032,0a1.543,1.543,0,1,0,1.606,1.542A1.573,1.573,0,0,0,14.351,14.608ZM6.456,12.1l.024-.093L7.2,10.753h5.984a1.61,1.61,0,0,0,1.406-.794l3.1-5.405-1.4-.74h-.008L15.4,5.355,13.187,9.211H7.548L7.444,9l-1.8-3.647L4.881,3.813,4.126,2.271H1.5V3.813H3.106L6,9.666,4.914,11.555a1.445,1.445,0,0,0-.2.74,1.58,1.58,0,0,0,1.606,1.542h9.638V12.3h-9.3A.2.2,0,0,1,6.456,12.1Z",
                                                            transform: "translate(-1.5 -1.5)",
                                                            fill: "#fff"
                                                        })
                                                    }) : null,
                                                    item.available ? "ADD TO CART" : "OUT OF STOCK"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-1/2 flex justify-end",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "shadow-lg border border-gray-100 bg-white h-10 w-36",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-xxs pl-2",
                                                    children: "As low as"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-end justify-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                            className: "font-bebas text-xl font-bold",
                                                            style: {
                                                                letterSpacing: "0.5px"
                                                            },
                                                            children: item.affirmPrice
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: item.affirmIcon,
                                                            alt: "",
                                                            style: {
                                                                height: "22px",
                                                                width: "44px"
                                                            }
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "px-14",
                                children: item.options.map((o, i)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "flex justify-center py-5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-roboto text-black-1c2023 text-sm lg:text-base",
                                                    children: o
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border-b border-gray-400"
                                            })
                                        ]
                                    }, i);
                                })
                            })
                        ]
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SliderPackages);


/***/ }),

/***/ 985:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8969);
/* harmony import */ var _components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(658);
/* harmony import */ var _components_ui_bodykore_Sections_CatPackagesSection1__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(775);
/* harmony import */ var _components_ui_bodykore_Sections_CatPackagesSection2__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9561);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderPackages__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5918);
/* harmony import */ var _components_ui_bodykore_Sections_CatPackagesSection3__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8683);
/* harmony import */ var _components_ui_bodykore_Sections_CatPackagesSection4__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7854);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6903);
/* harmony import */ var _lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8185);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9641);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4725);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2780);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5852);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_9__]);
_components_Header__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


















const getStaticProps = async (context)=>{
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_2__/* .getHeader */ .P)();
    const shopifyData = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .getShopifyCollectionPage */ .B2)("packages");
    const CMSData = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_4__/* .getCMSCollectionPage */ .d5)("packages");
    const bundleItems = [];
    for (let product of shopifyData.products.edges){
        const productItems = [];
        if (product.node.metafield) {
            for (let item of product.node.metafield.value.split(",")){
                const res = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .getProductCard */ .rE)(item);
                productItems.push(res.title);
            }
        }
        bundleItems.push(productItems);
    }
    return {
        props: {
            header,
            shopifyData,
            CMSData,
            bundleItems
        },
        revalidate: 30 * 60
    };
};
const AllBenches = ({ header , shopifyData , CMSData , bundleItems  })=>{
    const mapProjects = ()=>{
        return CMSData.projectCategories.map((item)=>({
                url: item.projects[0].image[0].url,
                title: item.title,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path}/${item.projects[0].slug}`
            }));
    };
    const mapProducts = ()=>{
        return shopifyData.products.edges.map((item, index)=>({
                id: item.node.variants.edges[0].node.id,
                slug: item.node.handle,
                url: item.node.featuredImage?.url,
                title: item.node.title,
                price: item.node.variants.edges[0].node.priceV2.amount,
                // comparePrice: item.node.variants.edges[0].node.compareAtPriceV2?.amount,
                // description: item.node.description,
                available: item.node.availableForSale,
                affirmPrice: "$60/mo at",
                affirmIcon: "/Product/affirm.jpg",
                options: bundleItems[index]
            }));
    };
    const size = (0,_lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    let widthSize = size.width;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_8__/* .categoryPackages */ .sX
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        title: "PACKAGES",
                        description: "Bodykore\u2019s home gym packages are designed to fit in any home. Whether there are space constraints or if you\u2019re looking to turn your whole garage into a gym, we have a package that fits.",
                        bgImage: CMSData.category?.cover?.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-32",
                        id: "belowBanner",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_CatPackagesSection1__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            title1: "THE BEST FITNESS EQUIPMENT IN EVERY",
                            title2: "BODYKORE PACKAGE",
                            paragraphs: [
                                {
                                    text: "At BodyKore, we have the best complete fitness equipment, either if you are looking for commercial gym equipment or fitness equipment to build your gym at home. In our catalog, you will find a wide range of packages containing several products to start or upgrade your commercial studio or private fitness room, including some of our world-class machines and other accessories like benches or weights."
                                },
                                {
                                    text: "The fitness equipment included in all our packages provides all necessary items for training your body to the maximum level and going that extra mile, from functional training to bodybuilding, from compound workouts to isolation exercises, from starter to professional level. There\u2019s a package for everyone, and all of them are of the highest quality."
                                }
                            ],
                            img: "/Packages-category/Section1.png"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (()=>{
                            if (widthSize !== undefined && widthSize >= 800) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "pt-10 pb-28",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_CatPackagesSection2__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        title1: "OUR",
                                        color1: "text-black-373933",
                                        title2: "PACKAGES",
                                        color2: "text-red-bc2026",
                                        btnText: "SEE ALL PACKAGES",
                                        border: "border",
                                        btnBorder: "border-black-373933",
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=Packages`,
                                        cards: mapProducts()
                                    })
                                });
                            } else {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "pt-10 pb-28",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderPackages__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                        title1: "OUR",
                                        color1: "text-black-373933",
                                        title2: "PACKAGES",
                                        color2: "text-red-bc2026",
                                        btnText: "SEE ALL PACKAGES",
                                        border: "border",
                                        btnBorder: "border-black-373933",
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=Packages`,
                                        cards: mapProducts()
                                    })
                                });
                            }
                        })()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_CatPackagesSection3__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        title: "VIDEO SECTION",
                        description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore.",
                        bgImage: "/Packages-category/VideoSection.png",
                        btnText: "SEE MORE",
                        slug: "videos"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_CatPackagesSection4__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                        title1: "WHY CHOOSE",
                        title2: "US",
                        paragraphs: [
                            {
                                text: "The fitness equipment included in every package has been carefully selected to fulfill the needs of each profile of fitness enthusiast, depending on the type of training you like, the space you have available, or if you are looking for commercial gym equipment or equipment for private use, for which we have prepared six different packages: Dynamic Package, Universal Gym Package, Home Gym Package, Garage Gym Package, Weight Room Package, and Free Weight Package. Visit our online shop and find your own!"
                            },
                            {
                                text: "BodyKore is a solid brand in the fitness and wellness industry, delivering only products of superior quality. Our fitness equipment is among the best in the market, and helping our customers reach their fitness goals is our main motivation."
                            },
                            {
                                text: "At Bodykore, we are specialists in all kinds of fitness equipment. Our team is made up of professionals who are passionate about the same things you are: fitness, wellness, and empowerment through physical activity."
                            },
                            {
                                text: "If you have any questions or need further advice on which fitness equipment to purchase, you can contact us via telephone, e-mail, or live chat. We are looking forward to hearing from you."
                            }
                        ],
                        bgImage: "/Packages-category/Section2.png",
                        heightbg: "768px",
                        heightGradient: "768px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-28 px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                            title1: "GET",
                            title2: "INSPIRATION",
                            color1: "text-red-bc2026",
                            color2: "text-black-373933",
                            btnText: "PORTFOLIO",
                            link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path,
                            bgImage: mapProjects(),
                            width: "w-1/2"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllBenches);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 8702:
/***/ ((module) => {

module.exports = require("@splidejs/react-splide");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,658,6903,8185], () => (__webpack_exec__(985)));
module.exports = __webpack_exports__;

})();