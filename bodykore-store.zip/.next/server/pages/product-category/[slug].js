"use strict";
(() => {
var exports = {};
exports.id = 1980;
exports.ids = [1980];
exports.modules = {

/***/ 4937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ FadingAndInfo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function FadingAndInfo({ title , description , icon , btnText , bgImage , heightbg , heightGradient , link  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `bg-no-repeat w-full bg-center bg-cover ${bgImage}`,
            style: {
                height: `${heightbg}`
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `bg-gradient-to-r from-black via-black to-transparent w-full flex items-center`,
                    style: {
                        height: `${heightGradient}`
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-row max-w-7xl m-auto",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-white md:w-1/2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-bebas text-5xl font-bold italic px-20 text-center md:text-left",
                                        style: {
                                            letterSpacing: "2px"
                                        },
                                        children: title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-roboto pt-2 px-20 text-center md:text-left",
                                        children: description
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex justify-center md:justify-start",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: link,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "flex gap-2 text-xs text-white border border-white rounded-lg px-8 py-2 mx-20 mt-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: icon,
                                                        alt: ""
                                                    }),
                                                    btnText
                                                ]
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-1/2"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "h-4 bg-red-bc2026"
                })
            ]
        })
    });
};


/***/ }),

/***/ 6565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TextRImg)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function TextRImg({ title , description , img  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-center items-center gap-16",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "md:w-2/5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-black-373933 text-5xl font-bebas font-bold italic text-center lg:text-left",
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-black-373933 font-roboto py-6 text-center lg:text-left w-96",
                                children: description
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: img,
                            alt: ""
                        })
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 7858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Blacktitle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function Blacktitle({ title , textSize , textColor , id  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            id: id,
            className: "max-w-7xl m-auto",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center lg:justify-start",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: `${textColor} ${textSize} font-bebas font-bold italic text-center md:text-left`,
                    children: title
                })
            })
        })
    });
};


/***/ }),

/***/ 2801:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8969);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7341);
/* harmony import */ var _components_ui_bodykore_Banners_FadingAndInfo__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4937);
/* harmony import */ var _components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(658);
/* harmony import */ var _components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6731);
/* harmony import */ var _components_ui_bodykore_Sections_ImgDescription__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(273);
/* harmony import */ var _components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1332);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6903);
/* harmony import */ var _components_ui_bodykore_Text_TextRImg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6565);
/* harmony import */ var _components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7858);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9641);
/* harmony import */ var _lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8185);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4725);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2780);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5852);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8099);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_9__]);
_components_Header__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



















const getStaticPaths = async ()=>{
    const projects = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getAllCategoriesSlug */ .kI)();
    const paths = projects.filter(({ slug  })=>slug != "packages").map(({ slug  })=>({
            params: {
                slug
            }
        })).flat();
    return {
        paths: [
            ...paths
        ],
        fallback: "blocking"
    };
};
const getStaticProps = async (context)=>{
    const { slug  } = context.params;
    const shopifyData = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_3__/* .getShopifyCollectionPage */ .B2)(slug);
    const CMSData = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_2__/* .getCMSCollectionPage */ .d5)(slug);
    if (shopifyData === undefined || CMSData.category === undefined) {
        return {
            notFound: true
        };
    }
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_4__/* .getHeader */ .P)();
    return {
        props: {
            shopifyData,
            header,
            CMSData
        },
        revalidate: 30 * 60
    };
};
const Category = ({ shopifyData , header , CMSData  })=>{
    console.log("hellpo");
    const mapSubcategories = ()=>{
        return CMSData.category.subcategories.map((item)=>({
                url: item.image?.url,
                topTitle: item.name,
                title: item.name,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=${shopifyData.title}&subcategory=${item.name}`
            }));
    };
    const mapProjects = ()=>{
        return CMSData.projectCategories.map((item)=>({
                url: item.projects[0].image[0].url,
                title: item.title,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path}/${item.projects[0].slug}`
            }));
    };
    const mapProducts = ()=>{
        return shopifyData.products.edges.map((item)=>({
                id: item.node.variants.edges[0].node.id,
                slug: item.node.handle,
                bgImg: item.node.featuredImage?.url,
                title: item.node.title,
                price: item.node.variants.edges[0].node.priceV2.amount,
                comparePrice: item.node.variants.edges[0].node.compareAtPriceV2?.amount,
                description: item.node.description,
                available: item.node.availableForSale
            }));
    };
    const mapFeatures = ()=>{
        return CMSData.category.features.map((item)=>({
                img: item.image.url,
                description: item.description
            }));
    };
    const size = (0,_lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    let widthSize = size.width;
    // dynamically change seo title
    const dinamycSeo = ()=>{
        return _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_7__/* .productsCategories */ .m2;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                seo: dinamycSeo()
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        title: shopifyData.title,
                        description: shopifyData.description,
                        bgImage: CMSData.category?.cover?.url
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-44 px-8",
                        id: "belowBanner",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_TextRImg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            title: "DISCOVERING",
                            description: "Bodykore\u2019s home gym packages are designed to fit in any home. Whether there are space constraints or if you\u2019re looking to turn your whole garage into a gym, we have a package that fits.",
                            img: CMSData.category?.discover?.url
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (()=>{
                            if (widthSize !== undefined && widthSize >= 800) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "py-52 px-8",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        title1: "ALL",
                                        color1: "text-red-bc2026",
                                        title2: shopifyData.title,
                                        color2: "text-black-373933",
                                        btnText: `SEE ALL ${shopifyData.title}`,
                                        btnBorder: "border-black-373933",
                                        border: "border-2",
                                        bgImage: mapSubcategories(),
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=${shopifyData.title}`
                                    })
                                });
                            } else {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "py-52 px-8",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                        title1: "ALL",
                                        title2: shopifyData.title,
                                        color1: "text-red-bc2026",
                                        color2: "text-black-373933",
                                        btnText: `SEE ALL ${shopifyData.title}`,
                                        link: `${_config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].products.path */ .Z.products.path}?category=${shopifyData.title}`,
                                        bgImage: mapSubcategories(),
                                        gap: "gap-20",
                                        pb: "py-4"
                                    })
                                });
                            }
                        })()
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            title: "FEATURES",
                            textColor: "text-black-373933",
                            textSize: "text-5xl"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "px-8 pt-10",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_ImgDescription__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            imgHeight: "h-72",
                            imgWidth: "w-72",
                            textSize: "text-sm",
                            images: mapFeatures()
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "pt-52",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_FadingAndInfo__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                            title: "HOW TO...",
                            description: "BodyKore\u2019s large array of benches comes in various designs that includes fixed and adjustable positions. Any BodyKore bench is a good addition to make as a focal point for your strength training, ensuring you can reap the full benefits of reps and sets.",
                            icon: "/svg/document.svg",
                            btnText: "Download Technical Data",
                            bgImage: "bg-mid-banner",
                            heightbg: "498px",
                            heightGradient: "498px",
                            link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].manuals.path */ .Z.manuals.path
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-44 px-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            title1: "GET",
                            title2: "INSPIRATION",
                            color1: "text-red-bc2026",
                            color2: "text-black-373933",
                            btnText: "PORTFOLIO",
                            link: _config_routes__WEBPACK_IMPORTED_MODULE_5__/* ["default"].portfolio.path */ .Z.portfolio.path,
                            bgImage: mapProjects(),
                            width: "w-1/2"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pb-64",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Text_Titles_Blacktitle__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                title: `TOP ${shopifyData.title} SELLS`,
                                textColor: "text-black-373933",
                                textSize: "text-5xl"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Cards_SellCards__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                gap: "gap-12",
                                cards: mapProducts()
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Category);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 8702:
/***/ ((module) => {

module.exports = require("@splidejs/react-splide");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4342:
/***/ ((module) => {

module.exports = require("localstorage-slim");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,658,6903,6731,8185,1332,273], () => (__webpack_exec__(2801)));
module.exports = __webpack_exports__;

})();