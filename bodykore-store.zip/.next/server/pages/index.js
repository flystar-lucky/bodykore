"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 8247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HomeSection1)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function HomeSection1({ options  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-black w-full text-white h-fit py-24 text-sm",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-wrap max-w-7xl m-auto justify-center gap-20",
                    children: options.map((o, i)=>{
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-row w-64",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: o.icon,
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "pl-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-acumin-pro pb-2",
                                            children: o.title
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-roboto text-gray-char",
                                            children: o.description
                                        })
                                    ]
                                })
                            ]
                        }, i);
                    })
                })
            })
        })
    });
};


/***/ }),

/***/ 5870:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HomeSection2)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function HomeSection2({ title1 , title2 , description , options  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
            className: "w-full",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "h-4 bg-red-bc2026"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "h-fit pt-12 bg-black justify-center text-center",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex flex-col",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-center pt-48 px-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-red-bc2026 pr-2 text-4xl lg:text-5xl font-bebas font-bold italic",
                                        children: title1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-white-f2f9fa text-4xl lg:text-5xl font-bebas font-bold italic",
                                        children: title2
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-white-f2f9fa px-12 lg:px-80 pt-6 text-sm lg:text-md font-roboto leading-7",
                                children: description
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-black",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap justify-center md:justify-between md:justify-between xl:justify-between w-full pb-16 md:pb-48 lg:pb-48 xl:pb-48 text-white-f2f9fa h-fit pt-10 lg:pt-24 text-sm max-w-7xl m-auto",
                        children: options.map((o, i)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "px-5 py-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex justify-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: o.icon,
                                            alt: ""
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-acumin-pro pt-4 text-center w-32",
                                        children: o.title
                                    })
                                ]
                            }, i);
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-4 bg-red-bc2026"
                })
            ]
        })
    });
};


/***/ }),

/***/ 5888:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HomeSection3)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function HomeSection3({ title1 , title2 , accordion , filter  }) {
    const { 0: active , 1: setActive  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(-1);
    const { 0: height , 1: setHeight  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("0px");
    const { 0: rotate , 1: setRotate  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("transform duration-700 ease");
    const contentSpace = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    function toggleAccordion(index) {
        if (active === index) {
            setActive(-1);
        } else {
            setActive(index);
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (contentSpace && contentSpace.current) {
            setHeight(`${contentSpace.current.scrollHeight}px`);
            setRotate(active ? "transform duration-700 ease" : "transform duration-700 ease rotate-180");
        }
    }, [
        active
    ]);
    const mapDisplayed = ()=>{
        return accordion.filter((item)=>item.type === type);
    };
    const { 0: type , 1: setType  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(filter[0]);
    const { 0: displayed , 1: setDisplayed  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(mapDisplayed());
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setDisplayed(mapDisplayed());
    }, [
        type
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "w-full max-w-7xl m-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row justify-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:w-1/4 pt-36 hidden lg:block",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-8 pl-24",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-1 space-y-1",
                                "aria-labelledby": "projects-headline",
                                children: filter.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: `group flex items-center px-3 py-1 font-bebas ${item === type ? "text-red-bc2026" : "text-black-373933"} cursor-pointer`,
                                        style: {
                                            letterSpacing: "1px"
                                        },
                                        onClick: ()=>{
                                            setType(item);
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "truncate",
                                            children: item
                                        })
                                    }, item))
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lg:w-3/4 lg:pr-24",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "lg:flex text-center font-bebas text-4xl lg:text-5xl font-bold italic pt-16 max-w-7xl m-auto pb-8",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-black-373933 pr-2",
                                        children: title1
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: " text-red-bc2026 pr-1",
                                        children: title2
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:hidden",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "my-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-1 flex flex-wrap justify-center",
                                        "aria-labelledby": "projects-headline",
                                        children: filter.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "group flex items-center px-3 py-1 font-bebas text-black-373933 cursor-pointer",
                                                style: {
                                                    letterSpacing: "1px"
                                                },
                                                onClick: ()=>{
                                                    setType(item);
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: item
                                                })
                                            }, item))
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "px-8 lg:px-0 pt-8 lg:pt-0",
                                children: displayed.map((a, i)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "py-3 box-border appearance-none cursor-pointer focus:outline-none flex items-center justify-between",
                                                onClick: ()=>toggleAccordion(i),
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex items-center gap-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            onClick: ()=>toggleAccordion(i),
                                                            src: `${active === i ? "/svg/substraction.svg" : "/svg/sum.svg"}`,
                                                            height: "30px",
                                                            alt: ""
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "inline-block text-footnote light font-bebas text-2xl text-black-373933",
                                                            children: a.question
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                ref: contentSpace,
                                                style: {
                                                    maxHeight: `${active === i ? height : "0px"}`
                                                },
                                                className: "overflow-auto transition-max-height duration-700 ease-in-out faqs-container",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "pl-8",
                                                    children: a.answer
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "border-b border-gray-200"
                                            })
                                        ]
                                    }, i);
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};


/***/ }),

/***/ 5075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(658);
/* harmony import */ var _components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8134);
/* harmony import */ var _components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1332);
/* harmony import */ var _components_ui_bodykore_Sections_HomeSection1__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8247);
/* harmony import */ var _components_ui_bodykore_Sections_HomeSection2__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5870);
/* harmony import */ var _components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6903);
/* harmony import */ var _components_ui_bodykore_Sections_AboutSection4__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3214);
/* harmony import */ var _components_ui_bodykore_Sections_HomeSection3__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5888);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2980);
/* harmony import */ var _components_Header__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8969);
/* harmony import */ var _lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8185);
/* harmony import */ var _utils_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4725);
/* harmony import */ var _config_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9641);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2780);
/* harmony import */ var services_graphCMS__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4263);
/* harmony import */ var services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5852);
/* harmony import */ var services_stamped__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(733);
/* harmony import */ var _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8099);
/* harmony import */ var _components_seoHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7341);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Header__WEBPACK_IMPORTED_MODULE_10__]);
_components_Header__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



















const getStaticProps = async (context)=>{
    const header = await (0,_utils_header__WEBPACK_IMPORTED_MODULE_1__/* .getHeader */ .P)();
    const shopifyData = await (0,services_shopify_storefront__WEBPACK_IMPORTED_MODULE_2__/* .getShopifyCollectionPage */ .B2)("packages");
    const CMSData = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_3__/* .getCMSCollectionPage */ .d5)("packages");
    const faqs = await (0,services_graphCMS__WEBPACK_IMPORTED_MODULE_4__/* .getFaqs */ .n)();
    const reviews = await (0,services_stamped__WEBPACK_IMPORTED_MODULE_5__/* .getHomeReviews */ .IK)();
    return {
        props: {
            header,
            CMSData,
            faqs,
            shopifyData,
            reviews
        },
        revalidate: 30 * 60
    };
};
function Home({ header , CMSData , faqs , shopifyData , reviews  }) {
    const mapProjects = ()=>{
        return CMSData.projectCategories.map((item)=>({
                url: item.projects[0].image[0].url,
                title: item.title,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].portfolio.path */ .Z.portfolio.path}/${item.projects[0].slug}`
            }));
    };
    const mapCollections = ()=>{
        return header.categories.map((item)=>({
                url: item.image,
                topTitle: item.title,
                title: item.title,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].collection.path */ .Z.collection.path}/${item.slug}`
            }));
    };
    const mapPackages = ()=>{
        return shopifyData.products.edges.map((item)=>({
                url: item.node.featuredImage?.url,
                downTitle: item.node.title,
                title: item.node.title,
                link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path}/${item.node.handle}`
            }));
    };
    const size = (0,_lib_hooks_use_window_size__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    let widthSize = size.width;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seoHeader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                seo: _public_SEO_en_json__WEBPACK_IMPORTED_MODULE_9__/* .home */ .LE
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Header__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                productCat: header.categories,
                dynamicPages: header.pages
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                    className: "w-full",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_MainBanner__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            title: "TURNKEY HOME GYM SYSTEM",
                            bgImage: "/frontPage/mainImage.jpg",
                            buttonsText: [
                                {
                                    text: "SEE ALL PACKAGES",
                                    color: "transparent",
                                    link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].collection.path */ .Z.collection.path}/packages`
                                }, 
                            ],
                            width: "w-3/4"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_HomeSection1__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            options: [
                                {
                                    icon: "/svg/characteristics1.svg",
                                    title: "AS LOW AS 0% APR FINANCING",
                                    description: "From Affirm."
                                },
                                {
                                    icon: "/svg/characteristics2.svg",
                                    title: "EASY ASSEMBLY",
                                    description: "Professional installation not required."
                                },
                                {
                                    icon: "/svg/characteristics3.svg",
                                    title: "WARRANTY INCLUDED",
                                    description: "Conditions may apply."
                                },
                                {
                                    icon: "/svg/characteristics4.svg",
                                    title: "NATIONWIDE SHIPPING",
                                    description: "Lorem ipsum dolor"
                                }, 
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Banners_InvisibleBanner__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            height: "h-24",
                            id: "belowBanner"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (()=>{
                                if (widthSize !== undefined && widthSize >= 900) {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "pt-10 px-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                            title1: "FIND A PACKAGE THAT MEETS YOUR",
                                            color1: "text-black-373933",
                                            title2: "NEEDS",
                                            color2: "text-red-bc2026",
                                            description: "With multiple options to choose from, BodyKore\u2019s premier selection of exercise and home gym equipment comes in a variety of different combinations all suited to your fitness needs. Whether you\u2019re low on space, or are looking to fill a larger area, BodyKore has a Package that\u2019s best-suited for your home.",
                                            btnText: "SEE ALL PACKAGES",
                                            border: "border",
                                            btnBorder: "border-black-373933",
                                            link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].collection.path */ .Z.collection.path}/packages`,
                                            bgImage: mapPackages(),
                                            height: "h-64"
                                        })
                                    });
                                } else {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "pt-10 px-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            title1: "FIND A PACKAGE THAT MEETS YOUR",
                                            title2: "NEEDS",
                                            color1: "text-black-373933",
                                            color2: "text-red-bc2026",
                                            description: "With multiple options to choose from, BodyKore\u2019s premier selection of exercise and home gym equipment comes in a variety of different combinations all suited to your fitness needs. Whether you\u2019re low on space, or are looking to fill a larger area, BodyKore has a Package that\u2019s best-suited for your home.",
                                            btnText: "SEE ALL PACKAGES",
                                            link: `${_config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].collection.path */ .Z.collection.path}/packages`,
                                            bgImage: mapPackages(),
                                            gap: "gap-8",
                                            textPosition: "text-center",
                                            pb: "py-8"
                                        })
                                    });
                                }
                            })()
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: (()=>{
                                if (widthSize !== undefined && widthSize >= 900) {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "py-44 px-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_Slider__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                            title1: "ALL",
                                            color1: "text-red-bc2026",
                                            title2: "PRODUCTS",
                                            color2: "text-black-373933",
                                            description: "From cable machines to dumbbells and everything in between, BodyKore\u2019s extensive product lines have machines, equipment, and more for every type of fitness training.",
                                            btnText: "SEE ALL PRODUCTS",
                                            btnBorder: "border-black-373933",
                                            border: "border",
                                            link: _config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path,
                                            bgImage: mapCollections()
                                        })
                                    });
                                } else {
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "py-32 md:py-44 px-8",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            title1: "ALL",
                                            title2: "PRODUCTS",
                                            color1: "text-red-bc2026",
                                            color2: "text-black-373933",
                                            description: "From cable machines to dumbbells and everything in between, BodyKore\u2019s extensive product lines have machines, equipment, and more for every type of fitness training.",
                                            btnText: "SEE ALL PRODUCTS",
                                            link: _config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].products.path */ .Z.products.path,
                                            bgImage: mapCollections(),
                                            gap: "gap-8",
                                            pb: "py-8"
                                        })
                                    });
                                }
                            })()
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_HomeSection2__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                            title1: "BENEFITS",
                            title2: "OF OWNING A HOME GYM",
                            description: "With multiple options to choose from, BodyKore\u2019s premier selection of exercise and home gym equipment comes in a variety of different combinations all suited to your fitness needs.",
                            options: [
                                {
                                    icon: "/svg/benefits1.svg",
                                    title: "TIME SAVING"
                                },
                                {
                                    icon: "/svg/benefits2.svg",
                                    title: "COMFORTABLE"
                                },
                                {
                                    icon: "/svg/benefits3.svg",
                                    title: "CLEAN"
                                },
                                {
                                    icon: "/svg/benefits4.svg",
                                    title: "INCREASE IN PROPERTY VALUE"
                                },
                                {
                                    icon: "/svg/benefits5.svg",
                                    title: "PRIVACY"
                                }, 
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "py-28 px-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sliders_SliderProgress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                title1: "GET",
                                title2: "INSPIRATION",
                                color1: "text-red-bc2026",
                                color2: "text-black-373933",
                                btnText: "PORTFOLIO",
                                link: _config_routes__WEBPACK_IMPORTED_MODULE_6__/* ["default"].portfolio.path */ .Z.portfolio.path,
                                bgImage: mapProjects(),
                                width: "w-1/2"
                            })
                        }),
                        reviews.length !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "px-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_AboutSection4__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                img: "/frontPage/Review.jpg",
                                reviews: reviews
                            })
                        }) : null,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "py-52",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_bodykore_Sections_HomeSection3__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                title1: "FREQUENTLY ASKED",
                                title2: "QUESTIONS",
                                accordion: faqs.faqs.map((item)=>({
                                        question: item.question,
                                        answer: item.answer,
                                        type: item.faqType?.name
                                    })),
                                filter: faqs.faqTypes.map((item)=>item.name)
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                productCat: header.categories
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ getFaqs)
/* harmony export */ });
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5805);
/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);


const graphcms = (0,_config__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
const getFaqs = async ()=>{
    const query = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`
    query FAQ {
      faqTypes {
        name
      }
      faqs {
        question
        answer
        faqType {
          name
        }
      }
    }
  `;
    const res = await graphcms.request(query);
    return res;
};


/***/ }),

/***/ 8768:
/***/ ((module) => {

module.exports = require("@heroicons/react/outline");

/***/ }),

/***/ 8702:
/***/ ((module) => {

module.exports = require("@splidejs/react-splide");

/***/ }),

/***/ 5805:
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 4305:
/***/ ((module) => {

module.exports = require("lodash.debounce");

/***/ }),

/***/ 6641:
/***/ ((module) => {

module.exports = require("next-seo");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9755:
/***/ ((module) => {

module.exports = require("recoil");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = import("@headlessui/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [2952,3061,6566,8933,658,6903,8185,1332,1759,3214], () => (__webpack_exec__(5075)));
module.exports = __webpack_exports__;

})();